//
//  ModifyPassword.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-11.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "RGBConvertUIColor.h"
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"

@interface ModifyPassword : UIViewController <UITableViewDataSource, UITableViewDelegate,NSURLConnectionDelegate,NSURLConnectionDataDelegate,UITextFieldDelegate>
{
    NSArray *baseInput;
    NSNetRequestKiss *RequestKiss;
        ViewOperation *vo;
}
@property (nonatomic,retain)  IBOutlet NSMutableData *receiveData;
@property (nonatomic, retain) IBOutlet UIView *FatherView;
@property (nonatomic, retain) IBOutlet UIButton *ResetBtn;
@property (nonatomic, retain) IBOutlet UIButton *CancelBtn;
@property (nonatomic, retain) IBOutlet UIView *SonView;
@property (nonatomic, retain) IBOutlet UISegmentedControl *rightSeg;

@property (nonatomic ,retain) IBOutlet UITextField *UserName;
@property (nonatomic ,retain) IBOutlet UITextField *DedaultPassWord;
@property (nonatomic ,retain) IBOutlet UITextField *NewPassWord;
@property (nonatomic ,retain) IBOutlet UITextField *NewPassWordAgain;
@property (nonatomic , retain) IBOutlet UITableViewCell *Cellcontainer1;
@property (nonatomic , retain) IBOutlet UITableViewCell *Cellcontainer2;
@property (nonatomic , retain) IBOutlet UITableViewCell *Cellcontainer3;
@property (nonatomic , retain) IBOutlet UITableViewCell *Cellcontainer4;
@property (nonatomic , retain) IBOutlet UITableViewCell *Cellcontainer6;

@end

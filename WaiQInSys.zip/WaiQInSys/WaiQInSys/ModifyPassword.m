//
//  ModifyPassword.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-11.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "ModifyPassword.h"


@interface ModifyPassword ()

@end

@implementation ModifyPassword
@synthesize FatherView = _FatherView;
@synthesize SonView = _SonView;
@synthesize ResetBtn = _ResetBtn;
@synthesize CancelBtn = _CancelBtn;
@synthesize rightSeg = _rightSeg;

@synthesize UserName = _UserName;
@synthesize DedaultPassWord = _DedaultPassWord;
@synthesize NewPassWord = _NewPassWord;
@synthesize NewPassWordAgain  =_NewPassWordAgain;
@synthesize receiveData = _receiveData;
@synthesize Cellcontainer1 =_Cellcontainer1;
@synthesize Cellcontainer2 =_Cellcontainer2;
@synthesize Cellcontainer3 =_Cellcontainer3;
@synthesize Cellcontainer4 =_Cellcontainer4;
@synthesize Cellcontainer6 =_Cellcontainer6;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIBarButtonItem  *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(SaveMsg)];
    [self.navigationItem setRightBarButtonItem:rightItem];
    baseInput = [[NSArray alloc]  initWithObjects:self.Cellcontainer1,self.Cellcontainer2,self.Cellcontainer3,self.Cellcontainer4, nil];
    //对View进行美化
    RGBConvertUIColor *con = [[RGBConvertUIColor alloc] init];
    self.ResetBtn.layer.cornerRadius = 10.0;
    self.CancelBtn.layer.cornerRadius = 10.0;
    self.ResetBtn.layer.backgroundColor = [con convertRGB:@"da4f49" andAlpha:@"1"].CGColor;
    self.CancelBtn.layer.backgroundColor = [con convertRGB:@"006dcc" andAlpha:@"1"].CGColor;
    self.SonView.layer.backgroundColor = [con convertRGB:@"f5f5f5" andAlpha:@"1"].CGColor;
    NSUserDefaults *userDefault = [NSUserDefaults   standardUserDefaults ];
    self.UserName.text = [userDefault objectForKey:@"un"];
    //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}

-(void)SaveMsg
{
    if([self.UserName.text isEqualToString:@""] | [self.DedaultPassWord.text  isEqualToString:@""]|[self.NewPassWordAgain.text  isEqualToString:@""])
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"用户名密码不能为空。" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
    }
    else
    {
        NSString *post = [NSString stringWithFormat:@"userAccount=%@&userPassword=%@&newPassword=%@",self.UserName.text,self.DedaultPassWord.text,self.NewPassWordAgain.text];
        RequestKiss = [[NSNetRequestKiss alloc] init];
        NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/user_updatepassword.action" AsyncOrSync:YES PostFormNetData:post]delegate:self];
        [urlConnection start];
    }

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  4;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    //cell.textLabel.text = [baseInfoHead objectAtIndex:indexPath.row];
    cell = [baseInput objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;

}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
   /// self.loadingText.text =@"正在登录...";
    
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
  //  self.loadingText.text =@"认证成功...";
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:self.receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"updatepasswordResult"] ];
    NSString *lll = [[NSString alloc] initWithData:self.receiveData encoding:NSUTF8StringEncoding];
    if([tmpStr  isEqualToString:@"密码修改成功！"])
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:tmpStr  delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        self.UserName.text = NULL;
        self.DedaultPassWord.text = NULL;
        self.NewPassWordAgain.text  = NULL;
    }else
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"用户名密码错误。" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
    }
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}
@end

//
//  aViewController.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-25.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface aViewController : UIViewController

@end

//
//  ApplyForDuty.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "ApplyForDuty.h"

@interface ApplyForDuty ()

@end

@implementation ApplyForDuty

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    editReprot = [[dutyReport alloc] initWithNibName:@"dutyReport" bundle:nil];
    cavation_App = [[ApplyForVacation alloc] initWithNibName:@"ApplyForVacation" bundle:nil ];
    otherDuty = [[OtherDuty alloc] initWithNibName:@"OtherDuty" bundle:nil];
    checkReport = [[CheckReportSearch alloc] initWithNibName:@"CheckReportSearch" bundle:nil];
    DutyList = [[NSDictionary alloc]  initWithObjectsAndKeys:checkReport,@"查看",otherDuty,@"时间外勤务",editReprot,@"勤务报告",cavation_App,@"休假申请", nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [DutyList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    cell.textLabel.text = [[DutyList  allKeys] objectAtIndex:indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *key = [[DutyList allKeys] objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:[DutyList objectForKey:key] animated:YES];
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
   
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}
-(IBAction)navitoVacation:(id)sender;

{
[self.navigationController pushViewController:cavation_App animated:YES];
}
-(IBAction)navitoDutyReport:(id)sender;

{
    [self.navigationController pushViewController:editReprot animated:YES];
}
-(IBAction)navitoOtherDuty:(id)sender
{
[self.navigationController pushViewController:otherDuty animated:YES];
}
-(IBAction)navitoCheckReport:(id)sender;

{
[self.navigationController pushViewController:checkReport animated:YES];
}
@end

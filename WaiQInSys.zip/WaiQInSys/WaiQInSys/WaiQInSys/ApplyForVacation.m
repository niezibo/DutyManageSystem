//
//  ApplyForVacation.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define kDEFAULT_DATE_TIME_FORMAT (@"yyyy-MM-dd HH:mm")
#import "ApplyForVacation.h"

@interface ApplyForVacation ()

@end

@implementation ApplyForVacation
@synthesize cell01 = _cell01;
@synthesize cell02 = _cell02;
@synthesize cell1 = _cell1;
@synthesize cell2 = _cell2;
@synthesize cell3 = _cell3;
@synthesize cell4 = _cell4;
@synthesize cell5 = _cell5;
@synthesize cell6 = _cell6;
@synthesize cell7 = _cell7;
@synthesize KissView = _KissView;
@synthesize kissPicker = _kissPicker;
@synthesize chooseOption = _chooseOption;
@synthesize projectField = _projectField;
@synthesize conVacation = _conVacation;
@synthesize beginTime = _beginTime;
@synthesize endTime = _endTime;
@synthesize beginTimeField = _beginTimeField;
@synthesize endTimeField = _endTimeField;
@synthesize userId = _userId;
@synthesize userName = _userName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
-(void)viewDidAppear:(BOOL)animated
{
    RequestKiss = [[NSNetRequestKiss alloc] init];
    codeDic = [[NSDictionary alloc] initWithDictionary:[RequestKiss  readSqlite:@"10"]];
    ProjectJson = [[NSArray alloc] initWithArray:[RequestKiss  getProjectJson]];
    ball = 0;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    userDefault  = [[NSUserDefaults alloc] init];
    proIndex = 0;
    codeIndex = 0;
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"休假申请";
    cellContainer =[[NSArray alloc]  initWithObjects:
                    self.cell01,
                    self.cell02,
                    self.cell1,
                    self.cell2,
                    self.cell3,
                    self.cell4,
                    self.cell5,
                    self.cell6,
                    self.cell7
                    , nil];
    cellContainerHeight = [[NSArray alloc] initWithObjects:NSStringFromCGPoint(CGPointMake(0, self.cell01.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell02.frame.size.height)),
                           NSStringFromCGPoint(CGPointMake(0, self.cell1.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell2.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.cell3.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell4.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell5.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.cell6.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell7.frame.size.height)),nil];
    optionSource = [codeDic allKeys];
    self.KissView.layer.cornerRadius = 5.0;
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(Oper) ];
    [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
    self.userName.text = [userDefault objectForKey:@"userName"];
    self.userId.text = [NSString stringWithFormat:@"%d", [[userDefault objectForKey:@"uid"] integerValue] ];
    self.chooseOption.inputView = self.kissPicker;
    self.projectField.inputView = self.kissPicker;
    self.beginTimeField.inputView = self.beginTime;
    self.endTimeField.inputView = self.endTime;
    [self.beginTime addTarget:self action:@selector(DateBeginChange:) forControlEvents:UIControlEventValueChanged];
     [self.endTime addTarget:self action:@selector(DateEndChange:) forControlEvents:UIControlEventValueChanged];
    //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
}
-(void)DateBeginChange:(id)sender{
    UIDatePicker *one = (UIDatePicker*)sender;
    NSDate *oneData = one.date;
    self.beginTimeField.text = [self NSDateToNSString:oneData];
    
}
-(void)DateEndChange:(id)sender{
    UIDatePicker *two = (UIDatePicker*)sender;
    NSDate *twoData = two.date;
    self.endTimeField.text = [self NSDateToNSString:twoData];
    
}
-(NSString * )NSDateToNSString: (NSDate * )date
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: kDEFAULT_DATE_TIME_FORMAT];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [cellContainer count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // Configure the cell...
    cell  = [cellContainer  objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if(indexPath.row  == 2 || indexPath.row ==3){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{      return  CGPointFromString([cellContainerHeight objectAtIndex:indexPath.row ]).y;
}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if(ball == 0)
    {
    return [ProjectJson count];
    }else if(ball == 1)
    {
        return [codeDic count];
    }
    
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if(ball == 0)
    {
        return [[ProjectJson objectAtIndex:row] objectForKey:@"projectName"];
    }else if(ball ==1)
    {
        return   [[codeDic allKeys] objectAtIndex:row];
    }

}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if(ball == 0)
    {
        self.projectField.text = [[ProjectJson objectAtIndex:row] objectForKey:@"projectName"];
        proIndex = row;
    }else if(ball==1)
    {
        self.chooseOption.text = [[codeDic allKeys] objectAtIndex:row];
    }

    
}
-(void)Oper
{
    NSString *post = [NSString stringWithFormat:@"userId=%d&va.userName=%@&va.projectNo=%d&va.startDate=%@&va.endDate=%@&va.vacationType=%@&va.vacationCont=%@",[[userDefault objectForKey:@"uid"] integerValue],[userDefault objectForKey:@"userName"],[[[ProjectJson objectAtIndex:proIndex] objectForKey:@"projectNo"] integerValue],self.beginTimeField.text,self.endTimeField.text,[codeDic objectForKey:self.chooseOption.text],self.conVacation.text];
    NSURLConnection *urlCon =[[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/vacationapply_makeVacationApply.action" AsyncOrSync:YES PostFormNetData:post] delegate:self]  ;
    [urlCon start];
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"makeVacationApplyResult"] ];
    if([tmpStr isEqualToString:@"提交成功！"])
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
    }else
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        
    }
    
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(IBAction)fillDataforPickerProject:(id)sender
{   ball = 0;
    [self.kissPicker reloadAllComponents];
    
}
-(IBAction)fillDataforPickerClass:(id)sender
{
    if(self.projectField.text == NULL){
        UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请先选择从事项目" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alertView show];
    }else{
        ball = 1;
        [self.kissPicker reloadAllComponents];
        
    }
    
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //[vo autoChangeViewByKeyBoard:textField needView:self.view];
    CGRect frame = textField.frame;
    int offset = frame.origin.y +32 - (self.view.frame.size.height-216.0);
    NSLog(@"%d",offset);
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"NOTHIDDEN" context:nil
     ];
    [UIView setAnimationDuration:animationDuration];
    if(offset <0)
    {
        self.view.frame = CGRectMake(0.0f, offset, self.view.frame.size.width, self.view.frame.size.height);
        
    }
    [UIView commitAnimations];
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}
@end

//
//  colleageContact.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-22.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMessageComposeViewController.h>
#import <MapKit/MapKit.h>
#import "NSNetRequestKiss.h"
#import "colleageLocation.h"

@interface colleageContact : UIViewController<UITableViewDataSource,UITableViewDelegate,MFMessageComposeViewControllerDelegate,MKMapViewDelegate,MKReverseGeocoderDelegate,CLLocationManagerDelegate>
{
    NSArray *contactMethod;
    NSString *phoneNum ;
    NSArray *First;
    NSArray *Second;
    NSArray *Third;
    NSArray *Forth;
    NSArray *Fiveth;
    NSArray *Container;
    NSMutableDictionary *BaseCell;
    CLLocationManager *locationManager;
    NSNetRequestKiss *RequestKiss;
    NSDictionary *rootDic;
    NSMutableData *receiveData;
    colleageLocation *locationView;

}
@property (weak, nonatomic) IBOutlet UILabel *posTime;
@property (retain, nonatomic) IBOutlet     NSDictionary *contentCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *phoneCall;
@property (strong, nonatomic) IBOutlet UITableViewCell *sendSMS;
@property (nonatomic,retain) IBOutlet  NSString   *passPhoneNum;
@property (strong, nonatomic) IBOutlet UIView *HeadView;
@property (strong, nonatomic) IBOutlet UITableViewCell *duty;
@property (strong, nonatomic) IBOutlet UITableViewCell *department;
@property (weak, nonatomic) IBOutlet UITableViewCell *cellphone;
@property (weak, nonatomic) IBOutlet UITableViewCell *telephone;
@property (weak, nonatomic) IBOutlet UITableViewCell *email;
@property (strong, nonatomic) IBOutlet UITableViewCell *workPosition;
@property (strong, nonatomic) IBOutlet UITableViewCell *myhome;
@property (strong, nonatomic) IBOutlet UITableViewCell *birth;
@property (strong, nonatomic) IBOutlet UITableViewCell *notes;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *cellPhoneLabel;
@property (weak, nonatomic) IBOutlet UILabel *telePhoneLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UILabel *workPositionLabel;
@property (weak, nonatomic) IBOutlet UILabel *myHomeLabel;
@property (weak, nonatomic) IBOutlet UILabel *birthLabel;
@property (weak, nonatomic) IBOutlet UILabel *noteLabel;
@property (weak, nonatomic) IBOutlet UILabel *postLabel;
@property (weak, nonatomic) IBOutlet NSString *postName;
@property (weak, nonatomic) IBOutlet UILabel *dutyLabel;
@property (weak, nonatomic) IBOutlet UIButton *posButton;

-(IBAction)makeAcall:(id)sender;
-(IBAction)makeAsms:(id)sender;
-(IBAction)navitoMap:(id)sender;

@end

//
//  tileType01.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-27.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "tileType01.h"

@implementation tileType01

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end

//
//  AppDelegate.h
//  WaiQinSys
//
//  Created by zhihuiguan on 13-2-25.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end

//
//  ApplyForDuty.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "dutyReport.h"
#import "ApplyForVacation.h"
#import "OtherDuty.h"
#import "CheckReportSearch.h"
#import "ViewOperation.h"
@interface ApplyForDuty : UIViewController<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate>
{
    NSDictionary *DutyList;
    dutyReport   *editReprot;
    ApplyForVacation *cavation_App;
    OtherDuty    *otherDuty;
    CheckReportSearch  *checkReport;
        ViewOperation *vo;
}
-(IBAction)navitoVacation:(id)sender;
-(IBAction)navitoDutyReport:(id)sender;
-(IBAction)navitoOtherDuty:(id)sender;
-(IBAction)navitoCheckReport:(id)sender;
@end

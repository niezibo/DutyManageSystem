//
//  RGBConvertUIColor.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RGBConvertUIColor : NSObject


-(UIColor *) convertRGB:(NSString *)rgb andAlpha:(NSString *)alpha;
@end

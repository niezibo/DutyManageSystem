//
//  ReportList.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define kDEFAULT_DATE_TIME_FORMAT (@"HH:mm")
#import "ReportList.h"

@interface ReportList ()

@end

@implementation ReportList
@synthesize cell1 = _cell1;
@synthesize cell2 = _cell2;
@synthesize cell3 = _cell3;
@synthesize cell4 = _cell4;
@synthesize cell5 = _cell5;
@synthesize Ticket  = _Ticket;
@synthesize WhichDay = _WhichDay;

@synthesize classOfvacation = _classOfvacation;
@synthesize onDuty = _onDuty;
@synthesize offDuty = _offDuty;
@synthesize Privatetime= _Privatetime;
@synthesize PrivatetravelTime = _PrivatetravelTime;
@synthesize Remarks = _Remarks;
@synthesize classOfvacationBtn = _classOfvacationBtn;
@synthesize classOfvacationString = _classOfvacationString;
@synthesize onDutyString = _onDutyString;
@synthesize offDutyString = _offDutyString;
@synthesize PrivatetimeString= _PrivatetimeString;
@synthesize PrivatetravelTimeString = _PrivatetravelTimeString;
@synthesize RemarksString = _RemarksString;
@synthesize classOfvacationBtnString = _classOfvacationBtnString;
@synthesize TicketNum = _TicketNum;
@synthesize userId = _userId;
@synthesize userName = _userName;

@synthesize datapicker = _datapicker;
@synthesize datepicker1 = _datepicker1;
@synthesize datepicker2 = _datepicker2;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    userDefault = [[NSUserDefaults alloc] init];
    dutyArr   = [[NSMutableDictionary alloc] initWithCapacity:10];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDictionary = [paths objectAtIndex:0];
    NSString *sqlitepath = [documentsDictionary stringByAppendingPathComponent:@"Duty.sqlite"];
    if(sqlite3_open([sqlitepath UTF8String], &db) == SQLITE_OK)
    {
        NSLog(@"数据库链接成功");
        const char *sqlQuery ="SELECT * FROM `t_code`  WHERE `codeType` ='08'" ;
        sqlite3_stmt *statement;
        if(sqlite3_prepare_v2(db, sqlQuery , -1, &statement, NULL) == SQLITE_OK)
        {

            while (sqlite3_step(statement)== SQLITE_ROW) {
                char *dutyNamechar = (char *)sqlite3_column_text(statement, 4);
                NSString  *dutyName = [[NSString alloc] initWithUTF8String:dutyNamechar];
                char *dutyCodechar = (char *)sqlite3_column_text(statement, 2);
                NSString  *dutyCode = [[NSString alloc] initWithUTF8String:dutyCodechar];
                [dutyArr setValue:dutyCode forKey:dutyName];
            }
            sqlite3_close(db);
        }else {
            NSLog(@"Error:%s",sqlite3_errmsg(db));
        }
        
    }else
    {
        sqlite3_close(db);
        UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"系统错误sqlite出错" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alertView show];
    }

    // Do any additional setup after loading the view from its nib.
    path = [[NSBundle mainBundle] pathForResource:@"ReportList" ofType:@"plist"];
    WorKDic = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
    WorkArr = [WorKDic objectForKey:@"ReportList"];
    cellContainer =[[NSArray alloc]  initWithObjects:
                    self.cell1,
                   self.cell2,
                    self.cell3,
                   self.cell4,
                   self.cell5,
                     nil];
    self.navigationItem.title =self.Ticket;
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(Oper) ];
    [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
    self.userName.text = [userDefault objectForKey:@"userName"];
    self.userId.text= [NSString stringWithFormat:@"%d", [[userDefault objectForKey:@"uid"] integerValue] ];
    self.classOfvacationBtn.titleLabel.text = self.classOfvacationBtnString;
    self.classOfvacation.text = self.classOfvacationString;
    self.onDuty.text = self.onDutyString;
    self.offDuty.text = self.offDutyString;
    self.PrivatetravelTime.text = self.PrivatetravelTimeString;
    self.Privatetime.text  = self.PrivatetimeString;
    self.Remarks.text = self.RemarksString;
    docWork = [[NSArray alloc]  initWithObjects:self.classOfvacation,self.onDuty, self.offDuty,self.PrivatetravelTime,self.Privatetime,self.Remarks,nil];
    vacationOption = [dutyArr allKeys];
    self.classOfvacation.inputView = self.datapicker;
    self.onDuty.inputView = self.datepicker1;
    self.offDuty.inputView = self.datepicker2;
    [self.datepicker1 addTarget:self action:@selector(DateBeginChange:) forControlEvents:UIControlEventValueChanged];
    [self.datepicker2 addTarget:self action:@selector(DateEndChange:) forControlEvents:UIControlEventValueChanged];
    helpKiss = [[HelpNS alloc] init];
    [helpKiss init_Son:self.view];
}
-(void)DateBeginChange:(id)sender{
    UIDatePicker *one = (UIDatePicker*)sender;
    NSDate *oneData = one.date;
    self.onDuty.text = [self NSDateToNSString:oneData];
    
}
-(void)DateEndChange:(id)sender{
    UIDatePicker *two = (UIDatePicker*)sender;
    NSDate *twoData = two.date;
    self.offDuty.text = [self NSDateToNSString:twoData];
    
}
-(void)Oper
{
    NSString *post = [NSString stringWithFormat:@"userId=%@&workApplyNo=%@&wal.workDate=%@&wal.startTime=%@&wal.endTime=%@&wal.workType=%@",[userDefault objectForKey:@"uid"] ,[userDefault objectForKey:@"workApplyNo"],self.WhichDay,[NSString stringWithFormat:@"%@%@",self.onDuty.text,@":00"] ,[NSString stringWithFormat:@"%@%@",self.offDuty.text,@":00"],[dutyArr objectForKey:self.classOfvacation.text]];
    RequestKiss = [[NSNetRequestKiss alloc] init];
    NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/workapply_makeWorkApplyDetail.action" AsyncOrSync:YES PostFormNetData:post]delegate:self];
    [urlConnection start];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [cellContainer count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell  = [cellContainer  objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [dutyArr count];
}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.classOfvacation.text = [[dutyArr allKeys] objectAtIndex:row];
}
-(NSString * )NSDateToNSString: (NSDate * )date
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: kDEFAULT_DATE_TIME_FORMAT];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [[dutyArr allKeys] objectAtIndex:row];
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"makeWorkApplyDetailResult"] ];
    if([tmpStr isEqualToString:@"提交成功！"])
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        [self.navigationController dismissModalViewControllerAnimated:YES];
    }else
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
    
    }
    
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //[vo autoChangeViewByKeyBoard:textField needView:self.view];
    CGRect frame = textField.frame;
    int offset = frame.origin.y +32 - (self.view.frame.size.height-216.0);
    NSLog(@"%d",offset);
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"NOTHIDDEN" context:nil
     ];
    [UIView setAnimationDuration:animationDuration];
    if(offset <0)
    {
        self.view.frame = CGRectMake(0.0f, offset, self.view.frame.size.width, self.view.frame.size.height);
        
    }
    [UIView commitAnimations];
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}
@end

//
//  ValidateInput.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-3.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "ValidateInput.h"

@implementation ValidateInput
-(NSString*)validateAccount:(NSString*)a validatePW:(NSString*)b{
    NSError *error;
    NSString *Flag;
    if([a isEqualToString:@""]){
       return @"用户名不能为空！";
        
    }else
    {
        if([b isEqualToString:@""]){
            
            return @"密码不能为空！";
        }
    }
    regularDemo = [[NSRegularExpression alloc] initWithPattern:@"^[0-9]{7,8}$" options:0 error:&error];
    if(regularDemo != nil){
        NSTextCheckingResult *firstMatch = [regularDemo firstMatchInString:a options:0 range:NSMakeRange(0, a.length)];
        if(firstMatch){
            Flag = @"YES";
            return Flag;
        }else
        {
          Flag = @"密码或用户名格式不正确";
            return Flag;
        }
        
    }
    return @"系统异常";
}
@end

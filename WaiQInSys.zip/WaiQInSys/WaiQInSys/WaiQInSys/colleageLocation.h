//
//  colleageLocation.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-2.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "mapLocation.h"

@interface colleageLocation : UIViewController<MKMapViewDelegate , CLLocationManagerDelegate, MKReverseGeocoderDelegate>
{

CLLocationManager *locationManager;
}
@property (weak, nonatomic) IBOutlet UIWebView *locationView;
@property (nonatomic, retain) IBOutlet NSString *colleageName;
@property (nonatomic, retain) IBOutlet NSString *locationName;
@property (nonatomic) IBOutlet float longi;
@property (nonatomic) IBOutlet float lati;
@property (nonatomic, retain) IBOutlet MKMapView *mapMine;
-(void)createAnnotationWithCoords:(CLLocationCoordinate2D) coords;
@end

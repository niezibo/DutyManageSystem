//
//  ApplicationGoOut.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryDetailViewController.h"
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"
#import "ToastUIView.h"
@interface ApplicationGoOut : UIViewController<UITableViewDataSource , UITableViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate>
{
    NSArray *CellContainer;
    NSArray *cellContainerHeight;
    NSString *path;
    NSMutableDictionary *scrollWheelDic;
    NSMutableArray *scroolWheelArr;
    UIAlertView *alert;
    HistoryDetailViewController *histor;
    NSNetRequestKiss *RequestKiss;
    NSUserDefaults *userDefault;
    NSMutableData *receiveData;
    NSArray * ProjectJson;
    NSInteger proIndex;
        ViewOperation *vo;

}


//从历史追踪跳转过来
@property (nonatomic) IBOutlet BOOL   justCheck;
@property (nonatomic) IBOutlet NSDictionary  *checkDic;

@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell0;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell1;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell2;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell3;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell4;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell5;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell6;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell7;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell8;
@property (nonatomic ,retain) IBOutlet UITableViewCell *Cell9;


@property (strong, nonatomic) IBOutlet UIPickerView *datapicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker0;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker1;
@property (nonatomic, retain) IBOutlet UITextField  *timeForgoout;
@property (nonatomic, retain) IBOutlet UITextField  *timeForgooutYear;
@property (nonatomic, retain) IBOutlet UITextField  *timeForgooutMonth;
@property (nonatomic, retain) IBOutlet UITextField  *timeForgooutDay;
@property (nonatomic, retain) IBOutlet UITextField  *timeForapply;
@property (nonatomic, retain) IBOutlet UITextField  *timeForapplyYear;
@property (nonatomic, retain) IBOutlet UITextField  *timeForapplyMonth;
@property (nonatomic, retain) IBOutlet UITextField  *timeForapplyDay;
@property (nonatomic, retain) IBOutlet UITextField  *timeForgooutBegin;
@property (nonatomic, retain) IBOutlet UITextField  *timeForgooutEnd;



@property (weak, nonatomic) IBOutlet UILabel *acceptState;

@property (nonatomic, retain) IBOutlet UITextField *departmentChoose;
@property (nonatomic, retain) IBOutlet UITextField *Applier;
@property (nonatomic, retain) IBOutlet UITextField *reasonforGoout;
@property (weak, nonatomic) IBOutlet UITextField *ApplyTitle;
@property (weak, nonatomic) IBOutlet UITextField *DepartmentBelong;
@property (weak, nonatomic) IBOutlet UITextField *ApplierKiss;
@property (weak, nonatomic) IBOutlet UITextField *StartPlace;
@property (weak, nonatomic) IBOutlet UITextField *EndPlace;
@property (weak, nonatomic) IBOutlet UITextField *ApplyId;

-(IBAction)ExitInput:(id)sender;
-(IBAction)beginEditClear:(id)sender;
-(IBAction)beginUserDatapicker:(id)sender;
@end

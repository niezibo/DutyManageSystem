//
//  tongshiLocationView.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-5.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "mapLocation.h"
#import "Colleague.h"
#import "NSNetRequestKiss.h"

@interface tongshiLocationView : UIViewController<MKMapViewDelegate , CLLocationManagerDelegate, MKReverseGeocoderDelegate>
{
CLLocationManager *locationManager;
    NSString *streetAddress;
    NSString *cityAddress;
    NSNetRequestKiss *NetRequestKiss;
        NSData *receiveData;
    NSMutableArray * rootArr;
}


@property (nonatomic, retain) IBOutlet MKMapView *mapMine;
@property (nonatomic, retain) IBOutlet  UISearchBar *showSearch;
@property (nonatomic,retain) IBOutlet UISegmentedControl *DefaultSeg;
@property (weak, nonatomic) IBOutlet UIWebView *allColleage;
@property (weak, nonatomic) IBOutlet UIWebView *loadWebView;
-(void)createAnnotationWIthCoords:(CLLocationCoordinate2D) coords;
-(IBAction)navitoList:(id)sender;
@end

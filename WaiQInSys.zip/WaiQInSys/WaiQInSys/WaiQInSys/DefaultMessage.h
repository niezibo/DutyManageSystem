//
//  DefaultMessage.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-6.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "RGBConvertUIColor.h"
#import "CompanyMessageCell.h"
#import "DefaultDetailCompanyMessage.h"
#import "JSONKit.h"
#import "NSNetRequestKiss.h"
#import "Login.h"
#import "ToastUIView.h"
#import "SVPullToRefresh.h"

@interface DefaultMessage : UIViewController<UITableViewDelegate,UITableViewDataSource,NSURLConnectionDelegate,NSURLConnectionDataDelegate>
{
    NSArray *tableHeaders;
    NSString *path;
    NSMutableDictionary *Msgdata;
    UIImage *img;
    UIImage *imgg;
    UIButton *SlideTop;
    UIButton *SlideDown;
    NSUserDefaults *userDefault;
    NSArray *allKeys;
    NSArray *First;
    NSArray *Second;
    NSMutableArray *expandOrnot;
    NSMutableArray *expandArr;
    NSInteger    *section_Kiss;
    NSNetRequestKiss *RequestKiss;
    NSMutableArray *na;
    NSMutableArray *naUser;
    NSInteger pretty;
}


@property (nonatomic ,retain) IBOutlet UIView *SearchViewContainer;
@property (nonatomic, retain) IBOutlet UIView *FirstVew;
@property (nonatomic, retain)  IBOutlet UITableView *CompanyTable;

@property (nonatomic ,retain) IBOutlet UISegmentedControl *SegMessage;
@property (nonatomic , retain) IBOutlet UIToolbar *bottomBar;

//最新模式
@property (strong, nonatomic) IBOutlet UIWebView *loadinWebview;
@property  (nonatomic, retain) IBOutlet NSMutableData *receiveData;
@property  (nonatomic, retain) IBOutlet NSMutableData *receiveDataUser;
@property (nonatomic ,retain) IBOutlet UIView *FatherView;
@property (nonatomic ,retain) IBOutlet UIView *SonView;
@property (nonatomic, retain) IBOutlet UILabel *CompanyM;
@property (nonatomic, retain) IBOutlet UILabel *PersonM;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentMsg;

-(IBAction)changeMsg:(id)sender;
-(IBAction)toolBarChoose:(id)sender;
-(IBAction)toolBarChooseMyZone:(id)sender;
-(IBAction)toolBarChooseMyTongShi:(id)sender;

@end

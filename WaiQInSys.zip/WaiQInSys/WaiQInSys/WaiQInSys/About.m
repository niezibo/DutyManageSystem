//
//  About.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-6.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "About.h"

@interface About ()

@end

@implementation About
@synthesize versionCode = _versionCode;
@synthesize picAbout = _picAbout;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    Container= [[NSMutableArray alloc] initWithObjects:self.picAbout,self.versionCode, nil];
    heightContainer=  [[NSMutableArray alloc] initWithObjects: [NSString stringWithFormat:@"%f",  self.picAbout.frame.size.height],[NSString stringWithFormat:@"%f",  self.versionCode.frame.size.height],nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return  [Container count];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    if(indexPath.section==0)
    {
          cell  = [Container objectAtIndex:0];
    }else
    {
        cell = [Container objectAtIndex:1];
    }
    // Configure the cell...
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   if(indexPath.section==0)
   {
       return [[heightContainer objectAtIndex:0] floatValue];
   }
    else
    {
    return [[heightContainer objectAtIndex:1] floatValue];
    }
}
@end

//
//  Login.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-25.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "Login.h"
#import "DefaultMessage.h"
#import "AppDelegate.h"
#import "ValidateInput.h"
#import "JSONKit.h"
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"
@interface Login : UIViewController<NSURLConnectionDelegate,NSURLConnectionDataDelegate,UITextFieldDelegate>
{
  
    NSArray *colContainer;
    UIButton *loginButton;
    UIButton *logoutButton;
    UIButton *userInfoButton;
    UIButton *timelineButton;
    UIButton *postStatusButton;
    UIButton *postImageStatusButton;
    
    NSDictionary *userInfo;
    NSArray *statues;
    NSString *postStatusText;
    NSString *postImageStatusText;
    ValidateInput *valiInput;
    NSNetRequestKiss *RequestKiss;
    NSUserDefaults *userDefault ;
    //DefaultViewController *Index;
    
    BOOL finished;
    ViewOperation *vo;
}
@property (weak, nonatomic) IBOutlet UISwitch *autoLogin;
@property (weak, nonatomic) IBOutlet UILabel *loadingText;
@property (weak, nonatomic) IBOutlet UIView *loadingUIView;
@property (weak, nonatomic) IBOutlet UIWebView *loadingView;
@property  (nonatomic, retain) IBOutlet UIImageView *textFieldView_Nie;
@property (nonatomic, retain) IBOutlet UIImageView *LoginBgsecond;
@property (nonatomic, retain) IBOutlet UITextField *username_Nie;
@property (nonatomic, retain) IBOutlet UITextField *password_Nie;
@property (nonatomic, retain) IBOutlet UIToolbar *toolBarForHidden;
@property  (nonatomic, retain) IBOutlet NSMutableData *receiveData;

-(IBAction)LoginContinue:(id)sender;
-(NSString*) dataFilePath;
-(IBAction)Edit_nie:(id)sender;
@end

//
//  ValidateInput.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-3.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ValidateInput : NSObject
{
    NSRegularExpression *regularDemo;
}

//验证账号 只能是由8位数字组成的账号
-(NSString*)validateAccount:(NSString*)a validatePW:(NSString*)b;
//密码 是由字符大小写和数字组成

//生日格式  1991.03.24
@end

//
//  HistoryDetailViewController.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "HistoryDetailViewController.h"

@interface HistoryDetailViewController ()

@end

@implementation HistoryDetailViewController
@synthesize loadNUM = _loadNUM;
@synthesize outWorkCheckInStatus = _outWorkCheckInStatus;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"历史追踪详情";
    RequestKiss = [[NSNetRequestKiss alloc] init];
    userDefault = [[NSUserDefaults alloc] init];
    NSString *post = [NSString stringWithFormat:@"id=%d",self.loadNUM];
    NSLog(@"%d",self.loadNUM);
    outWorkCheckIn = [[NSMutableArray alloc] initWithCapacity:4];
    NSURLResponse *res;
    NSError *error;
    NSURLConnection *urlConn = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/outworkcheckin_checkOutWorkCheckin.action" AsyncOrSync:YES PostFormNetData:post]  delegate:self];
    [urlConn start];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [outWorkCheckIn count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    HistoryDetailCell *cell = (HistoryDetailCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray *nib_Nie = [[NSBundle mainBundle] loadNibNamed:@"HistoryDetailCell" owner:self options:nil];
        cell = [nib_Nie  objectAtIndex:0];
    }
    
    // Configure the cell...
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.CountLabel.text = [NSString stringWithFormat:@"%d",(indexPath.row+1)];
    cell.Who.text = [userDefault  objectForKey:@"userName"];
    NSDictionary *tmpOuWorkCheckIn = [outWorkCheckIn objectAtIndex:indexPath.row];
    NSString *checkInState = [[RequestKiss readSqlite:@"09" sub:[tmpOuWorkCheckIn objectForKey:@"checkinType"]] objectForKey:[tmpOuWorkCheckIn objectForKey:@"checkinType"]];
    cell.CheckState.text = checkInState;
    cell.CheckTime.text = [tmpOuWorkCheckIn objectForKey:@"checkinTime"];
    cell.WorkState.text = [tmpOuWorkCheckIn objectForKey:@"WorkState"];
    cell.WorkStateSecond.text = checkInState;
    cell.WhoPosition.text =[[[[[[RequestKiss getMyPositionLon:[[tmpOuWorkCheckIn objectForKey:@"checkinLongitude"] floatValue] getMyPositionLon:[[tmpOuWorkCheckIn objectForKey:@"checkinLongitude"] floatValue]] objectForKey:@"list"] objectAtIndex:0] objectForKey:@"poilist"] objectAtIndex:0] objectForKey:@"name"];
    return cell;
}

//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//      
//}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 115;
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    outWorkCheckIn = [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error];
    [self.outWorkCheckInStatus reloadData];
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
@end

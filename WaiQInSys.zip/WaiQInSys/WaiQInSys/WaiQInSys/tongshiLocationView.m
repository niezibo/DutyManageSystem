//
//  tongshiLocationView.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-5.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "tongshiLocationView.h"

@interface tongshiLocationView ()

@end

@implementation tongshiLocationView
@synthesize mapMine = _mapMine;
@synthesize showSearch = _showSearch;
@synthesize DefaultSeg = _DefaultSeg;
@synthesize allColleage  =_allColleage;
@synthesize loadWebView = _loadWebView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NetRequestKiss = [[NSNetRequestKiss alloc] init];
    NSURLConnection *urlConn = [[NSURLConnection alloc] initWithRequest:[NetRequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/colleage_checkAllColleagePosition.action" AsyncOrSync:YES PostFormNetData:nil] delegate:self];
    [urlConn start];
    rootArr = [[NSMutableArray alloc] initWithCapacity:10];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title  = @"周边同事";
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"查找同事" style:UIBarButtonItemStylePlain target:self action:@selector(Oper) ];
    [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
    
    //加载时隐藏搜索栏
    self.showSearch.hidden = YES;
    //初始加载默认
    self.DefaultSeg.selectedSegmentIndex = 0;
    
    self.mapMine.mapType = MKMapTypeStandard;
    self.mapMine.delegate = self;
    self.mapMine.zoomEnabled = YES;
    self.mapMine.showsUserLocation = YES;
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter  =1000.0f;
    [locationManager startUpdatingLocation];
    [NetRequestKiss  loadingAction:self.loadWebView];
    [self.allColleage loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://w3c.ap01.aws.af.cm/allColleage.html"]]];


}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    self.loadWebView.hidden = YES;
}
-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{
    self.view.transform = CGAffineTransformIdentity;
    CGAffineTransform tranform = CGAffineTransformMakeRotation(-1 * M_PI*newHeading.magneticHeading/180.0);
    self.view.transform = tranform;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)mapViewWillStartLoadingMap:(MKMapView *)mapView
{
    if([rootArr count]==0)
    {
    
    }else
    {
        self.mapMine.centerCoordinate = mapView.centerCoordinate;
        
        float zoomLevel = 0.02;
        MKCoordinateRegion region = MKCoordinateRegionMake(mapView.centerCoordinate, MKCoordinateSpanMake(zoomLevel, zoomLevel));
        [self.mapMine setRegion:[self.mapMine regionThatFits:region] animated:YES];
        for(NSDictionary *d in rootArr)
        {
                CLLocationCoordinate2D coords = CLLocationCoordinate2DMake([[d objectForKey:@"checkinLatitude"] floatValue],[[d objectForKey:@"checkinLongitude"] floatValue]);
                [self createAnnotationWIthCoords:coords Flagtitle:[d objectForKey:@"checkinTime"] Flagsubtitle:@"I am here"];
        }

    }
   
}
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(newLocation.coordinate, 1000, 1000);
    // CLLocationCoordinate2D _xx_Nie = CLLocationCoordinate2DMake(36.48333, 134.33059445);
    // MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(_xx_Nie, 100000, 100000);
    
    MKCoordinateRegion adjustRegion = [self.mapMine regionThatFits:viewRegion];
    [self.mapMine setRegion:adjustRegion animated:YES];
    //[self.activeView_Nie stopAnimating];
    [locationManager stopUpdatingLocation];
    MKReverseGeocoder *geocoder = [[MKReverseGeocoder alloc] initWithCoordinate:newLocation.coordinate];
    geocoder.delegate = self;
    [geocoder start];

    
}
//获得地址信息
-(void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFindPlacemark:(MKPlacemark *)placemark
{
    streetAddress = placemark.thoroughfare;
    NSLog(streetAddress);
    
}

//添加大头针
-(void)createAnnotationWIthCoords:(CLLocationCoordinate2D) coords Flagtitle:(NSString*) Maptitle Flagsubtitle:(NSString*) Mapsubtitle
{
    mapLocation *annotaion_Map = [[mapLocation alloc] initWithCoordinate: coords ];
    annotaion_Map.title = Maptitle ;
    annotaion_Map.subtitle = Mapsubtitle;
    [self.mapMine addAnnotation:annotaion_Map];
        [self.mapMine selectAnnotation:annotaion_Map animated:YES];
    
}
-(void)Oper
{
    [UIView beginAnimations:@"ShowSearch" context:nil];
    [UIView setAnimationDuration:0.5];
    self.navigationController.navigationBarHidden = YES;
    self.showSearch.hidden = NO;
    [UIView commitAnimations];
}
-(IBAction)navitoList:(id)sender
{
    Colleague *tongshiList = [[Colleague alloc] initWithNibName:@"Colleague" bundle:nil];
    [self.navigationController pushViewController:tongshiList animated:YES];
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    rootArr = [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error];
    [self.mapMine reloadInputViews];
 
       
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
}
@end

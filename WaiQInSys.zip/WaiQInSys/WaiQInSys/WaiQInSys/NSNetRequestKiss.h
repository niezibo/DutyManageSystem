//
//  NSNetRequestKiss.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "JSONKit.h"

@interface NSNetRequestKiss : NSObject <NSURLConnectionDelegate>
{
    sqlite3 *db;
    NSUserDefaults *userDefault;
}
-(NSMutableURLRequest *)PostFormNetURL:(NSString*) a  AsyncOrSync:(BOOL) b PostFormNetData:(NSString*) c;
-(NSDictionary *)readSqlite:(NSString *)a;
-(NSArray *) getProjectJson;
-(NSDictionary *)getMyPositionLon:(CGFloat)A getMyPositionLon:(CGFloat)B;
-(NSArray *) getPostJson;
-(NSString *)timeConvert:(NSDate *)da;
-(void)loadingAction:(UIWebView *)a;
-(NSDictionary *)readSqlite:(NSString *) a sub:(NSString*)b;
-(NSDictionary *) postJsonOne:(int) a;
-(NSDictionary *) projectJsonOne:(int) a;
-(void)uploadPortraitTask:(NSDictionary *)info;
@end

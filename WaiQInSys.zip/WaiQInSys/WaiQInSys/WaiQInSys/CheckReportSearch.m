//
//  CheckReportSearch.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define kDEFAULT_DATE_TIME_FORMAT (@"yyyy-MM-dd")
#import "CheckReportSearch.h"

@interface CheckReportSearch ()

@end

@implementation CheckReportSearch
@synthesize Applyoption = _Applyoption;
@synthesize Applytime = _Applytime;
@synthesize ApplytimeEnd = _ApplytimeEnd;
@synthesize allKiss = _allKiss;
@synthesize datapicker = _datapicker;
@synthesize optionField = _optionField;
@synthesize datepicker1;
@synthesize datepicker2;
@synthesize timeBegin;
@synthesize timeEnd;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    userDefault = [[NSUserDefaults alloc] init];
    RequestKiss = [[NSNetRequestKiss alloc] init];
    urlContainer = [[NSArray alloc] initWithObjects:@"",@"", nil];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"报告检索";
    Container  = [[NSArray alloc] initWithObjects:self.Applytime,self.ApplytimeEnd, self.Applyoption,self.allKiss, nil];
    NSArray *tmpWorkApply = [[NSArray alloc] initWithObjects:@"http://w3c.ap01.aws.af.cm/workapply_searchWorkApply.action",@"http://w3c.ap01.aws.af.cm/workapply_searchWorkApply.action" ,nil];
    NSArray *tmpVacationApply = [[NSArray alloc] initWithObjects:@"http://w3c.ap01.aws.af.cm/vacationapply_checkVacationApply.action",@"http://w3c.ap01.aws.af.cm/vacationapply_searchVacationApply.action", nil];
    urlContainer = [[NSArray alloc] initWithObjects:tmpWorkApply,tmpVacationApply, nil];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"搜索" style:UIBarButtonItemStylePlain target:self action:@selector(Oper)];
    [self.navigationItem setRightBarButtonItem:rightItem];
    codeContainer = [[NSDictionary alloc] initWithObjectsAndKeys:tmpWorkApply,@"勤务申请",tmpVacationApply,@"休假申请", nil];
    chooseOption = [[NSArray alloc] initWithArray:[codeContainer allKeys]];
    self.optionField.inputView = self.datapicker;
    self.timeBegin.inputView  = self.datepicker1;
    self.timeEnd.inputView= self.datepicker2;
    
    [self.datepicker1 addTarget:self action:@selector(DateBeginChange:) forControlEvents:UIControlEventValueChanged];
    [self.datepicker2 addTarget:self action:@selector(DateEndChange:) forControlEvents:UIControlEventValueChanged];
}
-(void)DateBeginChange:(id)sender{
    UIDatePicker *one = (UIDatePicker*)sender;
    NSDate *oneData = one.date;
    self.timeBegin.text = [self NSDateToNSString:oneData];
    
}
-(void)DateEndChange:(id)sender{
    UIDatePicker *two = (UIDatePicker*)sender;
    NSDate *twoData = two.date;
    self.timeEnd.text = [self NSDateToNSString:twoData];
    
}
-(void)Oper
{
    if([self.optionField.text isEqualToString:@""])
    {
        [self.view makeToast:@"请选择申请分类"];
    }else{
        checkReprot = [[CheckReport alloc] initWithNibName:@"CheckReport" bundle:nil];
        checkReprot.researchTitle = [chooseOption objectAtIndexedSubscript:indexUrl];
        if([self.timeBegin.text isEqualToString:@""] || [self.timeEnd.text isEqualToString:@""])
        {
            checkReprot.urlPost = [[codeContainer objectForKey:self.optionField.text] objectAtIndex:0];
            if(indexUrl==0)
            {
                checkReprot.urlData = [NSString stringWithFormat:@"userId=%d&searchAll=%@",[[userDefault objectForKey:@"uid"] integerValue],@"true"];
            }else
            {
                checkReprot.urlData = [NSString stringWithFormat:@"userId=%d",[[userDefault objectForKey:@"uid"] integerValue]];
            }
            
        }else
        {
            checkReprot.urlPost = [[codeContainer objectForKey:self.optionField.text] objectAtIndex:1];
            if(indexUrl==0)
            {
                checkReprot.urlData = [NSString stringWithFormat:@"userId=%d&searchAll=%@&startDate=%@&endDate=%@",[[userDefault objectForKey:@"uid"] integerValue],@"false",self.timeBegin.text,self.timeEnd.text];
            }else
            {
                checkReprot.urlData = [NSString stringWithFormat:@"userId=%d&startDate=%@&endDate=%@",[[userDefault objectForKey:@"uid"] integerValue],self.timeBegin.text,self.timeEnd.text];
            }
        }
        [self.navigationController pushViewController:checkReprot animated:YES];
    }
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [Container count];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    
    cell = [Container objectAtIndex:indexPath.row];
    // Configure the cell...
     cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if(indexPath.row == 2 ||indexPath.row == 3){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 3){
        checkReprot = [[CheckReport alloc] initWithNibName:@"CheckReport" bundle:nil];
        [self.navigationController pushViewController:checkReprot animated:YES];
    } 
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [chooseOption count];
}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [chooseOption objectAtIndex:row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    indexUrl = row;
    self.optionField.text = [chooseOption objectAtIndex:row];
}
-(NSString * )NSDateToNSString: (NSDate * )date
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: kDEFAULT_DATE_TIME_FORMAT];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
   
}
@end

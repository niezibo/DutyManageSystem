//
//  Colleague.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-12.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "RGBConvertUIColor.h"
#import "tongshiLocationView.h"
#import "ColleageCell.h"
#import "colleageContact.h"
#import "NSNetRequestKiss.h"
@interface Colleague : UIViewController<UITableViewDataSource, UITableViewDelegate>{
    NSInteger *tmpData;
    NSNetRequestKiss *RequestKiss;
    NSMutableData *receiveData;
    NSMutableArray *rootArr;
    NSMutableDictionary *father;
    NSMutableArray   *godfather ;
    NSMutableArray *sonArr;
    NSInteger *colleageId;

}
    @property (nonatomic, retain) NSArray *arrayOriginal;
    @property (nonatomic, retain) NSMutableArray *arForTable;
@property (nonatomic, retain) IBOutlet UIView    *sweetUIView;
@property (nonatomic, retain) IBOutlet UIWebView *sweetWebView;
@property (nonatomic, retain) IBOutlet UIView *sweetSearchBar;
@property (nonatomic, retain) IBOutlet UITableView *sweetTable;
@property (strong, nonatomic) IBOutlet UIView *openView;
@property (strong, nonatomic) IBOutlet UIView *closeView;
@property (strong, nonatomic) IBOutlet UIView *dotView;
-(void)miniMizeThisRows:(NSArray*)ar needtableView:(UITableView*)tableView;
@end

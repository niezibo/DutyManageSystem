//
//  Colleague.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-12.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "Colleague.h"
#define COLLEAGEICO @"http://w3c.ap01.aws.af.cm/"
@interface Colleague ()

@end

@implementation Colleague
@synthesize sweetSearchBar = _sweetSearchBar;
@synthesize arrayOriginal= _arrayOriginal;
@synthesize arForTable = _arForTable;
@synthesize sweetTable = _sweetTable;
@synthesize sweetWebView = _sweetWebView;
@synthesize sweetUIView = _sweetUIView;
@synthesize closeView = _closeView;
@synthesize openView = _openView;
@synthesize dotView = _dotView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    RequestKiss = [[NSNetRequestKiss alloc]  init];
    NSURLConnection  *urlConn = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/spinner_postName.action" AsyncOrSync:YES PostFormNetData:nil] delegate:self];
    [urlConn start];
    ////////////////
    godfather = [[NSMutableArray alloc] initWithCapacity:10];
    [RequestKiss loadingAction:self.sweetWebView];
////////////////
	

    UIBarButtonItem *rightLocation =[[UIBarButtonItem alloc] initWithTitle:@"同事定位" style:UIBarButtonItemStylePlain target:self action:@selector(navitoLa)];
    [self.navigationItem setRightBarButtonItem:rightLocation animated:YES];
    tmpData = 0;
    


}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
	
	cell.textLabel.text=[[godfather objectAtIndex:indexPath.row] valueForKey:@"name"];
    UIImage *openImg = [UIImage imageNamed:@"ico_open.png"];
    cell.image = openImg;
    //cell.accessoryView = self.openView;
	[cell setIndentationLevel:[[[godfather objectAtIndex:indexPath.row] valueForKey:@"level"] intValue]];
    if([cell indentationLevel]==1){
        ColleageCell *cellSpi = (ColleageCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if(cellSpi == nil){
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ColleageCell" owner:self options:nil];
            cellSpi = [nib objectAtIndex:0];
        }
        [cellSpi setIndentationLevel:[[[godfather objectAtIndex:indexPath.row] valueForKey:@"level"] intValue]];
        cellSpi.colleageName.text = [[godfather objectAtIndex:indexPath.row] valueForKey:@"name"];
        cellSpi.colleagePhone.text = [[godfather objectAtIndex:indexPath.row] valueForKey:@"phoneNum"];
        UIImage *dotImg = [UIImage imageNamed:@"ico_dot.png"];
        cellSpi.image = dotImg;
        NSString *urlStr = [NSString stringWithFormat:@"%@%@",COLLEAGEICO,[[godfather objectAtIndex:indexPath.row] valueForKey:@"userIco"]];
       NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlStr]];
        UIImage *netImg = [UIImage imageWithData:data];
        cellSpi.colleageIco.image = netImg;
        return cellSpi;
    }
	
    return cell;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
	
	NSDictionary *d=[godfather objectAtIndex:indexPath.row];
	if([d valueForKey:@"Objects"]) {
		NSArray *ar=[d valueForKey:@"Objects"];
		
		BOOL isAlreadyInserted=NO;
		
		for(NSDictionary *dInner in ar ){
			NSInteger index=[godfather indexOfObjectIdenticalTo:dInner];
			isAlreadyInserted=(index>0 && index!=NSIntegerMax);
			if(isAlreadyInserted) break;
		}
		
		if(isAlreadyInserted) {
			[self miniMizeThisRows:ar needtableView:tableView];
		} else {
			NSUInteger count=indexPath.row+1;
			NSMutableArray *arCells=[NSMutableArray array];
			for(NSDictionary *dInner in ar ) {
				[arCells addObject:[NSIndexPath indexPathForRow:count inSection:0]];
				[godfather insertObject:dInner atIndex:count++];
			}
			[tableView insertRowsAtIndexPaths:arCells withRowAnimation:UITableViewRowAnimationLeft];
		}
	}

    tmpData = [[[godfather objectAtIndex:indexPath.row] objectForKey:@"level"] intValue];
   
    if(tmpData==1){
        colleageContact *colleageContactKiss = [[colleageContact alloc] initWithNibName:@"colleageContact" bundle:nil];
        colleageContactKiss.passPhoneNum = [[godfather objectAtIndex:indexPath.row] valueForKey:@"phoneNum"];
        colleageContactKiss.contentCell = [[godfather objectAtIndex:indexPath.row] objectForKey:@"perInfo"] ;
        colleageContactKiss.postName = [[godfather objectAtIndex:indexPath.row] objectForKey:@"postName"] ;

        [self.navigationController pushViewController:colleageContactKiss animated:YES];
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [godfather count];
}
-(void)navitoLa
{
    tongshiLocationView *locationView = [[tongshiLocationView alloc] initWithNibName:@"tongshiLocationView" bundle:nil];
    [self.navigationController pushViewController:locationView animated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
            self.navigationItem.title = @"通讯录";
    self.navigationItem.hidesBackButton = YES;
}
-(void)miniMizeThisRows:(NSArray*)ar needtableView:(UITableView*)tableView{
	
	for(NSDictionary *dInner in ar ) {
		NSUInteger indexToRemove=[godfather indexOfObjectIdenticalTo:dInner];
		NSArray *arInner=[dInner valueForKey:@"Objects"];
		if(arInner && [arInner count]>0){
			[self miniMizeThisRows:arInner needtableView:tableView];
		}
		
		if([godfather indexOfObjectIdenticalTo:dInner]!=NSNotFound) {
			[godfather removeObjectIdenticalTo:dInner];
			[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:
                                                    [NSIndexPath indexPathForRow:indexToRemove inSection:0]
                                                    ]
                                  withRowAnimation:UITableViewRowAnimationRight];
		}
	}
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *faceView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320
                                                                , 44)];
    [faceView addSubview:self.sweetSearchBar];
    return  faceView;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    /// self.loadingText.text =@"正在登录...";
    
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //  self.loadingText.text = @"认证成功...";
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error ;
    rootArr = [NSJSONSerialization JSONObjectWithData: receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSData *resData;
    NSURLResponse *res;
    NSData *workDate = [NSURLConnection sendSynchronousRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/user_userList.action" AsyncOrSync:YES PostFormNetData:nil] returningResponse:&res error:&error];
     sonArr = [NSJSONSerialization JSONObjectWithData: workDate options:NSJSONReadingMutableLeaves error:&error];

    for(NSDictionary *d in rootArr)
    {

        NSMutableArray *arr = [[NSMutableArray alloc] initWithCapacity:10];

        for (NSDictionary *c in sonArr)
        {   
            if([d objectForKey:@"postCode"] ==[c objectForKey:@"postCode"])
            {
                
                NSString *userName = [c objectForKey:@"userName"];
                NSString *phoneNumber = [c objectForKey:@"telNo"];
                NSString *count = [NSString stringWithFormat:@"%d", colleageId];
                NSString *postName = [d objectForKey:@"postName"];
                NSString *colleageIco = [c objectForKey:@"userIco"];
                NSMutableDictionary *tmpDic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:postName,@"postName",c,@"perInfo",userName,@"name",[NSString stringWithFormat:@"%d", 1],@"level",phoneNumber,@"phoneNum",colleageIco,@"userIco",nil];
                [arr addObject:tmpDic];
            }
            
            
        }
       [godfather addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[d objectForKey:@"postName"],@"name",[NSString stringWithFormat:@"%d",0],@"level",arr,@"Objects",nil]];
       
        
    }

    [self.sweetTable reloadData];
    self.sweetUIView.hidden = YES;

    

}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}

- (void)viewDidUnload {
    [self setOpenView:nil];
    [self setCloseView:nil];
    [self setDotView:nil];
    [super viewDidUnload];
}
@end

//
//  HistoryTrackSearch.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define kDEFAULT_DATE_TIME_FORMAT (@"yyyy-MM-dd")
#import "HistoryTrackSearch.h"

@interface HistoryTrackSearch ()

@end

@implementation HistoryTrackSearch
@synthesize TimeBeginer = _TimeBeginer;
@synthesize TimeEnder = _TimeEnder;
@synthesize datepicker = _datepicker;
@synthesize DateBegin = _DateBegin;
@synthesize DateEnd = _DateEnd;
@synthesize datepickerSecond = _datepickerSecond;
@synthesize allKiss = _allKiss;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    userDefault = [[NSUserDefaults alloc] init];
    // Do any additional setup after loading the view from its nib.
    Container = [[NSArray alloc] initWithObjects:self.TimeBeginer,self.TimeEnder,self.allKiss, nil];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"搜索" style:UIBarButtonItemStylePlain target:self action:@selector(Oper)];
    [self.navigationItem setRightBarButtonItem:rightItem];
    self.DateEnd.inputView = self.datepickerSecond;
    self.DateBegin.inputView = self.datepicker;
    [self.datepicker addTarget:self action:@selector(DateBeginChange:) forControlEvents:UIControlEventValueChanged];
    [self.datepickerSecond addTarget:self action:@selector(DateEndChange:) forControlEvents:UIControlEventValueChanged];
    self.navigationItem.title = @"勤务检索";
}

-(void)Oper{
    if([self.DateBegin.text isEqualToString:@""] || [self.DateEnd.text isEqualToString:@""])
    {
        [self.view makeToast:@"请输入有效的起始时间"];
    }else
    {
        HistoryTrack *track = [[HistoryTrack alloc] initWithNibName:@"HistoryTrack" bundle:nil];
        track.reqUrl = @"http://w3c.ap01.aws.af.cm/outworkapply_searchOutWorkApply.action";
        track.postData = [NSString stringWithFormat:@"userId=%d&startTime=%@&endTime=%@",[[userDefault objectForKey:@"uid"] integerValue],self.DateBegin.text,self.DateEnd.text];
        [self.navigationController pushViewController:track animated:YES];
    }

}
-(void)DateBeginChange:(id)sender{
    UIDatePicker *one = (UIDatePicker*)sender;
    NSDate *oneData = one.date;
    self.DateBegin.text = [self NSDateToNSString:oneData];
    
}
-(void)DateEndChange:(id)sender{
    UIDatePicker *two = (UIDatePicker*)sender;
    NSDate *twoData = two.date;
    self.DateEnd.text = [self NSDateToNSString:twoData];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    
    cell = [Container objectAtIndex:indexPath.row];
    // Configure the cell...
     cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if(indexPath.row ==2){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row ==2){
        HistoryTrack *track = [[HistoryTrack alloc] initWithNibName:@"HistoryTrack" bundle:nil];
        track.reqUrl = @"http://w3c.ap01.aws.af.cm/outworkapply_checkOutWorkApply.action";
        track.postData = [NSString stringWithFormat:@"oa.userId=%@",[userDefault objectForKey:@"uid"]];
        [self.navigationController pushViewController:track animated:YES];
    }
}
-(NSString * )NSDateToNSString: (NSDate * )date
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: kDEFAULT_DATE_TIME_FORMAT];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
   
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}
@end

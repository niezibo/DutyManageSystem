//
//  NSNetRequestKiss.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "NSNetRequestKiss.h"

@implementation NSNetRequestKiss

-(NSMutableURLRequest  *)PostFormNetURL:(NSString*) a  AsyncOrSync:(BOOL) b PostFormNetData:(NSString*) c
{
    NSURL *url =  [NSURL URLWithString:a ];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[c dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES ]];
    //回应
   
    return request;
}
-(NSDictionary *)readSqlite:(NSString *) a
{   NSMutableDictionary   *dutyArr   = [[NSMutableDictionary alloc] initWithCapacity:10];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDictionary = [paths objectAtIndex:0];
    NSString *sqlitepath = [documentsDictionary stringByAppendingPathComponent:@"Duty.sqlite"];
    if(sqlite3_open([sqlitepath UTF8String], &db) == SQLITE_OK)
    {
        NSLog(@"数据库链接成功");
        NSString   *sqlQuery   =[NSString stringWithFormat:@"SELECT * FROM `t_code`  WHERE `codeType` ='%@'",a];
        sqlite3_stmt *statement;
        if(sqlite3_prepare_v2(db, [sqlQuery UTF8String] , -1, &statement, NULL) == SQLITE_OK)
        {

            while (sqlite3_step(statement)== SQLITE_ROW) {
                char *dutyNamechar = (char *)sqlite3_column_text(statement, 4);
                NSString  *dutyName = [[NSString alloc] initWithUTF8String:dutyNamechar];
                char *dutyCodechar = (char *)sqlite3_column_text(statement, 2);
                NSString  *dutyCode = [[NSString alloc] initWithUTF8String:dutyCodechar];
                NSDictionary *dutyDic = [[NSDictionary alloc] initWithObjectsAndKeys:dutyName,dutyCode, nil];
                [dutyArr setValue:dutyCode forKey:dutyName];
            }
            sqlite3_close(db);
        }else {
            NSLog(@"Error:%s",sqlite3_errmsg(db));
        }
        
    }else
    {
        sqlite3_close(db);
        UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"系统错误sqlite出错" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alertView show];
    }
    return dutyArr;
}
-(NSDictionary *)readSqlite:(NSString *) a sub:(NSString*)b
{   NSMutableDictionary   *dutyArr   = [[NSMutableDictionary alloc] initWithCapacity:10];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDictionary = [paths objectAtIndex:0];
    NSString *sqlitepath = [documentsDictionary stringByAppendingPathComponent:@"Duty.sqlite"];
    if(sqlite3_open([sqlitepath UTF8String], &db) == SQLITE_OK)
    {
        NSLog(@"数据库链接成功");
        NSString   *sqlQuery   =[NSString stringWithFormat:@"SELECT * FROM `t_code`  WHERE `codeType` ='%@' AND `codeValue` ='%@'",a,b];
        sqlite3_stmt *statement;
        if(sqlite3_prepare_v2(db, [sqlQuery UTF8String] , -1, &statement, NULL) == SQLITE_OK)
        {
            
            while (sqlite3_step(statement)== SQLITE_ROW) {
                char *dutyNamechar = (char *)sqlite3_column_text(statement, 4);
                NSString  *dutyName = [[NSString alloc] initWithUTF8String:dutyNamechar];
                [dutyArr setValue:dutyName forKey:b];
            }
            sqlite3_close(db);
        }else {
            NSLog(@"Error:%s",sqlite3_errmsg(db));
        }
        
    }else
    {
        sqlite3_close(db);
        UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"系统错误sqlite出错" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alertView show];
    }
    return dutyArr;
}
-(NSArray *) getProjectJson
{
    userDefault = [[NSUserDefaults alloc] init];
    NSString *token = [NSString stringWithFormat:@"userId=%d",[[userDefault objectForKey:@"uid"] integerValue]];
    return [self getGeneralJson:token Action:@"http://w3c.ap01.aws.af.cm/spinner_projectName.action" ];
}
-(NSArray *)getGeneralJson:(NSString*)a Action:(NSString*)b
{
    NSData *resData;
    NSURLResponse *res;
    NSError *error;
    NSData *workDate = [NSURLConnection sendSynchronousRequest:[self PostFormNetURL:b AsyncOrSync:YES PostFormNetData:a] returningResponse:&res error:&error];
    NSArray * beforeDic = [NSJSONSerialization JSONObjectWithData:workDate options:NSJSONReadingMutableLeaves error:&error];
    return beforeDic;
}
-(NSArray *) getPostJson
{
    return [self getGeneralJson:nil Action:@"http://w3c.ap01.aws.af.cm/spinner_postName.action"];
   
}
-(NSDictionary *)getMyPositionLon:(CGFloat)A getMyPositionLon:(CGFloat)B
{
    NSLog(@"%f",A);
        NSURLResponse *res;
    NSError *error;
    NSString *post = [NSString stringWithFormat:@"resType=json&flag=callback&encode=UTF-8&sid=7001&range=1000&crossnum=0&roadnum=0&poinum=4&retvalue=1&lse_sort_rule=7&lse_poiid_filter=&region=%f,%f",A,B];
    
    NSData *responseData =[NSURLConnection sendSynchronousRequest:[self PostFormNetURL:@"http://restapi.amap.com/rgeocode/simple" AsyncOrSync:YES PostFormNetData:post] returningResponse:&res error:&error];
    NSString *pos =  [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];

    NSString *poss = [pos substringWithRange:NSMakeRange(1, [pos length]-4)];
    return [NSJSONSerialization JSONObjectWithData:[poss dataUsingEncoding:NSUTF8StringEncoding] options:&res error:&error];
}
-(NSString *)timeConvert:(NSDate *)da
{
    NSDateFormatter *nf = [[NSDateFormatter alloc] init];
    [nf  setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
   return  [nf stringFromDate:da];
}
-(void)loadingAction:(UIWebView *)a{
    NSData *gifFile = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"loadinginfo" ofType:@"gif"]];
    //设置WebView是透明的
    a.backgroundColor = [UIColor clearColor];
    a.scrollView.bounces = NO;
    a.scrollView.scrollEnabled = NO;
    [a loadData:gifFile MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];
    
    
}
-(NSDictionary *) postJsonOne:(int) a
{
    NSURLResponse *res;
    NSError *error;
    NSString *post = [NSString stringWithFormat:@"postCode=%d",a];
    NSData *responseData = [NSURLConnection sendSynchronousRequest: [self PostFormNetURL:@"http://w3c.ap01.aws.af.cm/spinner_postNameOne.action" AsyncOrSync:YES PostFormNetData:post] returningResponse:&res error:&error];
    NSDictionary *postDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    return postDic;
}
-(NSDictionary *) projectJsonOne:(int) a
{
    NSURLResponse *res;
    NSError *error;
    NSString *post = [NSString stringWithFormat:@"projectNo=%d",a];
    NSData *responseData = [NSURLConnection sendSynchronousRequest: [self PostFormNetURL:@"http://w3c.ap01.aws.af.cm/spinner_projectNameOne.action" AsyncOrSync:YES PostFormNetData:post] returningResponse:&res error:&error];
    NSDictionary *postDic = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    return postDic;
}
@end

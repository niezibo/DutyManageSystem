//
//  HistoryTrack.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryCell.h"
#import <QuartzCore/QuartzCore.h>
#import "ApplicationGoOut.h"
#import "NSNetRequestKiss.h"
#import "SVPullToRefresh.h"
@interface HistoryTrack : UIViewController<UITableViewDataSource , UITableViewDelegate>
{
    NSNetRequestKiss *RequestKiss;
    NSUserDefaults *userDefault;
    NSMutableData  *receiveData;
    NSMutableArray * rootDic;
    int flag;
    int deleteNo;
}

@property (nonatomic, retain) IBOutlet UITableView *listTable;
@property (nonatomic, retain) IBOutlet UIView *HeadView;
@property (nonatomic, retain) IBOutlet NSString *timeBeginer;
@property (nonatomic, retain) IBOutlet NSString *timeEnder;
@property (nonatomic, retain) IBOutlet NSString *reqUrl;
@property (nonatomic, retain) IBOutlet NSString *postData;
@property (weak, nonatomic) IBOutlet UIView *loadingView;
@property (weak, nonatomic) IBOutlet UIWebView *loadingWebView;


@end

//
//  DefaultMessageCell.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-11.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "DefaultMessageCell.h"

@implementation DefaultMessageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  About.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-6.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface About : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *Container;
    NSMutableArray *heightContainer;
}
@property (weak, nonatomic) IBOutlet UITableViewCell *picAbout;
@property (weak, nonatomic) IBOutlet UITableViewCell *versionCode;

@end

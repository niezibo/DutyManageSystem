//
//  dutyReport.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define kDEFAULT_DATE_TIME_FORMAT (@"yyyy")
#import "dutyReport.h"

@interface dutyReport ()

@end

@implementation dutyReport

//Cell
@synthesize ChooseWeek = _ChooseWeek;
@synthesize ShowTime = _ShowTime;
@synthesize JoinPro =_JoinPro;
@synthesize DutyServe = _DutyServe;
//
@synthesize WeeksInMonth = _WeeksInMonth;
@synthesize SelectText  = _SelectText;
@synthesize InputText = _InputText;
@synthesize ItemText = _ItemText;
@synthesize DutyText = _DutyText;
@synthesize receiveData  = _receiveData ;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    Container = [[NSArray alloc] initWithObjects:self.ChooseWeek,self.ShowTime,self.JoinPro,self.DutyServe, nil];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"报告作成" style:UIBarButtonItemStylePlain target:self action:@selector(Oper)];
    [self.navigationItem setRightBarButtonItem:rightItem];
    self.navigationItem.title = @"勤务报告作成";
   
    self.SelectText.inputView = self.WeeksInMonth;
    self.ItemText.inputView = self.WeeksInMonth;
    self.DutyText.inputView = self.WeeksInMonth;
    self.WeeksInMonth.showsSelectionIndicator = YES;
    hero = 0;
    self.InputText.userInteractionEnabled = NO;
    //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
    re = [[MakeReport alloc] initWithNibName:@"MakeReport" bundle:nil];
    
}
-(void)Oper
{
    userDefault = [[NSUserDefaults alloc] init];
    NSString *post = [NSString stringWithFormat:@"userId=%d&wa.projectNo=%d&wa.workDuty=%@&wa.startDate=%@&wa.endDate=%@",[[userDefault objectForKey:@"uid"] integerValue],projectId,[dutyArr objectForKey:self.DutyText.text],beginDate  ,endDate];
    RequestKiss = [[NSNetRequestKiss alloc] init];
    NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/workapply_makeWorkApply.action" AsyncOrSync:YES PostFormNetData:post]delegate:self];
    [urlConnection start];
    }
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)SlideDown:(id)sender
{
    UIAlertView *gun = [[UIAlertView alloc] initWithFrame:CGRectMake(0, 0, 200, 500)];
    [gun show];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    //return [WorkArr count];
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell = [Container objectAtIndex:indexPath.row];
    if(indexPath.row == 2 || indexPath.row == 3){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

//滚轮显示的列数
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
//当前列下的显示条数
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if(hero==0){
            return [scroolWheelArr  count];
    }else if(hero==1){
           return  [SecondWorkArr count];
    }else if (hero==2){
          
    }      return [dutyArr count];

}
//显示当前行的内容
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if(hero==0){
            return [scroolWheelArr objectAtIndex:row];
    }else if(hero==1){
           return  [[SecondWorkArr objectAtIndex:row] objectForKey:@"projectName"];
    }else if (hero==2){
        return [[dutyArr allKeys ] objectAtIndex:row];
    }


}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
    if(hero==0){
        NSString *defaultTemplate =[NSString stringWithFormat:@"%@%@%@%@",[NSString stringWithFormat:@"%d",helpNS.year],@"-",[NSString stringWithFormat:@"%d",helpNS.month],@"-"];
        NSArray *tmpThunder = [[NSArray alloc] initWithArray:[helpNS getfromto:row+1]];
        re.Beginer = [tmpThunder[0] intValue];
        beginDate = [NSString stringWithFormat:@"%@%@",defaultTemplate,tmpThunder[0]];
        endDate = [NSString stringWithFormat:@"%@%@",defaultTemplate,tmpThunder[1]];
        re.Ender = [tmpThunder[1] intValue];
        re.fieldBeginer = [self dateFromString:beginDate];
        NSString *fillText = [NSString stringWithFormat:@"%@%@%@%@%@",defaultTemplate,tmpThunder[0],@"~",defaultTemplate,tmpThunder[1]];
        self.SelectText.text = [scroolWheelArr objectAtIndex:row];
        self.InputText.text = fillText;
        allDataNet = [self getDataBeforeLoad];
    }else if(hero==1){
        self.ItemText.text = [[SecondWorkArr objectAtIndex:row] objectForKey:@"projectName"];
        projectId = (row+1);
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDictionary = [paths objectAtIndex:0];
        NSString *sqlitepath = [documentsDictionary stringByAppendingPathComponent:@"Duty.sqlite"];
        if(sqlite3_open([sqlitepath UTF8String], &db) == SQLITE_OK)
        {
            NSLog(@"数据库链接成功");
            const char *sqlQuery ="SELECT * FROM `t_code`  WHERE `codeType` ='02'" ;
            sqlite3_stmt *statement;
            NSLog(@"%d",sqlite3_prepare_v2(db, sqlQuery , -1, &statement, NULL));
            if(sqlite3_prepare_v2(db, sqlQuery , -1, &statement, NULL) == SQLITE_OK)
            {
                dutyArr   = [[NSMutableDictionary alloc] initWithCapacity:10];
                while (sqlite3_step(statement)== SQLITE_ROW) {
                    char *dutyNamechar = (char *)sqlite3_column_text(statement, 4);
                    NSString  *dutyName = [[NSString alloc] initWithUTF8String:dutyNamechar];
                    char *dutyCodechar = (char *)sqlite3_column_text(statement, 2);
                    NSString  *dutyCode = [[NSString alloc] initWithUTF8String:dutyCodechar];
                    NSDictionary *dutyDic = [[NSDictionary alloc] initWithObjectsAndKeys:dutyName,dutyCode, nil];
                    [dutyArr setValue:dutyCode forKey:dutyName];
                }
                sqlite3_close(db);
            }else {
                 NSLog(@"Error:%s",sqlite3_errmsg(db));
            }
            
        }else
        {
            sqlite3_close(db);
            UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"系统错误sqlite出错" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
            [alertView show];
        }
        
    }else if (hero==2){
        self.DutyText.text = [[dutyArr allKeys] objectAtIndex:row ];
    }
}
-(IBAction)fillDataforDatePicker:(id)sender
{   hero = 0;
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY"];
    helpNS = [[HelpNS alloc] init];
    helpNS.year = [[dateFormatter stringFromDate:currentDate] intValue];
    [dateFormatter setDateFormat:@"MM"];
    helpNS.month = [[dateFormatter stringFromDate:currentDate] intValue];
    Weeks = [helpNS gethowmanyweeks];
    scroolWheelArr = [[NSMutableArray alloc] initWithCapacity:10];
    for(int jj= 1; jj <=Weeks;jj++ ){
        NSString *ii = [NSString stringWithFormat:@"%@%@%@%@%@%@",[NSString stringWithFormat:@"%d",helpNS.year],@"年",[NSString stringWithFormat:@"%d",helpNS.month],@"月第",[NSString stringWithFormat:@"%d",jj],@"周"];
        [scroolWheelArr addObject:ii];
    }
    [self.WeeksInMonth reloadAllComponents];
}
-(IBAction)fillDataforDatePickerItem:(id)sender
{   hero = 1;
   
    SecondWorkArr =  [allDataNet objectAtIndex:1];
    [self.WeeksInMonth reloadAllComponents];
    
}
-(IBAction)fillDataforDatePickerDuty:(id)sender
{
    if(self.ItemText.text == NULL){
        UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请先选择从事项目" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
            [alertView show];
    }else{
           hero = 2;
        [self.WeeksInMonth reloadAllComponents];
        
    }

    
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
  //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
   // self.loadingText.text =@"认证成功...";
     NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
     NSLog(@"接受数据中");
    self.receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:self.receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"makeWorkApplyResult"] ];
   if([tmpStr isEqualToString:@"提交成功！" ])
    {
        [userDefault setValue: [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"workApplyNo"] ] forKey:@"workApplyNo"];
        [self.navigationController pushViewController:re animated:YES];
    }
    else  if([tmpStr isEqualToString:@"提交失败！请重试" ])
     {
         UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:tmpStr delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
         [alertV show];
     }else
     {
         UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"出现系统错误，请稍后重试！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
         [alertV show];
     }
   
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(NSArray *)getDataBeforeLoad
{
    RequestKiss = [[NSNetRequestKiss alloc] init];
    NSArray *needURL = [[NSArray alloc] initWithObjects:@"http://w3c.ap01.aws.af.cm/workapply_checkDateType.action",@"http://w3c.ap01.aws.af.cm/spinner_projectName.action", nil];
    NSData *resData;
    NSURLResponse *res;
    NSError *error;
    NSData *workDate = [NSURLConnection sendSynchronousRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/workapply_makeWorkApply.action" AsyncOrSync:YES PostFormNetData:nil] returningResponse:&res error:&error];
    NSMutableArray *constArr = [[NSMutableArray alloc] init];
    for( int i = 0; i<[needURL count];i++)
    {
    NSData *workDate = [NSURLConnection sendSynchronousRequest:[RequestKiss PostFormNetURL:[needURL objectAtIndex:i] AsyncOrSync:YES PostFormNetData:nil] returningResponse:&res error:&error];
     NSArray * beforeDic = [NSJSONSerialization JSONObjectWithData:workDate options:NSJSONReadingMutableLeaves error:&error];
        [constArr addObject:beforeDic];
    }
    return constArr;
}
//输入的日期字符串形如：@"1992-05-21 13:08:08"

- (NSDate *)dateFromString:(NSString *)dateString{
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat: @"yyyy-MM-dd"];
    
    
    NSDate *destDate= [dateFormatter dateFromString:dateString];
    
    
    return destDate;
    
}
@end

//
//  CheckReportDetail.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-20.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "CheckReportDetail.h"

@interface CheckReportDetail ()

@end

@implementation CheckReportDetail
@synthesize cell0 = _cell0;
@synthesize cell1 = _cell1;
@synthesize cell2 = _cell2;
@synthesize cell3 = _cell3;
@synthesize cell4 = _cell4;
@synthesize cell5 = _cell5;
@synthesize headTitle = _headTitle;
@synthesize ObjectTitle = _ObjectTitle;
@synthesize SignObjectDay = _SignObjectDay;
@synthesize SignDay = _SignDay;
@synthesize DateLimit = _DateLimit;
@synthesize Approver = _Approver;
@synthesize State = _State;
@synthesize Note = _Note;
@synthesize DicDetail = _DicDetail;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = self.headTitle;
    // Do any additional setup after loading the view from its nib.
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"周明细" style:UIBarButtonItemStylePlain target:self action:@selector(Oper)];
    [self.navigationItem setRightBarButtonItem:rightItem animated:YES];
    cellContainer =[[NSArray alloc]  initWithObjects:
                    self.cell0,
                    self.cell1,
                    self.cell2,
                    self.cell3,
                    self.cell4,
                    self.cell5,
                    nil];
    RequestKiss= [[NSNetRequestKiss alloc] init];
    cellContainerHeight = [[NSArray alloc] initWithObjects:NSStringFromCGPoint(CGPointMake(0, self.cell0.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.cell1.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell2.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.cell3.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell4.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell5.frame.size.height)), nil];
    self.SignObjectDay.text = self.ObjectTitle;
    self.SignDay.text = [[self.DicDetail objectForKey:@"inputTime"] substringWithRange:NSMakeRange(0,16)];
    self.DateLimit.text = [self.DicDetail objectForKey:@"DateLimit"];
    self.Approver.text = [self.DicDetail objectForKey:@"acceptUserName"];
    self.State.text =[[RequestKiss readSqlite:@"07" sub:[self.DicDetail objectForKey:@"acceptStatus"]] objectForKey:[self.DicDetail objectForKey:@"acceptStatus"]];
    self.Note.text = [self.DicDetail objectForKey:@"Note"];
}
-(void)Oper
{
    WeekReportDetail *weekDetail = [[WeekReportDetail alloc] initWithNibName:@"WeekReportDetail" bundle:nil];
    weekDetail.workApplyNo = [[self.DicDetail objectForKey:@"workApplyNo"] intValue];
    [self.navigationController pushViewController:weekDetail animated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell  = [cellContainer  objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
     return  CGPointFromString([cellContainerHeight objectAtIndex:indexPath.row ]).y;
}
@end

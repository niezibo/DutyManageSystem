//
//  SignIn.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "SignIn.h"
#import "ASIFormDataRequest.h"
#import "HJManagedImageV.h"
#define UPLOAD_URL @"http://w3c.ap01.aws.af.cm/outworkcheckin_makeCheckinWithUpload.action"
#define REMOTE_URL @"http://w3c.ap01.aws.af.cm/"
@interface SignIn ()

@end

@implementation SignIn
@synthesize  cell1 = _cell1;
@synthesize  cell2= _cell2;
@synthesize  cell3 = _cell3;
@synthesize cell4 = _cell4;
@synthesize KissTable = _KissTable;
@synthesize HeadViewFace = _HeadViewFace;
@synthesize datapicker = _datapicker;
@synthesize mapMine =_mapMine;
@synthesize HeadView = _HeadView;
@synthesize state = _state;
@synthesize SigninWebview  =_SigninWebview;
@synthesize getPicText = _getPicText;
@synthesize userFace = _userFace;

//记录信息格式转化
@synthesize staffName;
@synthesize staffId;
@synthesize staffPosition;
@synthesize staffSignstate;
@synthesize staffSigntime;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
-(void)viewDidAppear:(BOOL)animated
{
    RequestKiss = [[NSNetRequestKiss alloc] init];
     Container = [[NSDictionary alloc] initWithDictionary:[RequestKiss readSqlite:@"09"]];
     NSURLResponse *res;
     NSError *error;

    
    NSURLRequest *req = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://w3c.ap01.aws.af.cm/"]];
    [self.SigninWebview loadRequest:req];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
     userDefault  = [[NSUserDefaults alloc] init];
    self.navigationItem.title = @"签到";

    Cells = [[NSArray alloc] initWithObjects:self.cell1,self.cell2,self.cell3,self.cell4, nil];
    CellsHeight = [[NSArray alloc] initWithObjects:
                 NSStringFromCGPoint(CGPointMake(0, self.cell1.frame.size.height))  ,
                   NSStringFromCGPoint(CGPointMake(0, self.cell2.frame.size.height))  ,
                   NSStringFromCGPoint(CGPointMake(0, self.cell3.frame.size.height))  ,
                    NSStringFromCGPoint(CGPointMake(0, self.cell4.frame.size.height))  ,
                nil];
    self.mapMine.layer.cornerRadius = 5.0;
    self.mapMine.mapType = MKMapTypeStandard;
    self.mapMine.delegate = self;
    self.mapMine.zoomEnabled = YES;
    self.mapMine.showsUserLocation = YES;
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter  =1000.0f;
    [locationManager startUpdatingLocation];
    UIBarButtonItem  *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"签到" style:UIBarButtonItemStylePlain target:self action:@selector(SignInKiss)];
    [self.navigationItem  setRightBarButtonItem:rightItem animated:YES];
    self.HeadViewFace.layer.cornerRadius = 5.0;
    self.staffSignstate.inputView   = self.datapicker;
    //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
    hero = 3;
    picArr = [[NSArray alloc] initWithObjects:@"从相机获得",@"从相册获得", nil];
    //获取头像
    NSString *urlStr = [NSString stringWithFormat:@"%@%@",REMOTE_URL,[userDefault objectForKey:@"uico"]];
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlStr]];
    self.userFace.image = [UIImage imageWithData:data];
    self.staffName.text = [userDefault objectForKey:@"userName"];
    self.staffId.text = [NSString stringWithFormat:@"%d", [[userDefault objectForKey:@"uid"] integerValue] ];
}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}

-(void)SignInKiss
{
    [self   uploadPortraitTask:picSource];
//    NSDictionary *staffName_yui = [[NSDictionary alloc] initWithObjectsAndKeys:self.staffName.text
//                                   ,@"staffName" ,nil];
//    NSDictionary *staffId_yui = [[NSDictionary alloc] initWithObjectsAndKeys:self.staffId.text
//                                   ,@"staffId", nil];
//    NSDictionary *staffPosition_yui = [[NSDictionary alloc] initWithObjectsAndKeys:self.staffPosition.text
//                                   ,@"staffPosition" ,nil];
//    NSDictionary *staffSigntime_yui = [[NSDictionary alloc] initWithObjectsAndKeys:self.staffSigntime.text
//                                   ,@"staffSigntime" ,nil];
//    NSDictionary *staffSignstate_yui = [[NSDictionary alloc] initWithObjectsAndKeys:self.staffSignstate.text
//                                       ,@"staffSignstate" ,nil];
//    NSArray *lastArr = [[NSArray alloc] initWithObjects:staffName_yui,staffId_yui,staffPosition_yui,staffSigntime_yui,staffSigntime_yui, nil];
//    if([NSJSONSerialization isValidJSONObject:lastArr]){
//        NSError *error_Kiss;
//        NSData *last = [NSJSONSerialization dataWithJSONObject:lastArr options:NSJSONWritingPrettyPrinted error:&error_Kiss];
//    }else{
//        NSLog(@"Error");
//
//    }
//    
//    ////////////////////////////////////////////
//    NSDateFormatter *fa = [[NSDateFormatter alloc] init];
//    [fa setDateFormat:@"yyyy-MM-dd hh:mm"];
//    userDefault  = [[NSUserDefaults alloc] init];
//    NSString *post = [NSString stringWithFormat:@"userId=%d&userName=%@&owc.checkinTime=%@&owc.checkinLongitude=%@&owc.checkinLatitude=%@&owc.CheckinType=%@",[[userDefault objectForKey:@"uid"] integerValue],[userDefault objectForKey:@"userName"],[fa stringFromDate:[NSDate date]],checkinLongitude,checkinLatitude,[Container objectForKey:self.staffSignstate.text]];
//    NSURLConnection *urlCon =[[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/outworkcheckin_makeCheckin.action" AsyncOrSync:YES PostFormNetData:post] delegate:self];
//    [urlCon start];
    
    /////////////////////////////////
    

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [Cells count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell = [Cells objectAtIndex:indexPath.row];
    if(indexPath.row == 2)
    {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if(indexPath.row == hero){
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   return   CGPointFromString( [CellsHeight objectAtIndex:indexPath.row]).y;
}
-(IBAction)gtePic:(id)sender
{

    imagePicker =[[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    imagePicker.allowsEditing = YES;
    [self  presentModalViewController:imagePicker animated:YES];
}
-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{
    self.view.transform = CGAffineTransformIdentity;
    CGAffineTransform tranform = CGAffineTransformMakeRotation(-1 * M_PI*newHeading.magneticHeading/180.0);
    self.view.transform = tranform;
}
-(void)mapViewWillStartLoadingMap:(MKMapView *)mapView
{
    float zoomLevel = 0.02;
    MKCoordinateRegion region = MKCoordinateRegionMake(mapView.centerCoordinate, MKCoordinateSpanMake(zoomLevel, zoomLevel));
    [self.mapMine setRegion:[self.mapMine regionThatFits:region] animated:YES];
    
    [self createAnnotationWIthCoords:mapView.centerCoordinate Flagtitle:@"我" Flagsubtitle:@"当前位置"];
   }
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(newLocation.coordinate, 1000, 1000);
    MKCoordinateRegion adjustRegion = [self.mapMine regionThatFits:viewRegion];
    [self.mapMine setRegion:adjustRegion animated:YES];
    //[self.activeView_Nie stopAnimating];
    [locationManager stopUpdatingLocation];
    MKReverseGeocoder *geocoder = [[MKReverseGeocoder alloc] initWithCoordinate:newLocation.coordinate];
   checkinLatitude =[NSString stringWithFormat:@"%f",newLocation.coordinate.latitude] ;
   checkinLongitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
    geocoder.delegate = self;
    [geocoder start];
    
    
}
//获得地址信息

//添加大头针
-(void)createAnnotationWIthCoords:(CLLocationCoordinate2D) coords Flagtitle:(NSString*) Maptitle Flagsubtitle:(NSString*) Mapsubtitle
{
    mapLocation *annotaion_Map = [[mapLocation alloc] initWithCoordinate: coords ];
    annotaion_Map.title = Maptitle ;
    annotaion_Map.subtitle = Mapsubtitle;
    [self.mapMine addAnnotation:annotaion_Map];
    [self.mapMine selectAnnotation:annotaion_Map animated:YES];
    NSDateFormatter *nf = [[NSDateFormatter alloc] init];
    [nf setDateFormat:@"yyyy-MM-dd hh:mm"];
    self.staffSigntime.text   = [nf stringFromDate:[NSDate date] ];
    
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return self.HeadView;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return  200;
}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return  [[Container allKeys] count];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.staffSignstate.text = [[Container allKeys]  objectAtIndex:row];
    hero = 2;
    [self.KissTable reloadData];
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{

    return [[Container allKeys]  objectAtIndex:row];
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //[vo autoChangeViewByKeyBoard:textField needView:self.view];
    CGRect frame = textField.frame;
    int offset = frame.origin.y +32 - (self.view.frame.size.height-216.0);
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"NOTHIDDEN" context:nil
     ];
    [UIView setAnimationDuration:animationDuration];
    if(offset <0)
    {
        self.view.frame = CGRectMake(0.0f, offset, self.view.frame.size.width, self.view.frame.size.height);
        
    }
    [UIView commitAnimations];
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:editingInfo];
    [dic setObject:image forKey:@"UIIImagePickerControllerEditedImage"];
    [self imagePickerController:imagePicker didFinishPickingMediaWithInfo:dic];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    if(picker ==imagePicker)
    {
        UIImage *original_image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        UIImageWriteToSavedPhotosAlbum(original_image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
                UIImage *editedImg = [info objectForKey:@"UIImagePickerControllerEditedImage"];
        UIImageView *imgView = [[UIImageView alloc] initWithImage:editedImg];
        [imgView setFrame:CGRectMake(107, 2, 40, 40)];
        [self.cell4.contentView addSubview: imgView];
        picSource = [[NSDictionary alloc] initWithDictionary:info];
        [self dismissModalViewControllerAnimated:YES];
    }
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}
- (void) image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSLog(@"error");
}
-(void)uploadPortraitTask:(NSDictionary *)info
{
    NSDateFormatter *fa = [[NSDateFormatter alloc] init];
    [fa setDateFormat:@"yyyy-MM-dd hh:mm"];
    NSURL *URL = [NSURL URLWithString:UPLOAD_URL];
    ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:URL];
    [Request setRequestMethod:@"POST"];
    [Request addRequestHeader:@"Content-Type" value:@"multipart/form-data"];
    [Request setTimeOutSeconds:10];
    UIImage *img = [vo scaleToSize:[info objectForKey:@"UIImagePickerControllerOriginalImage"] size:CGSizeMake(600, 600)];
    [Request setData:UIImagePNGRepresentation(img) forKey:@"fil.fileupload"];
    [Request setPostValue: [userDefault objectForKey:@"userName"] forKey:@"userName"];
    [Request setPostValue: [fa stringFromDate:[NSDate date]] forKey:@"owc.checkinTime"];
    [Request setPostValue: checkinLongitude forKey:@"owc.checkinLongitude"];
    [Request setPostValue: checkinLatitude forKey:@"owc.checkinLatitude"];
    [Request setPostValue: [userDefault objectForKey:@"uid"] forKey:@"userId"];
    [Request setPostValue: [Container objectForKey:self.staffSignstate.text] forKey:@"owc.CheckinType"];
    [Request setDelegate:self];
    [Request setCompletionBlock:^{
        NSString *responseString = [Request responseString];
        NSError *error = nil;
        NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:[Request responseData] options:NSJSONReadingMutableLeaves error:&error];
        NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"makeCheckinResult"] ];
        if([tmpStr isEqualToString:@"提交成功！"])
        {
            UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertV show];
        }else
        {
            [self.view makeToast:tmpStr];
            
        }
    }];
    [Request startAsynchronous];
    [Request setDidFinishSelector:@selector(uploadSuccess)];
    [Request setDidFailSelector:@selector(uploadFail)];
}
-(void)uploadSuccess
{

}
-(void)uploadFail
{

}
- (void)viewDidUnload {
    [self setCell4:nil];
    [self setGetPicText:nil];
    [self setUserFace:nil];
    [super viewDidUnload];
}
@end

//
//  MakeReport.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "MakeReport.h"

@interface MakeReport ()

@end

@implementation MakeReport
@synthesize Beginer =_Beginer;
@synthesize Ender = _Ender;
@synthesize fieldBeginer =_fieldBeginer;
@synthesize fieldEnder = _fieldEnder;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    Container = [[NSMutableArray  alloc] initWithArray:[self FormatDate:self.Beginer FormatDate_Kiss:self.Ender]];
    self.navigationItem.title = @"报告作成";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   return  [Container count];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
    }
    
    cell.textLabel.text=[[[ Container  objectAtIndex:indexPath.row] allKeys] objectAtIndex:0];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    // Configure the cell...
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    signinReport = [[ReportList alloc] initWithNibName:@"ReportList" bundle:nil];
    signinReport.Ticket= [[[ Container  objectAtIndex:indexPath.row] allKeys] objectAtIndex:0];
    NSCalendar *myCal = [[NSCalendar alloc] initWithCalendarIdentifier: NSGregorianCalendar];
    NSDateComponents *comp = [[NSDateComponents alloc] init];
    [comp setDay:self.Beginer+indexPath.row-1];
    NSDate *gotDate = [myCal dateByAddingComponents:comp  toDate:self.fieldBeginer options:0];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //设定时间格式,这里可以设置成自己需要的格式
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    //用[NSDate date]可以获取系统当前时间
    NSString *currentDateStr = [dateFormatter stringFromDate:gotDate];
    signinReport.WhichDay =  currentDateStr;
    [self.navigationController pushViewController:signinReport animated:YES];
}
-( NSArray *) FormatDate:(NSInteger)one FormatDate_Kiss:(NSInteger) two{
    NSMutableArray   *allKiss= [[NSMutableArray alloc] initWithCapacity:7];
    NSMutableDictionary *allDic = [[NSMutableDictionary alloc] initWithCapacity:7];
    for( int i = one;i<two+1;i++){
        switch (i%7) {
            case  1:
                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期一  (",i,@")"], nil]];
                break;
            case  2:
                                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期二  (",i,@")"], nil]];
                break;
            case  3:
                                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期三  (",i,@")"], nil]];
                break;
            case  4:
                                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期四  (",i,@")"], nil]];
                break;
            case  5:
                                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期五  (",i,@")"], nil]];
                break;
            case  6:
                                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期六  (",i,@")"], nil]];
                break;
            case  0:
                                [allKiss addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%d",i ] ,[NSString stringWithFormat:@"%@%d%@",@"星期日  (",i,@")"], nil]];
                break;
            default:
                break;
        }
    }
return allKiss;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
   
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}
@end

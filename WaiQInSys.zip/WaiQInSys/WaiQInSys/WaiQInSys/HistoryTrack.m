//
//  HistoryTrack.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "HistoryTrack.h"

@interface HistoryTrack ()

@end

@implementation HistoryTrack
@synthesize HeadView = _HeadView;
@synthesize timeBeginer = _timeBeginer;
@synthesize timeEnder = _timeEnder;
@synthesize reqUrl = _reqUrl;
@synthesize postData = _postData;
@synthesize listTable = _listTable;
@synthesize loadingView = _loadingView;
@synthesize loadingWebView = _loadingWebView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    userDefault = [[NSUserDefaults alloc] init];
    RequestKiss = [[NSNetRequestKiss alloc] init];
    // Do any additional setup after loading the view from its nib.
    [RequestKiss loadingAction:self.loadingWebView];
    self.navigationItem.title=@"历史追踪";
    [self.listTable addPullToRefreshWithActionHandler:^{
        [self.listTable.pullToRefreshView performSelector:@selector(stopAnimating) withObject:nil afterDelay:2];
    }];
    flag = 0;
    rootDic = [[NSMutableArray alloc] initWithCapacity:10];
            
        NSString *post = [NSString stringWithFormat:@"oa.userId=%d",[[userDefault objectForKey:@"uid"] integerValue]];
        NSURLConnection *Urlconn =   [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:self.reqUrl AsyncOrSync:YES PostFormNetData:self.postData] delegate:self];
        [Urlconn start];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [rootDic count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"HistoryCell";
    HistoryCell *cell_Kiss = (HistoryCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell_Kiss == nil) {
        NSArray *nib_Nie =  [[NSBundle mainBundle] loadNibNamed:@"HistoryCell" owner:self options:nil];
        cell_Kiss = [nib_Nie objectAtIndex:0];
    }
    
    // Configure the cell...
    cell_Kiss.TitleSup.text = [[rootDic objectAtIndex:indexPath.row]  objectForKey:@"workDate"];
    cell_Kiss.TitleSub.text = [[rootDic objectAtIndex:indexPath.row]  objectForKey:@"outWorkContent"];
    cell_Kiss.state.text =[[RequestKiss readSqlite:@"06" sub:[[rootDic objectAtIndex:indexPath.row]  objectForKey:@"applyStatus"]] objectForKey:[[rootDic objectAtIndex:indexPath.row]  objectForKey:@"applyStatus"] ];
    //applyStatus
    cell_Kiss.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell_Kiss;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ApplicationGoOut  *his = [[ApplicationGoOut alloc] initWithNibName:@"ApplicationGoOut" bundle:nil];
    //his.loadNUM = indexPath.row;
    his.justCheck = YES;
    his.checkDic = [rootDic objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:his animated:YES];
}
-(void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    flag = 1;
    deleteNo = indexPath.row;
    NSString *post = [NSString stringWithFormat:@"id=%d",[[[rootDic objectAtIndex:indexPath.row]  objectForKey:@"outWorkApplyNo"] integerValue]];
    NSURLConnection *Urlconn =   [[NSURLConnection alloc] initWithRequest: [RequestKiss  PostFormNetURL:@"http://w3c.ap01.aws.af.cm/outworkapply_deleteOutWorkApply.action" AsyncOrSync:YES PostFormNetData:post] delegate:self];
    [Urlconn start];
    
}
-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
     return @"撤回";
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    if(flag == 0)
    {
        rootDic = [[NSMutableArray alloc] initWithArray: [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error] ];
        [self.listTable reloadData];
        self.loadingView.hidden = YES;
        if([rootDic count]==0)
        {
            [self.view makeToast:@"历史追踪记录为空，请稍后重试"];
        }
    }else if(flag==1)
    {
        NSDictionary *tmpDic = [[NSMutableDictionary alloc] initWithDictionary:[NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error]];
        NSString *tmpMsg= [tmpDic objectForKey:@"deleteOutWorkApplyResult"];
        if([tmpMsg isEqualToString:@"撤回成功！"])
        {
               [rootDic removeObjectAtIndex:deleteNo];
               [self.listTable reloadData];
        }
        [self.view makeToast:tmpMsg];
    }
  
   }
@end

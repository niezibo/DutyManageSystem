//
//  HistoryDetailCell.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "HistoryDetailCell.h"

@implementation HistoryDetailCell
@synthesize CountLabel = _CountLabel;
@synthesize  WorkState =_WorkState;
@synthesize  WorkStateSecond =_WorkStateSecond;
@synthesize CheckTime = _CheckTime;
@synthesize Who = _Who;
@synthesize CheckState = _CheckState;
@synthesize WhoPosition = _WhoPosition;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  duty.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-11.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ApplicationGoOut.h"
#import "SignIn.h"
#import "HistoryTrackSearch.h"

@interface duty : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSDictionary *DutyList;
    ApplicationGoOut *GoOut;
    SignIn *Signin;
    HistoryTrackSearch *historyTrack;
}
-(IBAction)navitoSign:(id)sender;
-(IBAction)navitoApplicationGoOut:(id)sender;
-(IBAction)navitoHistoryTracker:(id)sender;
@end

//
//  ViewOperation.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-13.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define IOS_VERSION [[[UIDevice currentDevice] systemVersion] floatValue]
#import "ViewOperation.h"

@interface ViewOperation ()

@end

@implementation ViewOperation
@synthesize rootView = _rootView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)autoChangeViewByKeyBoard:(UITextField *)textField needView:(UIView *)root
{
    if(IOS_VERSION<5.0)
    {
        CGRect frame = textField.frame;
        int offset = frame.origin.y +32 - (root.frame.size.height-216.0);
        NSTimeInterval animationDuration = 0.30f;
        [UIView beginAnimations:@"NOTHIDDEN" context:nil
         ];
        [UIView setAnimationDuration:animationDuration];
        if(offset >0)
        {
            root.frame = CGRectMake(0.0f, -offset, root.frame.size.width, root.frame.size.height);
            [UIView commitAnimations];
        }
    }else
    {
        CGRect frame = textField.frame;
        int offset = frame.origin.y +32 - (root.frame.size.height-216.0);
        NSTimeInterval animationDuration = 0.30f;
        [UIView beginAnimations:@"NOTHIDDEN" context:nil
         ];
        [UIView setAnimationDuration:animationDuration];
        if(offset >0)
        {
            root.frame = CGRectMake(0.0f, -offset, root.frame.size.width, root.frame.size.height);
            [UIView commitAnimations];
        }
    }
}
-(BOOL)validateNotNil:(NSArray *)a  delegateView:(UIView *) b
{
    for(UITableViewCell *cell in a)
    {
        UITextField *errTextField = (UITextField*)[[[cell contentView] subviews] objectAtIndex:1];
        if([errTextField.text isEqualToString:@""])
        {
            UILabel *errorLabel =         (UILabel *)[[[cell contentView] subviews] objectAtIndex:0];
            [b makeToast:[NSString stringWithFormat:@"%@%@",errorLabel.text,@"不能为空"]  ];
            return NO;
        }

    }
return YES;
}
-(BOOL)validateNotNilTextField:(NSArray *)a  delegateView:(UIView *) b
{
    for(UITextField  *cell in a)
    {
        if([cell.text isEqualToString:@""])
        {
            [b makeToast:[NSString stringWithFormat:@"用户名密码不能为空",@"不能为空"]  ];
            return NO;
        }
        
    }
    return YES;
}
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size{
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(size);
    // 绘制改变大小的图片
    [img drawInRect:CGRectMake(0,0, size.width, size.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage =UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    //返回新的改变大小后的图片
    return scaledImage;
}
@end

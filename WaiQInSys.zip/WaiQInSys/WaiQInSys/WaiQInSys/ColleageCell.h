//
//  ColleageCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-22.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColleageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *colleageIco;
@property (nonatomic, retain) IBOutlet UILabel *colleageId;
@property (nonatomic, retain) IBOutlet UILabel *colleageName;
@property (nonatomic, retain) IBOutlet UILabel *colleageDuty;
@property (nonatomic, retain) IBOutlet UILabel *colleagePhone;
@property (nonatomic, retain) IBOutlet UIImageView *colleageFace;
@end

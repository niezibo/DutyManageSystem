//
//  CheckReport.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckReportDetail.h"
#import "CheckReportCell.h"
#import "NSNetRequestKiss.h"
#import "ToastUIView.h"

@interface CheckReport : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSString *path;
    NSMutableDictionary *ReportContainer;
    NSMutableArray *ReportContainerArr;
    NSNetRequestKiss *RequestKiss;
    NSMutableData *receiveData ;
    int diff;
    int deleteNo;
    NSMutableDictionary *resMsg;
}
@property (weak, nonatomic) IBOutlet UITableView *listTable;
@property (nonatomic, retain) IBOutlet NSString *urlPost;
@property (strong, nonatomic) IBOutlet UIView *editView;
@property (nonatomic, retain) IBOutlet NSString *urlData;
@property (nonatomic, retain) IBOutlet NSString *researchTitle;
@property (weak, nonatomic) IBOutlet UIView *loadingView;
@property (weak, nonatomic) IBOutlet UIWebView *loadingWebView;
@property (strong, nonatomic) IBOutlet UITableViewCell *operLable;

@end

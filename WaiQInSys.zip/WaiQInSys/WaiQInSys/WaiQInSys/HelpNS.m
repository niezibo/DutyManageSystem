//
//  HelpNS.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-21.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "HelpNS.h"

@implementation HelpNS
@synthesize year = _year;
@synthesize month = _month;
@synthesize vv = _vv;
int day=0;				//保存当月的天数;
int week=0;				//保存当前是星期几;
bool boolear = NO;	//判断该年是否闰年;
int daysum = 0;			//总天数;
int days=0;
int weeksOfMonth=1;  //某月有几周

int j=2;

-(id) WeekOfMonth:(int)year MonthofWeek:(int)month {
    if(self == [super init])
    {
        self.year = year;
        
        self.month = month;
    }
    return self;
    
}
-(void) initer{
    if(self.year%400==0||(self.year%4==0&&self.year%100!=0))  //判断是否闰年;
		
        
    {
        boolear = true;
    }
    for (int i = 1900; i < self.year; i++)
    {
        if (i%4==0&&i%100!=0||i%400==0)
        {
            daysum+=366;
        }
        else
        {
            daysum+=365;
        }
    }
    for(int j=1;j<=self.month;j++)
    {
        switch(j)
        {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:day=31;break;
                
			case 4:
			case 6:
			case 9:
			case 11:day=30;break;
                
			case 2:
				if(boolear)
				{
					day=29;
					break;
				}
				else
				{
					day=28;
					break;
				}
        }
        if(j<self.month)
        {
            days+=day;
        }
    }
    daysum+=days;
    week = (1+daysum)%7;
}
-(int)gethowmanyweeks{
    [self initer];
    for (int i = 1; i <= day; i++)
    {
        //控制每到星期6就换行
        //原理为总天数加上当月天数对7取余
        
        if ((daysum + i) % 7 == 6 && i!=day)
            weeksOfMonth++;
        
    }
    return weeksOfMonth;
}
-(NSMutableArray*) getfromto:(int) weekth{
    [self initer];
    NSMutableArray *result = [[NSMutableArray alloc] initWithCapacity:2];
   // int[] result=new int[2];
    for (int i = 1; i <= day; i++)
    {
        
        //控制每到星期6就换行
        if ((daysum + i) % 7 == 6) {
            if(weekth==1){
                result[0] =  [NSString stringWithFormat:@"%d",1];
                result[1]= [NSString stringWithFormat:@"%d",i];
                break;
            }
            
            if(weekth==j){
               result[0] =  [NSString stringWithFormat:@"%d",(i+1)];
				
                if(i+7<day){
                     result[1]= [NSString stringWithFormat:@"%d",(i+7)];
                    
                }else{
                    result[1]= [NSString stringWithFormat:@"%d",day];
					
                }
                break;
			}
            j++;
		}
		
	}
    return result;
}
-(void)init_Son:(UIView*)a{

      self.vv = a;
      UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
      [tap setNumberOfTapsRequired:1];
      [self.vv addGestureRecognizer:tap];

}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}
@end

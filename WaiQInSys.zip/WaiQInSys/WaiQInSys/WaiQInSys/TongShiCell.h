//
//  TongShiCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-4.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TongShiCell : UITableViewCell

@property  (nonatomic,retain) IBOutlet UIView *LocationView;
@property (nonatomic, retain) IBOutlet UIView *NumberView;

@property (nonatomic, retain) IBOutlet UILabel *CheckName;
@property (nonatomic, retain) IBOutlet UILabel *CheckNumber;
@property (nonatomic, retain) IBOutlet UILabel *CheckLocation;
@property (nonatomic, retain) IBOutlet UILabel *CheckLocationTime;
@end

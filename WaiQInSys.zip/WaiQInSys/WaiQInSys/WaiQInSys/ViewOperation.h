//
//  ViewOperation.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-13.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ToastUIView.h"
@interface ViewOperation : UIViewController
-(void)autoChangeViewByKeyBoard:(UITextField *)textField needView:(UIView *)root;
-(BOOL)validateNotNil:(NSArray *)a  delegateView:(UIView *) b;
-(BOOL)validateNotNilTextField:(NSArray *)a  delegateView:(UIView *) b;
- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size;
@property (nonatomic,retain) IBOutlet UIView *rootView;
@end

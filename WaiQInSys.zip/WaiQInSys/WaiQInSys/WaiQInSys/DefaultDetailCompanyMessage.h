//
//  DefaultDetailCompanyMessage.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-7.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface DefaultDetailCompanyMessage : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    NSString *path;
    UITableViewCell *TitleCell;
    UITableViewCell *MsgThemeCell;
    UITableViewCell *MsgerCell;
    UITableViewCell *MsgTimerCell;
    UITableViewCell *MsgDetailCell;
    NSDictionary *MsgList;
    NSArray*MsgSquare;
    NSDictionary *allKiss;
    NSArray *Container;
    NSArray *labelPanel;
}
@property (nonatomic, retain) IBOutlet NSDictionary *containerCell;
@property (nonatomic, retain) IBOutlet UILabel *DetailTitle;
@property (nonatomic, retain) IBOutlet UILabel *DetailMsg;
@property (weak, nonatomic) IBOutlet UILabel *publisher;
@property (weak, nonatomic) IBOutlet UILabel *pubtime;
@property (weak, nonatomic) IBOutlet UILabel *pubclass;
@property (weak, nonatomic) IBOutlet UITableViewCell *cell1;
@property (weak, nonatomic) IBOutlet UITableViewCell *cell2;
@property (weak, nonatomic) IBOutlet UITableViewCell *cell3;
@property (weak, nonatomic) IBOutlet UITableViewCell *cell4;
@property (weak, nonatomic) IBOutlet UITableViewCell *cell5;

@end

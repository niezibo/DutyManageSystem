//
//  DefaultMessageCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-11.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultMessageCell : UITableViewCell

@end

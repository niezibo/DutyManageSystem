//
//  HistoryTrackSearch.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryTrack.h"
#import "ViewOperation.h"
#import "ToastUIView.h"
@interface HistoryTrackSearch : UIViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    NSArray *Container;
        NSUserDefaults *userDefault;
        ViewOperation *vo;
}
@property (strong, nonatomic) IBOutlet UITableViewCell *TimeBeginer;
@property (strong, nonatomic) IBOutlet UITableViewCell *TimeEnder;
@property (strong, nonatomic) IBOutlet UITableViewCell *allKiss;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepickerSecond;
@property (weak, nonatomic) IBOutlet UITextField *DateBegin;
@property (weak, nonatomic) IBOutlet UITextField *DateEnd;

@end

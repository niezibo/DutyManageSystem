
//
//  CompanyMessageCell.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-4.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "CompanyMessageCell.h"

@implementation CompanyMessageCell

@synthesize mianTitle = _mianTitle;
@synthesize mianMsg = _mianMsg;
@synthesize pubMan = _pubMan;
@synthesize pubTime = _pubTime;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
       
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

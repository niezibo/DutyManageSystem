//
//  dutyReport.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MakeReport.h"
#import <QuartzCore/QuartzCore.h>
#import "HelpNS.h"
#import "NSNetRequestKiss.h"
#import <sqlite3.h>

@interface dutyReport : UIViewController <UITabBarDelegate,UITableViewDataSource ,UIPickerViewDelegate, UIPickerViewDataSource>
{
    NSArray *tmp_Nie;
    NSString  *path;
    NSMutableDictionary *WorKDic;
    NSMutableDictionary *SecondWorKDic;
    NSArray   *WorkArr;
    NSArray   *SecondWorkArr;
    HelpNS *helpNS;
    NSMutableArray *scroolWheelArr;
    int Weeks;
    int  hero;

    
    
    NSArray *Container;
    MakeReport *re;
    NSNetRequestKiss *RequestKiss;
    int projectId;
    int itemId;
    NSString *beginDate;
    NSString *endDate;
    NSArray *allDataNet;
    sqlite3 *db;
    NSMutableDictionary *dutyArr;
    NSUserDefaults *userDefault ;
}

@property (strong, nonatomic) IBOutlet UIPickerView *WeeksInMonth;
@property (nonatomic, retain) IBOutlet UITextField *SelectText;
@property (nonatomic, retain) IBOutlet UITextField *InputText;
@property (nonatomic, retain) IBOutlet UITextField *ItemText;
@property (nonatomic, retain) IBOutlet UITextField *DutyText;
@property (strong, nonatomic) IBOutlet UITableViewCell *ChooseWeek;
@property (strong, nonatomic) IBOutlet UITableViewCell *ShowTime;
@property (strong, nonatomic) IBOutlet UITableViewCell *JoinPro;
@property (strong, nonatomic) IBOutlet UITableViewCell *DutyServe;
@property (strong , nonatomic)IBOutlet NSMutableData   *receiveData;
-(IBAction)SlideDown:(id)sender;
-(IBAction)fillDataforDatePicker:(id)sender;
-(IBAction)fillDataforDatePickerItem:(id)sender;
-(IBAction)fillDataforDatePickerDuty:(id)sender;
@end

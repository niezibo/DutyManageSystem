//
//  HistoryCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *state;

@property (nonatomic , retain) IBOutlet UILabel *TitleSup;
@property (nonatomic , retain) IBOutlet UILabel *TitleSub;
@end

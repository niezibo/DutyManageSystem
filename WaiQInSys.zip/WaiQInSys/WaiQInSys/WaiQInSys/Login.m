


//
//  Login.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-25.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "Login.h"
#import "AppDelegate.h"

@interface Login ()
@end
@implementation Login
@synthesize password_Nie = _password_Nie;
@synthesize LoginBgsecond = _LoginBgsecond;
@synthesize textFieldView_Nie;
@synthesize toolBarForHidden  = _toolBarForHidden;
@synthesize username_Nie = _username_Nie;
@synthesize receiveData = _receiveData;
@synthesize loadingView = _loadingView;
@synthesize loadingUIView = _loadingUIView;
@synthesize loadingText = _loadingText;
@synthesize autoLogin = _autoLogin;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
 
        
    }
    return self;
}

-(void)dealloc
{
    userInfo = nil;
    statues = nil;
}


-(void)  resetButton
{
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
        [self.navigationItem setHidesBackButton:YES];
        self.navigationItem.title = @"外勤小灵通";
        userDefault = [[NSUserDefaults   alloc] init];
   
        if([userDefault objectForKey:@"un"] != NULL && [userDefault objectForKey:@"up"]!= NULL)
        {
            if([userDefault objectForKey:@"autologin"]==NULL)
            {
                [userDefault setObject:@"0" forKey:@"autologin"];
            }else
            {
                if(self.autoLogin.isOn)
                {
                    [userDefault setObject:@"1" forKey:@"autologin"];
                    self.username_Nie.text = [userDefault objectForKey:@"un"] ;
                    self.password_Nie.text =[userDefault objectForKey:@"up"] ;
                }
            }
        }
    [self.autoLogin addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    // Do any additional setup after loading the view from its nib.
    self.password_Nie.secureTextEntry = YES;
    _LoginBgsecond.layer.cornerRadius =10.0;
    _LoginBgsecond.layer.shadowOffset = CGSizeMake(0, 3);
    _LoginBgsecond.layer.shadowOpacity = 0.8;
    textFieldView_Nie.layer.cornerRadius = 10.0;
    textFieldView_Nie.backgroundColor = [UIColor grayColor];
    textFieldView_Nie.layer.bounds =CGRectMake(0, 0, 280, 150);
    textFieldView_Nie.layer.opacity =0.1 ;
    self.tabBarController.tabBar.hidden = YES;
    self.loadingUIView.hidden = YES;
    [self loadingAction];
    colContainer = [[NSArray alloc] initWithObjects:self.username_Nie,self.password_Nie, nil];
}

-(void)switchValueChanged:(id)sender
{
    UISwitch* control = (UISwitch*)sender;
    if(control == self.autoLogin){
        BOOL on = control.on;
        //添加自己要处理的事情代码
        if(on)
        {   [  userDefault setObject:@"1" forKey:@"autologin"];
            self.username_Nie.text = [userDefault objectForKey:@"un"] ;
            self.password_Nie.text =[userDefault objectForKey:@"up"] ;
        }else
        {
             [userDefault setObject:@"0" forKey:@"autologin"];
        }
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)LoginContinue:(id)sender
{
    if([vo validateNotNilTextField:colContainer  delegateView:self.view])
    {
        NSString *post = [NSString stringWithFormat:@"userAccount=%@&userPassword=%@",self.username_Nie.text,self.password_Nie.text];
        RequestKiss = [[NSNetRequestKiss alloc] init];
        NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/user_login.action" AsyncOrSync:YES PostFormNetData:post]delegate:self];
        [urlConnection start];
        self.loadingUIView.hidden = NO;
    }
   
}

-(IBAction)Edit_nie:(id)sender
{
     [self.username_Nie resignFirstResponder];
     [self.password_Nie resignFirstResponder];
}

//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    self.loadingText.text =@"正在登录..."; 
    
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.loadingText.text =@"认证成功...";
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{   
    NSError *error = nil;
    NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:self.receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"loginResult"] ];
    NSString *lll = [[NSString alloc] initWithData:self.receiveData encoding:NSUTF8StringEncoding];
    if([tmpStr  isEqualToString:@"fail"])
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"用户名密码错误。" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        self.loadingUIView.hidden = YES;
    }else
    {

        
        [userDefault setObject:self.username_Nie.text forKey:@"un"];
        [userDefault setObject:self.password_Nie.text forKey:@"up"];
        [userDefault setObject:[rootDic objectForKey:@"userId"] forKey:@"uid"];
        [userDefault setObject:[rootDic objectForKey:@"userIco"] forKey:@"uico"];
        [userDefault setObject:[rootDic objectForKey:@"userName"] forKey:@"userName"];
        [userDefault setObject:[rootDic objectForKey:@"telNo"] forKey:@"telNo"];
        [userDefault setObject:[rootDic objectForKey:@"homeAddress"] forKey:@"homeAddress"];
         [userDefault setObject:[rootDic objectForKey:@"birthDay"] forKey:@"birthDay"];
        [userDefault setObject:[rootDic objectForKey:@"emailAddress"] forKey:@"emailAddress"];
        [userDefault setObject:[rootDic objectForKey:@"postCode"] forKey:@"postCode"];
        [userDefault setObject:[rootDic objectForKey:@"dutyKind"] forKey:@"dutyKind"];
        [userDefault setObject:[rootDic objectForKey:@"sexKind"] forKey:@"sexKind"];
        [userDefault setObject:[rootDic objectForKey:@"remarkColumn"] forKey:@"remarkColumn"];
        DefaultMessage *Index = [[DefaultMessage alloc]  initWithNibName:@"DefaultMessage" bundle:nil];
        [self.navigationController pushViewController:Index  animated:YES];
    }

}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    self.loadingUIView.hidden = YES;

}
-(void)loadingAction{
    NSData *gifFile = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"loading42" ofType:@"gif"]];
    //设置WebView是透明的
   // self.loadingView.backgroundColor = [UIColor clearColor];
    self.loadingView.scrollView.bounces = NO;
    self.loadingView.scrollView.scrollEnabled = NO;
    [self.loadingView loadData:gifFile MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];

    
}
@end
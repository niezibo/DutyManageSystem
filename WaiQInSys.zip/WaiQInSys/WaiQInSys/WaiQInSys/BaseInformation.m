//
//  BaseInformation.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-12.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "BaseInformation.h"
#import "ASIFormDataRequest.h"
#define REMOTEURL @"http://w3c.ap01.aws.af.cm/"
#define UPLOAD_URL @"http://w3c.ap01.aws.af.cm/user_updateFaceIco.action"
@interface BaseInformation ()

@end

@implementation BaseInformation
@synthesize defaultTableView = _defaultTableView;
@synthesize UserName_Nie = _UserName_Nie;
@synthesize SubLabel_Nie  = _SubLabel_Nie;
@synthesize FaceCandy  = _FaceCandy;

@synthesize duty;
@synthesize department;
@synthesize cellphone;
@synthesize telephone;
@synthesize email;
@synthesize workPosition;
@synthesize myhome;
@synthesize birth;
@synthesize notes;
@synthesize dutyTextField;
@synthesize departmentTextField;
@synthesize cellphoneTextField;
@synthesize emailTextField;
@synthesize workPositionTextField;
@synthesize myhomeTextField;
@synthesize birthTextField;
@synthesize sexKind = _sexKind;
@synthesize noteTextField;
@synthesize datepicker = _datepicker;
@synthesize datapicker = _datapicker;
@synthesize loadingView = _loadingView;
@synthesize loadingWebView = _loadingWebView;
@synthesize userFace = _userFace;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    RequestKiss = [[NSNetRequestKiss alloc] init];
     dutyArr   = [[NSMutableDictionary alloc] initWithDictionary:[RequestKiss readSqlite:@"04"]];
    WorKDic  = [[NSMutableDictionary alloc] initWithCapacity:10];
    postArr = [[NSArray alloc] initWithArray:[RequestKiss getPostJson]];
    sexDic = [[NSDictionary alloc] initWithDictionary:[RequestKiss readSqlite:@"01"]];
    for (NSDictionary *dic in postArr)
    {
        [WorKDic setValue:[dic objectForKey:@"postCode"] forKey:[dic objectForKey:@"postName"]];
    }
    // Do any additional setup after loading the view from its nib.
    First = [[NSArray alloc] initWithObjects:self.department,self.duty, nil];
    Second = [[NSArray alloc] initWithObjects:self.telephone,self.cellphone, nil];

    Third= [[NSArray alloc] initWithObjects:self.email, nil];

    Forth= [[NSArray alloc] initWithObjects:self.workPosition,self.myhome, nil];

    Fiveth= [[NSArray alloc] initWithObjects:self.birth,self.notes, nil];
    BaseCell = [[NSMutableDictionary alloc] initWithObjectsAndKeys:First,@"First",Second,@"Second",Third,@"Third",Forth,@"Forth",Fiveth, @"Fiveth",nil];
    Container = [[NSArray alloc] initWithObjects:self.departmentTextField,self.dutyTextField,self.cellphoneTextField,self.sexKind,self.emailTextField,self.birthTextField,self.workPositionTextField,self.myhome,self.noteTextField, nil];
    //进行美化
    self.UserName_Nie.font = [UIFont fontWithName:@"Microsoft Yahei" size:16 ];
    self.SubLabel_Nie.font = [UIFont fontWithName:@"Microsoft Yahei" size:14 ];
    Edit_Msg = [[UIBarButtonItem alloc] initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(BeginEdit_Kiss)];
    [self.navigationItem setRightBarButtonItem:Edit_Msg animated:YES];
    for(UITextField *tf in Container)
    {
        tf.userInteractionEnabled = NO;
    }
    self.birthTextField.inputView = self.datepicker;
    self.departmentTextField.inputView = self.datapicker;
    self.dutyTextField.inputView = self.datapicker;
    [self loadingAction];
    girl = YES;

    userDefault  =  [[NSUserDefaults alloc] init];
    NSString *post = [NSString  stringWithFormat:@"userId=%d",[[userDefault objectForKey:@"uid"] integerValue]];
    NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/user_checkPersonalInformation.action" AsyncOrSync:YES PostFormNetData:post]delegate:self];
    [urlConnection start];
    //点击图片，可以更新头像
    UITapGestureRecognizer *face = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(updateFaceIco:)];
    [face setNumberOfTapsRequired:1];
    [self.FaceCandy addGestureRecognizer:face];
    //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}
-(void)updateFaceIco:(UITapGestureRecognizer *)sender
{
    imagePicker =[[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    imagePicker.allowsEditing = YES;
    [self  presentModalViewController:imagePicker animated:YES];

}
-(void)BeginEdit_Kiss
{
    [self.defaultTableView setEditing:YES animated:YES];
    Edit_Msg.title = @"保存";
    Edit_Msg.action = @selector(EndEdit_Kiss);
    for(UITextField *tf in Container)
    {
        tf.userInteractionEnabled = YES;
        girl = NO;
        
    }
    

    
}
-(void)EndEdit_Kiss
{
    NSString *post = [NSString stringWithFormat:@"user.userId=%d&user.userName=%@&user.postCode=%@&user.dutyKind=%@&user.sexKind=%@&user.telNo=%@&user.remarksColumn=%@&user.birthDay=%@&user.emailAddress=%@&user.homeAddress=%@&user.updateUserid=%@&user.updateTime=%@",[[userDefault objectForKey:@"uid"] integerValue],[userDefault objectForKey:@"userName"],[WorKDic objectForKey:self.departmentTextField.text],[dutyArr objectForKey:self.dutyTextField.text],[sexDic objectForKey:self.sexKind.text],self.cellphoneTextField.text,self.noteTextField.text,self.birthTextField.text,self.emailTextField.text,self.myhomeTextField.text,[userDefault objectForKey:@"uid"],[RequestKiss timeConvert:[NSDate date]]];
    NSURLConnection *conUrl = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/user_updatePersonalInformation.action" AsyncOrSync:YES PostFormNetData:post] delegate:self];
    [conUrl start];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return [BaseCell count];
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(section==0){
        UIView *FaceView = [[UIView alloc] initWithFrame:CGRectMake(0, 20, 320, 80)];
        [FaceView addSubview:self.FaceCandy];
            return FaceView;
    }else{
        return nil;
    }



}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    
    return [[BaseCell objectForKey:[[BaseCell allKeys] objectAtIndex:section] ] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    NSInteger *section = indexPath.section;
    NSString *key  =[[BaseCell allKeys] objectAtIndex:section];
    cell = [[BaseCell objectForKey:key] objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section ==0){
        return 110;
    }else
    {
        return 10;
    }
}
//滚轮显示的列数
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
//当前列下的显示条数
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if(hero==0){
        return [WorKDic  count];
    }else if(hero==1){
        return  [dutyArr count];
    }else  if(hero ==2)
    {
        return [sexDic count];
    }
    
}
//显示当前行的内容
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if(hero==0){
        return [[WorKDic allKeys] objectAtIndex:row];
    }else if(hero==1){
        return  [[dutyArr allKeys] objectAtIndex:row] ;
    }else if(hero ==2)
    {
        return  [[sexDic allKeys] objectAtIndex:row];
    }
    
    
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
   if(hero==0){
       self.departmentTextField.text =  [[WorKDic allKeys] objectAtIndex:row];
    }else if (hero==1){
        self.dutyTextField.text = [[dutyArr allKeys] objectAtIndex:row];
    }else if(hero ==2)
    {
        self.sexKind.text = [[sexDic allKeys] objectAtIndex:row];
    }

}
-(IBAction)fillDataforDatePickerItem:(id)sender
{       hero=0;

    [self.datapicker reloadAllComponents];
    
}
-(IBAction)fillDataforDatePickerDuty:(id)sender
{
    if(self.departmentTextField.text == NULL){
        UIAlertView *alertView  = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请先选择所属部门" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil,nil];
        [alertView show];
    }else{
        hero = 1;
        [self.datapicker  reloadAllComponents];
        
    }
    
    
}
-(IBAction)fillDataforDatePickerSex:(id)sender
{
    hero = 2;
    [self.datapicker  reloadAllComponents];

}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    /// self.loadingText.text =@"正在登录...";
    
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //  self.loadingText.text = @"认证成功...";
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    self.receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
     rootDic = [NSJSONSerialization JSONObjectWithData:self.receiveData options:NSJSONReadingMutableLeaves error:&error];
    if(girl)
    {
        NSString *urlStr = [NSString stringWithFormat:@"%@%@",REMOTEURL,[rootDic objectForKey:@"userIco"]];
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlStr]];
        self.userFace.image = [UIImage imageWithData:data];
        self.UserName_Nie.text = [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"userName"]];
        self.noteTextField.text = [rootDic objectForKey:@"remarkColumn"];
        self.dutyTextField.text =  [[RequestKiss readSqlite:@"04" sub:[rootDic objectForKey:@"dutyKind"]] objectForKey:[rootDic objectForKey:@"dutyKind"] ];
        for (NSDictionary *dic in postArr)
        {
            if([dic objectForKey:@"postCode"] == [rootDic objectForKey:@"postCode"])
            {
                    self.departmentTextField.text = [dic objectForKey:@"postName"];
            }
        }

        self.birthTextField.text =[ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"birthDay"]];
        self.emailTextField.text = [ NSString stringWithFormat:@"%@",[rootDic objectForKey:@"emailAddress"]];
        self.myhomeTextField.text = [ NSString stringWithFormat:@"%@",[rootDic objectForKey:@"homeAddress"]];
        for (int i = 0; i<[sexDic count];i++)
        {
            if([[sexDic objectForKey:[[sexDic allKeys] objectAtIndex:i] ] isEqualToString:[rootDic objectForKey:@"sexKind"] ])
            {
                self.sexKind.text =[[sexDic allKeys] objectAtIndex:i];
            }
        }
        self.cellphoneTextField.text = [ NSString stringWithFormat:@"%@",[rootDic objectForKey:@"telNo"]];
        
        [UIView beginAnimations:nil context:nil];
        //设定动画持续时间
        [UIView setAnimationDuration:2];
        self.loadingView.hidden = YES;
         [UIView commitAnimations];
    }else
    {
        [self.defaultTableView setEditing:NO animated:YES];
        Edit_Msg.title = @"编辑";
        Edit_Msg.action = @selector(BeginEdit_Kiss);
        for(UITextField *tf in Container)
        {
            tf.userInteractionEnabled = NO;
            
        }
        NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"updatePersonalInformationResult"] ];
        NSString *lll = [[NSString alloc] initWithData:self.receiveData encoding:NSUTF8StringEncoding];
        if([tmpStr  isEqualToString:@"修改成功！"])
        {
            UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:tmpStr  delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertV show];
        }else
        {
            UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"用户信息修改失败！" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertV show];
        }

    }
        
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(void)loadingAction{
    NSData *gifFile = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"loadinginfo" ofType:@"gif"]];
    //设置WebView是透明的
     self.loadingWebView.backgroundColor = [UIColor clearColor];
    self.loadingWebView.scrollView.bounces = NO;
    self.loadingWebView.scrollView.scrollEnabled = NO;
    [self.loadingWebView loadData:gifFile MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];
    
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    //[vo autoChangeViewByKeyBoard:textField needView:self.view];
    CGRect frame = textField.frame;
    int offset = frame.origin.y +32 - (self.view.frame.size.height-216.0);
    NSLog(@"%d",offset);
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"NOTHIDDEN" context:nil
     ];
    [UIView setAnimationDuration:animationDuration];
    if(offset <0)
    {
        self.view.frame = CGRectMake(0.0f, offset, self.view.frame.size.width, self.view.frame.size.height);
        
    }
    [UIView commitAnimations];
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:editingInfo];
    [dic setObject:image forKey:@"UIIImagePickerControllerEditedImage"];
    [self imagePickerController:imagePicker didFinishPickingMediaWithInfo:dic];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    if(picker ==imagePicker)
    {
        UIImage *original_image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        UIImageWriteToSavedPhotosAlbum(original_image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
        UIImage *editedImg = [info objectForKey:@"UIImagePickerControllerEditedImage"];      
  
        picSource = [[NSDictionary alloc] initWithDictionary:info];
        [self dismissModalViewControllerAnimated:YES];
        [self uploadPortraitTask:info];
    }
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];
}
- (void) image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSLog(@"error");
}
-(void)uploadPortraitTask:(NSDictionary *)info
{
    NSDateFormatter *fa = [[NSDateFormatter alloc] init];
    [fa setDateFormat:@"yyyy-MM-dd hh:mm"];
    NSURL *URL = [NSURL URLWithString:UPLOAD_URL];
    ASIFormDataRequest *Request = [ASIFormDataRequest requestWithURL:URL];
    [Request setRequestMethod:@"POST"];
    [Request addRequestHeader:@"Content-Type" value:@"multipart/form-data"];
    [Request setTimeOutSeconds:10];
    UIImage *img = [vo scaleToSize:[info objectForKey:@"UIImagePickerControllerOriginalImage"] size:CGSizeMake(256, 256)];
    [Request setData:UIImagePNGRepresentation(img) forKey:@"fil.fileupload"];
    [Request setPostValue: [NSString stringWithFormat:@"%d",[[userDefault objectForKey:@"uid"] integerValue]]forKey:@"userId"];
    [Request setDelegate:self];
    [Request setCompletionBlock:^{
        NSString *responseString = [Request responseString];
        NSDictionary *result = [NSJSONSerialization JSONObjectWithData:[Request responseData] options:NSJSONReadingMutableLeaves error:nil];
        [self.view makeToast:[result objectForKey:@"updateuserfaceResult"]];
        if([[result objectForKey:@"updateuserfaceResult"] isEqualToString:@"头像更新成功" ])
        {
                  self.userFace.image = img;
        }
    }];
    [Request startAsynchronous];
    [Request setDidFinishSelector:@selector(uploadSuccess)];
    [Request setDidFailSelector:@selector(uploadFail)];
}
-(void)uploadSuccess
{
    
}
-(void)uploadFail
{
    
}
- (void)viewDidUnload {
        [self setUserFace:nil];
        [super viewDidUnload];

}
@end
//
//  Suggest.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-13.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "Suggest.h"

@interface Suggest ()

@end

@implementation Suggest
@synthesize cell1 = _cell1;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    vo = [[ViewOperation alloc] init];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"投诉建议";
    cellContainer =[[NSArray alloc]  initWithObjects:
                    self.cell1,
                    nil];
    cellContainerHeight = [[NSArray alloc] initWithObjects:NSStringFromCGPoint(CGPointMake(0, self.cell1.frame.size.height)), nil];
    UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc]     initWithTitle:@"提交" style: UIBarButtonItemStylePlain target:self action:@selector(Oper)];
    [self.navigationItem setRightBarButtonItem:rightBtn animated:YES];
}
-(void)Oper{
    UIAlertView *alertLikejs = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"你的建议已经计较成功，我们会针对您提出的问题，进行改进以满足您的需求。" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    
    cell  = [cellContainer  objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{      return  CGPointFromString([cellContainerHeight objectAtIndex:indexPath.row ]).y;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    
}
@end

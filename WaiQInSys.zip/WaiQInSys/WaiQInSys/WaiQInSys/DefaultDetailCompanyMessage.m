//
//  DefaultDetailCompanyMessage.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-7.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "DefaultDetailCompanyMessage.h"

@interface DefaultDetailCompanyMessage ()

@end

@implementation DefaultDetailCompanyMessage
@synthesize DetailMsg = _DetailMsg;
@synthesize DetailTitle = _DetailTitle;
@synthesize pubclass = _pubclass;
@synthesize publisher = _publisher;
@synthesize pubtime  = _pubtime;
@synthesize cell1 = _cell1;
@synthesize cell2 = _cell2;
@synthesize cell3 = _cell3;
@synthesize cell4 = _cell4;
@synthesize cell5 = _cell5;
@synthesize containerCell =_containerCell;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    Container = [[NSArray alloc] initWithObjects:self.cell1,self.cell2,self.cell3,self.cell4,self.cell5, nil];
    //禁止对多行文本框UITextView进行编辑
    self.DetailMsg.userInteractionEnabled = NO;
    self.DetailMsg.layer.cornerRadius = 3.0;
    self.navigationItem.title = @"公告详情";
    [self.DetailTitle sizeToFit];
    [self.DetailMsg sizeToFit];
    [self.publisher sizeToFit];
    [self.pubtime sizeToFit];
    [self.pubclass sizeToFit];
    if([self.containerCell objectForKey:@"tulTitle"] != nil)
        
    {
        self.DetailTitle.text = [self.containerCell objectForKey:@"tulTitle"];
        self.DetailMsg.text = [self.containerCell objectForKey:@"tulContents"];

    }
    else
    {
        self.DetailTitle.text = [self.containerCell objectForKey:@"inforTitle"];
        self.DetailMsg.text = [self.containerCell objectForKey:@"inforContents"];
    }

    self.publisher.text = [self.containerCell objectForKey:@"userName"];
    self.pubtime.text = [self.containerCell objectForKey:@"inputTime"];
    self.pubclass.text = [self.containerCell objectForKey:@"inputTime"];
    labelPanel = [[NSArray alloc] initWithObjects:self.DetailTitle, self.publisher,self.pubtime,self.pubclass,self.DetailMsg,nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"SimpleDataItem";
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        
        NSArray *nib_Nie = [[NSBundle mainBundle] loadNibNamed:@"CompanyMessageCell" owner:self options:nil];
        cell = [nib_Nie objectAtIndex:0];
    }
    cell = [Container objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  5;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==4 ||indexPath.row==0 )
    {
        NSString *cellText =[(UILabel*)[labelPanel objectAtIndex:indexPath.row] text];
        UIFont *cellFont = [UIFont fontWithName:@"Helvetica" size:17.0];
        CGSize constraintSize = CGSizeMake(280.0f,9999);
        CGSize labelSize = [cellText sizeWithFont:cellFont constrainedToSize:constraintSize lineBreakMode:UILineBreakModeCharacterWrap];
        [(UILabel*)[labelPanel objectAtIndex:indexPath.row] setFrame:CGRectMake(10, 11, 280, labelSize.height)];
        [(UILabel*)[labelPanel objectAtIndex:indexPath.row] setNumberOfLines:0];
        return labelSize.height + 20;
    }else
    {
        NSString *cellText =[(UILabel*)[labelPanel objectAtIndex:indexPath.row] text];
        UIFont *cellFont = [UIFont fontWithName:@"Helvetica" size:17.0];
        CGSize constraintSize = CGSizeMake(200.0f,9999);
        CGSize labelSize = [cellText sizeWithFont:cellFont constrainedToSize:constraintSize lineBreakMode:UILineBreakModeCharacterWrap];
        [(UILabel*)[labelPanel objectAtIndex:indexPath.row] setFrame:CGRectMake(90, 11, 100, labelSize.height)];
        [(UILabel*)[labelPanel objectAtIndex:indexPath.row] setNumberOfLines:0];

        return 44;
    }

}
@end

//
//  CheckReportSearch.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckReport.h"
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"
#import "ToastUIView.h"
@interface CheckReportSearch : UIViewController <UITableViewDataSource,UITableViewDelegate, UIPickerViewDataSource,UIPickerViewDelegate>
{
    NSArray *Container;
    NSArray *chooseOption;
    CheckReport *checkReprot;
    NSNetRequestKiss *RequestKiss;
    NSDictionary *codeContainer;
    NSArray   *urlContainer;
   int *indexUrl;
    NSUserDefaults *userDefault;
    ViewOperation *vo;
}
@property (weak, nonatomic) IBOutlet UITextField *timeBegin;
@property (weak, nonatomic) IBOutlet UITextField *timeEnd;
@property (strong, nonatomic) IBOutlet UITableViewCell *Applytime;
@property (strong, nonatomic) IBOutlet UITableViewCell *ApplytimeEnd;
@property (strong, nonatomic) IBOutlet UITableViewCell *Applyoption;
@property (strong, nonatomic) IBOutlet UITableViewCell *allKiss;
@property (strong, nonatomic) IBOutlet UIPickerView *datapicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker1;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker2;
@property (strong, nonatomic) IBOutlet UITextField *optionField;
@end

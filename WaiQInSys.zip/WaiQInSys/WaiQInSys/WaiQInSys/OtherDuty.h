//
//  OtherDuty.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface OtherDuty : UIViewController<UITableViewDelegate, UITableViewDataSource,UIPickerViewDataSource,UIPickerViewDelegate>
{
    NSArray *cellContainer;
    NSArray *cellContainerHeight;
    NSArray *Container;
    NSUserDefaults *userDefault;
}
@property (strong, nonatomic) IBOutlet UITableViewCell *cell01;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell02;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell03;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell1;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell2;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell3;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell4;
@property (nonatomic,retain)  IBOutlet UIView    *KissView;
@property (weak, nonatomic) IBOutlet UITextField *chooseOption;
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *userId;
@property (strong, nonatomic) IBOutlet UIPickerView *datapicker;
@end

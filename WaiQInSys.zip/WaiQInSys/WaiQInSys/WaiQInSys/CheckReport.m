//
//  CheckReport.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "CheckReport.h"

@interface CheckReport ()

@end

@implementation CheckReport
@synthesize urlPost = _urlPost;
@synthesize urlData = _urlData;
@synthesize listTable = _listTable;
@synthesize researchTitle = _researchTitle;
@synthesize editView  = _editView;
@synthesize loadingView = _loadingView;
@synthesize loadingWebView = _loadingWebView;
@synthesize operLable = _operLable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    RequestKiss= [[NSNetRequestKiss alloc] init];
    NSURLConnection *urlConn = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:self.urlPost AsyncOrSync:YES PostFormNetData:self.urlData] delegate:self];
    [urlConn start];
    // Do any additional setup after loading the view from its nib.
    ReportContainerArr = [[NSMutableArray alloc] initWithCapacity:10];
    self.navigationItem.title = @"查看";
    diff = 0;
    resMsg = [[NSMutableDictionary alloc] initWithCapacity:1];
    [self.loadingView setHidden:NO];
    [RequestKiss loadingAction:self.loadingWebView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [ ReportContainerArr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    CheckReportCell *cell = (CheckReportCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle]  loadNibNamed:@"CheckReportCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    // Configure the cell...
    cell.leftTitle.text = self.researchTitle;
    cell.editingAccessoryView = self.editView;
    if([ self.researchTitle isEqualToString:@"休假申请"])
    {
        cell.startDate.text =[[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"startTime"];
        cell.endDate.text = [[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"endTime"];
    }else
    {
        cell.startDate.text =[[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"startDate"];
        cell.endDate.text = [[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"endDate"];
        if( [[[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"applyStatus"] isEqualToString:@"00"]&&[[[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"acceptStatus"] isEqualToString:@"00"])
        {
                cell.applyState.text = [[ReportContainerArr objectAtIndex:indexPath.row]  objectForKey:@"applyStatus"];
        }else
        {
        
        }

    }

    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CheckReportDetail *reportDetail = [[CheckReportDetail alloc]  initWithNibName:@"CheckReportDetail" bundle:nil];
    reportDetail.headTitle = self.researchTitle;
    if([ self.researchTitle isEqualToString:@"休假申请"])
    {
        reportDetail.ObjectTitle = [NSString stringWithFormat:@"%@%@%@",[[[ReportContainerArr objectAtIndex:indexPath.row] objectForKey:@"startTime"] substringWithRange:NSMakeRange(0,10)] ,@"~",[[[ReportContainerArr objectAtIndex:indexPath.row] objectForKey:@"endTime"] substringWithRange:NSMakeRange(0,10)]];
    }else
    {
    reportDetail.ObjectTitle = [NSString stringWithFormat:@"%@%@%@",[[ReportContainerArr objectAtIndex:indexPath.row] objectForKey:@"startDate"],@"-",[[ReportContainerArr objectAtIndex:indexPath.row] objectForKey:@"endDate"]];
    }
    reportDetail.DicDetail = [ReportContainerArr objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:reportDetail animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *all = [[UIView alloc] initWithFrame:CGRectMake(00, 0, 320, 10)];
    all.layer.backgroundColor = [UIColor clearColor].CGColor;
    return all;
}
-(void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSURLConnection *urlconn ;
    NSString *post;
    if([self.researchTitle isEqualToString:@"勤务申请"])
    {
        post = [NSString stringWithFormat:@"workApplyNo=%d",[[[ReportContainerArr objectAtIndex:indexPath.row] objectForKey:@"workApplyNo"] integerValue]];
        urlconn = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/workapply_deleteWorkApply.action" AsyncOrSync:YES PostFormNetData:post] delegate:self];

    }
    else if([self.researchTitle isEqualToString:@"休假申请"])
    {
        post = [NSString stringWithFormat:@"vacationApplyNo=%d",[[[ReportContainerArr objectAtIndex:indexPath.row] objectForKey:@"vacationApplyNo"] integerValue]];
        urlconn = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/vacationapply_deleteVacationApply.action" AsyncOrSync:YES PostFormNetData:post] delegate:self];
    }
            [urlconn start];
    deleteNo  = indexPath.row;
    diff = 1;
    self.operLable.text = @"撤回中";
    [self.loadingView setHidden:NO];
}
-(NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
     return @"撤回";
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    if(diff ==0)
    {
    ReportContainerArr =[[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error]];
    
    }else if(diff ==1)
    {
        diff = 0;
        resMsg =[[NSMutableDictionary alloc] initWithDictionary:[NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error]];
                [self.loadingView setHidden:YES];
        if([ self.researchTitle isEqualToString:@"勤务申请"])
        {
            if([[resMsg objectForKey:@"deleteWorkApplyResult"] isEqualToString:@"此勤务报告不在撤回范围内！"])
            {
                UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[resMsg objectForKey:@"deleteWorkApplyResult"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertV show];
            }else
            {
                UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[resMsg objectForKey:@"deleteWorkApplyResult"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertV show];
                [ReportContainerArr removeObjectAtIndex:deleteNo];
            }
        }else if([ self.researchTitle isEqualToString:@"休假申请"])
        {
            if([[resMsg objectForKey:@"deleteVacationApplyResult"] isEqualToString:@"此休假申请不在撤回范围内！"])
            {
                UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[resMsg objectForKey:@"deleteVacationApplyResult"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertV show];
            }else
            {
                UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[resMsg objectForKey:@"deleteVacationApplyResult"] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertV show];
                [ReportContainerArr removeObjectAtIndex:deleteNo];
            }
        }
        
       
        
    }
    
    [self.listTable reloadData];
    [self.loadingView setHidden:YES];
    if([[self.listTable indexPathsForVisibleRows] count]==0)
    {
        [self.view makeToast:@"勤务历史为空，请稍后重试"];
    }
    
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
- (void)viewDidUnload {
    [self setEditView:nil];
    [self setLoadingView:nil];
    [self setLoadingWebView:nil];
    [self setOperLable:nil];
    [super viewDidUnload];
}
@end

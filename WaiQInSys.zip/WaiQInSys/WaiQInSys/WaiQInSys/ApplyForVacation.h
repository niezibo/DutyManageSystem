//
//  ApplyForVacation.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"
@interface ApplyForVacation : UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>
{
    NSArray *cellContainer;
    NSArray *cellContainerHeight;
    
    NSArray *optionSource;
    NSUserDefaults * userDefault;
    NSNetRequestKiss *RequestKiss;
    NSArray *ProjectJson;
    NSInteger *proIndex;
    NSInteger *codeIndex;
    NSDictionary *codeDic;
    NSInteger ball;
    NSMutableData *receiveData;
        ViewOperation *vo;
}

@property (strong, nonatomic) IBOutlet UITableViewCell *cell01;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell02;

@property (nonatomic,retain) IBOutlet UITableViewCell *cell1;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell2;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell3;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell4;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell5;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell6;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell7;
@property (nonatomic,retain)  IBOutlet UIView    *KissView;
@property (nonatomic,retain)  IBOutlet UIPickerView   *kissPicker;
@property (strong, nonatomic) IBOutlet UIPickerView *projectPicker;
@property (weak, nonatomic) IBOutlet UITextField *projectField;
@property (strong, nonatomic) IBOutlet UIDatePicker *beginTime;
@property (strong, nonatomic) IBOutlet UIDatePicker *endTime;
@property (weak, nonatomic) IBOutlet UITextField *beginTimeField;
@property (weak, nonatomic) IBOutlet UITextField *endTimeField;
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *userId;

@property (weak, nonatomic) IBOutlet UITextView *conVacation;
@property (nonatomic,retain)  IBOutlet UITextField    *chooseOption;
@end

//
//  OtherDuty.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "OtherDuty.h"

@interface OtherDuty ()

@end

@implementation OtherDuty
@synthesize cell01 = _cell01;
@synthesize cell02 = _cell02;
@synthesize cell03 = _cell03;
@synthesize cell1 = _cell1;
@synthesize cell2 = _cell2;
@synthesize cell3 = _cell3;
@synthesize cell4 = _cell4;
@synthesize KissView = _KissView;
@synthesize datapicker = _datapicker;
@synthesize chooseOption = _chooseOption;
@synthesize userName  = _userName;
@synthesize userId = _userId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    userDefault = [[NSUserDefaults alloc] init];
    
        self.navigationItem.title = @"时间外勤务";
    // Do any additional setup after loading the view from its nib.
    cellContainer =[[NSArray alloc]  initWithObjects:
                    self.cell01,
                    self.cell02,
                    self.cell03,
                    self.cell1,
                    self.cell2,
                    self.cell3,
                    self.cell4,
                     nil];
    cellContainerHeight = [[NSArray alloc] initWithObjects:NSStringFromCGPoint(CGPointMake(0, self.cell01.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell02.frame.size.height)),
                           NSStringFromCGPoint(CGPointMake(0, self.cell03.frame.size.height)),
                           NSStringFromCGPoint(CGPointMake(0, self.cell1.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell2.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.cell3.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.cell4.frame.size.height)), nil];
    Container = [[NSArray alloc] initWithObjects:@"加班",@"休日出勤", nil];
      self.KissView.layer.cornerRadius = 5.0;
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(Oper) ];
    [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
    self.chooseOption.inputView = self.datapicker;
    self.userName.text = [userDefault objectForKey:@"userName"];
    self.userId.text = [NSString stringWithFormat:@"%d", [[userDefault objectForKey:@"uid"] integerValue] ];
     //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 7;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell  = [cellContainer  objectAtIndex:indexPath.row];
    if(indexPath.row==2 || indexPath.row ==3 || indexPath.row ==4){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{      return  CGPointFromString([cellContainerHeight objectAtIndex:indexPath.row ]).y;
}
-(void)Oper
{

}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
   return  [Container count];
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [Container objectAtIndex:row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.chooseOption.text = [Container objectAtIndex:row];
}
@end

//
//  Setting.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-13.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "Setting.h"

@interface Setting ()

@end

@implementation Setting
@synthesize trackInteval = _trackInteval;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"注销" style:UIBarButtonItemStylePlain target:self action:@selector(Oper) ];
    [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
    // Do any additional setup after loading the view from its nib.
    personInfo = [[BaseInformation alloc] initWithNibName:@"BaseInformation" bundle:nil];
    modifyPw = [[ModifyPassword alloc] initWithNibName:@"ModifyPassword" bundle:nil];
    about = [[About alloc] initWithNibName:@"About" bundle:nil];
    suggestMine = [[Suggest alloc] initWithNibName:@"Suggest" bundle:nil];
    Container_Nie = [[NSArray alloc] initWithObjects:personInfo ,modifyPw,about,suggestMine, nil];
    personInfo.title = @"个人信息";
     modifyPw.title =  @"修改密码";
     about.title=    @"其他设置";
    suggestMine.title = @"投诉建议";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==0)
    {
    [self.navigationController pushViewController:[Container_Nie objectAtIndex:indexPath.row] animated:YES];
    }
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    if(indexPath.section == 0)
    {
        cell.textLabel.text = [[Container_Nie objectAtIndex:indexPath.row]  title];
        cell.accessoryType  = UITableViewCellAccessoryDetailDisclosureButton;
    }else if(indexPath.section ==1)
    {
        cell = self.trackInteval;
    }
   
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section ==0)
    {
    return [Container_Nie count];
    }else if(section==1)
    {
        return 1;
    }
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(void) Oper
{   userDefault   = [[NSUserDefaults alloc] init];
    [userDefault setObject:NULL forKey:@"un"];
    [userDefault setObject:NULL forKey:@"up"];
    Login *loginBack = [[Login alloc]  initWithNibName:@"Login" bundle:nil];
    
    [self.navigationController pushViewController:loginBack animated:NO];
}
@end

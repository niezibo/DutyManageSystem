//
//  colleageLocation.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-2.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "colleageLocation.h"


@interface colleageLocation ()

@end

@implementation colleageLocation
@synthesize longi = _longi;
@synthesize lati = _lati;
@synthesize mapMine = _mapMine;
@synthesize colleageName = _colleageName;
@synthesize locationName = _locationName;
@synthesize locationView = _locationView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.mapMine.mapType = MKMapTypeStandard;
    self.mapMine.delegate = self;
    self.mapMine.zoomEnabled = YES;
    self.mapMine.showsUserLocation = YES;
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter  =800.0f;
    [locationManager startUpdatingLocation];
    ///
    NSURLRequest *req = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://w3c.ap01.aws.af.cm/"]];
    [self.locationView loadRequest:req];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)mapViewWillStartLoadingMap:(MKMapView *)mapView
{
        CLLocationCoordinate2D coords = CLLocationCoordinate2DMake(self.lati,self.longi);
        self.mapMine.centerCoordinate =coords;
        
        float zoomLevel = 0.02;
        MKCoordinateRegion region = MKCoordinateRegionMake(mapView.centerCoordinate, MKCoordinateSpanMake(zoomLevel, zoomLevel));
        [self.mapMine setRegion:[self.mapMine regionThatFits:region] animated:YES];

            [self createAnnotationWithCoords:coords Flagtitle:self.colleageName Flagsubtitle:self.locationName];
    [locationManager stopUpdatingLocation];
    
}
//添加大头针
-(void)createAnnotationWithCoords:(CLLocationCoordinate2D) coords Flagtitle:(NSString*) Maptitle Flagsubtitle:(NSString*) Mapsubtitle
{
    mapLocation *annotaion_Map = [[mapLocation alloc] initWithCoordinate: coords ];
    annotaion_Map.title = Maptitle ;
    annotaion_Map.subtitle = Mapsubtitle;
    [self.mapMine addAnnotation:annotaion_Map];
    [self.mapMine selectAnnotation:annotaion_Map animated:YES];
    
}
@end

//
//  MyTabBarController.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-8.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTabBarController : UITabBarController

@end

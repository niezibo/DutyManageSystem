//
//  ApplicationGoOut.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//
#define kDEFAULT_DATE_TIME_FORMAT (@"yyyy-MM-dd")

#import "ApplicationGoOut.h"
@interface ApplicationGoOut ()

@end

@implementation ApplicationGoOut
@synthesize justCheck=_justCheck;
@synthesize checkDic = _checkDic;
@synthesize Cell0 = _Cell0;
@synthesize Cell1 = _Cell1;
@synthesize Cell2 = _Cell2;
@synthesize Cell3 = _Cell3;
@synthesize Cell4 = _Cell4;
@synthesize Cell5 = _Cell5;
@synthesize Cell6 = _Cell6;
@synthesize Cell7 = _Cell7;
@synthesize Cell8 = _Cell8;
@synthesize Cell9 = _Cell9;
@synthesize departmentChoose;

@synthesize datapicker  = _datapicker;
@synthesize datepicker0  = _datepicker0;
@synthesize datepicker  = _datepicker;
@synthesize datepicker1  = _datepicker1;
@synthesize timeForgooutYear;
@synthesize timeForgooutMonth;
@synthesize timeForgooutDay;
@synthesize timeForapplyYear;
@synthesize timeForapplyMonth;
@synthesize timeForapplyDay;
@synthesize Applier;
@synthesize reasonforGoout;
@synthesize timeForapply = _timeForapply;
@synthesize timeForgoout = _timeForgoout;
@synthesize ApplierKiss = _ApplierKiss;
@synthesize ApplyTitle = _ApplyTitle;
@synthesize DepartmentBelong = _DepartmentBelong;
@synthesize StartPlace = _StartPlace;
@synthesize EndPlace = _EndPlace;
@synthesize ApplyId = _ApplyId;
@synthesize timeForgooutBegin = _timeForgooutBegin;
@synthesize timeForgooutEnd = _timeForgooutEnd;
@synthesize acceptState = _acceptState;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
   
}
- (void)viewDidLoad
{
    [super viewDidLoad];
     vo = [[ViewOperation alloc] init];
   
    self.navigationItem.title = @"外出申请表";
    CellContainer = [[NSArray alloc] initWithObjects:
                     self.Cell1,
                     self.Cell2,
                     self.Cell3,
                     self.Cell4,
                     self.Cell5,
                     self.Cell6,
                     self.Cell7,
                     self.Cell8,
                     self.Cell9,
                     self.Cell0,nil];
    // Do any additional setup after loading the view from its nib.
     cellContainerHeight = [[NSArray alloc] initWithObjects: NSStringFromCGPoint(CGPointMake(0, self.Cell1.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.Cell2.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.Cell3.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.Cell4.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.Cell5.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.Cell6.frame.size.height)), NSStringFromCGPoint(CGPointMake(0, self.Cell7.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.Cell8.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.Cell9.frame.size.height)),NSStringFromCGPoint(CGPointMake(0, self.Cell0.frame.size.height)),nil];
    RequestKiss =[[NSNetRequestKiss alloc] init];
    ProjectJson = [[NSArray alloc] initWithArray:[RequestKiss  getProjectJson]];
    userDefault = [[NSUserDefaults alloc] init];
    self.ApplierKiss.text = [userDefault objectForKey:@"userName"];
    self.ApplyId.text = [NSString stringWithFormat:@"%d", [[userDefault objectForKey:@"uid"] integerValue] ];
    if(self.justCheck)
    {
        UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"签到状态" style:UIBarButtonItemStylePlain target:self action:@selector(checkHistorySign) ];
        [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
        self.timeForapply.text =[self.checkDic objectForKey:@"workDate"] ;
        self.timeForgooutBegin.text = [self.checkDic objectForKey:@"startTime"];
        self.timeForgooutEnd.text = [self.checkDic objectForKey:@"endTime"];
        self.StartPlace.text = [self.checkDic objectForKey:@"startPos"];
        self.EndPlace.text = [self.checkDic objectForKey:@"endPos"];
        self.reasonforGoout.text = [self.checkDic objectForKey:@"outWorkContent"];
        NSString *accpetStatus = [self.checkDic objectForKey:@"acceptStatus"];
        self.acceptState.text =[[RequestKiss readSqlite:@"07" sub:accpetStatus] objectForKey:accpetStatus];
        NSDictionary *proInfo = [RequestKiss projectJsonOne:[[self.checkDic objectForKey:@"projectNo"] integerValue]];
        NSLog(@"%d",[proInfo count]);
        self.DepartmentBelong.text = [ proInfo objectForKey:@"projectName"];
    }else
    {
        UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"提交" style:UIBarButtonItemStylePlain target:self action:@selector(Oper) ];
        [self.navigationItem setRightBarButtonItem:rightBarButton animated:YES];
    }
    self.timeForapply.inputView = self.datepicker0;
    self.timeForgooutBegin.inputView = self.datepicker;
    self.timeForgooutEnd.inputView = self.datepicker1;
    self.DepartmentBelong.inputView = self.datapicker;
    [self.datepicker0 addTarget:self action:@selector(DateSignChange:) forControlEvents:UIControlEventValueChanged];
    [self.datepicker addTarget:self action:@selector(DateBeginChange:) forControlEvents:UIControlEventValueChanged];
    [self.datepicker1 addTarget:self action:@selector(DateEndChange:) forControlEvents:UIControlEventValueChanged];
    //添加点击屏幕，键盘隐藏
    UITapGestureRecognizer *rootTapScreen = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rootTap:)];
    [rootTapScreen setNumberOfTapsRequired:1];
    [self.view addGestureRecognizer:rootTapScreen];
}
-(void)DateSignChange:(id)sender{
    UIDatePicker *one = (UIDatePicker*)sender;
    NSDate *oneData = one.date;
    self.timeForapply.text = [self NSDateToNSString:oneData];
    
}
-(void)DateBeginChange:(id)sender{
    UIDatePicker *one = (UIDatePicker*)sender;
    NSDate *oneData = one.date;
    self.timeForgooutBegin.text = [self NSDateToNSString:oneData];
    
}
-(void)DateEndChange:(id)sender{
    UIDatePicker *two = (UIDatePicker*)sender;
    NSDate *twoData = two.date;
    self.timeForgooutEnd.text = [self NSDateToNSString:twoData];
    
}
-(NSString * )NSDateToNSString: (NSDate * )date
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: kDEFAULT_DATE_TIME_FORMAT];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}
-(void)rootTap:(UITapGestureRecognizer*)sender
{
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
}
-(void)Oper
{
   if([vo validateNotNil:CellContainer delegateView:self.view])
   {
       
       userDefault = [[NSUserDefaults alloc] init];
       NSString *post = [NSString stringWithFormat:@"userId=%d&oa.projectNo=%d&oa.workDate=%@&oa.startTime=%@&oa.endTime=%@&oa.acceptTime=%@&oa.startPos=%@&oa.endPos=%@&oa.outWorkContent=%@",[[userDefault objectForKey:@"uid"] integerValue],[[[ProjectJson objectAtIndex:proIndex] objectForKey:@"projectNo"] integerValue],self.timeForapply.text,self.timeForgooutBegin.text,self.timeForgooutEnd.text,@"2013-04-01 08:30:00",self.StartPlace.text,self.EndPlace.text,self.reasonforGoout.text];
       NSURLConnection *urlCon =[[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/outworkapply_makeOutWorkApply.action" AsyncOrSync:YES PostFormNetData:post] delegate:self]  ;
       [urlCon start];
   }

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [CellContainer count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...

    cell = [CellContainer objectAtIndex:indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
//退出键盘
-(IBAction)ExitInput:(id)sender
{
    [Applier resignFirstResponder];
    [departmentChoose resignFirstResponder];
    [reasonforGoout resignFirstResponder];
}
//输入前清空
-(IBAction)beginEditClear:(id)sender
{
    self.departmentChoose.text = nil;

}
-(IBAction)beginUserDatapicker:(id)sender
{

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CGPointFromString([cellContainerHeight objectAtIndex:indexPath.row ]).y;
}
//滚轮显示的列数
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
//当前列下的显示条数
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [ProjectJson  count];
}
//显示当前行的内容
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
     return [[ProjectJson objectAtIndex:row] objectForKey:@"projectName"];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.DepartmentBelong.text = [[ProjectJson objectAtIndex:row] objectForKey:@"projectName"];
    proIndex = row;
}

//查看历史签到状态
-(void)checkHistorySign
{
    histor  = [[HistoryDetailViewController alloc] initWithNibName:@"HistoryDetailViewController" bundle:nil];
    histor.loadNUM = [[self.checkDic  objectForKey:@"outWorkApplyNo"] integerValue];
    [self.navigationController pushViewController:histor animated:YES];
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    //  self.loadingText.text =@"正在登录...";
    NSLog(@"正在提交中");
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    // self.loadingText.text =@"认证成功...";
    NSLog(@"获得回应");
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"接受数据中");
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error = nil;
    NSDictionary * rootDic = [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSString *tmpStr =  [ NSString stringWithFormat:@"%@", [rootDic objectForKey:@"makeOutWorkApplyResult"] ];
    if([tmpStr isEqualToString:@"提交成功！"])
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        [self.navigationController dismissModalViewControllerAnimated:YES];
    }else
    {
        UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:[NSString  stringWithFormat:@"%@",tmpStr] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertV show];
        
    }
    
    
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
 //[vo autoChangeViewByKeyBoard:textField needView:self.view];
    CGRect frame = textField.frame;
    int offset = frame.origin.y +32 - (self.view.frame.size.height-216.0);
    NSLog(@"%d",offset);
    NSTimeInterval animationDuration = 0.30f;
    [UIView beginAnimations:@"NOTHIDDEN" context:nil
     ];
    [UIView setAnimationDuration:animationDuration];
    if(offset <0)
    {
        self.view.frame = CGRectMake(0.0f, offset, self.view.frame.size.width, self.view.frame.size.height);

    }
            [UIView commitAnimations];

}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
}
@end

//
//  WeekReportDetail.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-16.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "WeekReportDetail.h"

@interface WeekReportDetail ()

@end

@implementation WeekReportDetail
@synthesize workApplyNo =_workApplyNo;
@synthesize weekDetailTable = _weekDetailTable;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"一周勤务明细";
    ResquestKiss = [[NSNetRequestKiss alloc] init];
    weekDetail = [[NSMutableArray alloc] initWithCapacity:10];
    NSString *Post = [NSString stringWithFormat:@"workApplyNo=%d",self.workApplyNo];
    NSURLConnection *conn = [NSURLConnection connectionWithRequest:[ResquestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/workapply_checkWeekWorkApply.action" AsyncOrSync:YES PostFormNetData:Post ] delegate:self];
    [conn start];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [weekDetail count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    WeekReportDetailCell *cell = (WeekReportDetailCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle]  loadNibNamed:@"WeekReportDetailCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    cell.weekDay.text = [[weekDetail objectAtIndex:indexPath.row] objectForKey:@"workDate"];
    cell.weekDayDate.text =[[weekDetail objectAtIndex:indexPath.row] objectForKey:@"workDate"];
    cell.DutyClass.text = [[ResquestKiss readSqlite:@"05" sub:[[weekDetail objectAtIndex:indexPath.row] objectForKey:@"workType"]] objectForKey:[[weekDetail objectAtIndex:indexPath.row] objectForKey:@"workType"]];
    cell.onDutyTime.text =[[weekDetail objectAtIndex:indexPath.row] objectForKey:@"startTime"];
    cell.offDutyTime.text =[[weekDetail objectAtIndex:indexPath.row] objectForKey:@"endTime"];
    return cell;
}
-(void) connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    NSLog(@"Begin Send");
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    weeDetailData = data;
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error;
    weekDetail = [NSJSONSerialization JSONObjectWithData:weeDetailData options:NSJSONReadingMutableLeaves error:&error];
    [self.weekDetailTable reloadData];
}
- (void)viewDidUnload {
    [self setWeekDetailTable:nil];
    [super viewDidUnload];
}
@end

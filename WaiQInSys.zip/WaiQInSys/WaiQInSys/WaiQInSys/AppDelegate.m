//
//  AppDelegate.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-25.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "AppDelegate.h"
//#import "Login.h"
@implementation AppDelegate


@synthesize window = _window;
@synthesize rootController;

//生命周期函数  与其他语言是异曲同工
-(void) dealloc{
    //[sinaweibo release];
    //[_window   release];
    ////[_login_Nie release];
   // [super dealloc];
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    if([self isCameraAvailable]){
        NSLog(@"Camera is available");
    }else
    {
        NSLog(@"Camera is not available");
    }
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.  
     //加载信息页面
    DefaultMessage *message_Nie = [[DefaultMessage alloc]  initWithNibName:@"DefaultMessage" bundle:nil];
    UINavigationController *messageNaviControll = [[UINavigationController alloc] initWithRootViewController:message_Nie];
    [[messageNaviControll navigationBar] setTintColor:[UIColor orangeColor]];
    message_Nie.title = @"消息通知";
    UIImage *img1 = [UIImage imageNamed:@"Message.png"];
    [message_Nie.tabBarItem initWithTitle:@"消息通知" image:img1  tag:1];
    //加载外出勤务
    duty *duty_Nie = [[duty alloc] initWithNibName:@"duty" bundle:nil];
    UINavigationController *dutyControll = [[UINavigationController alloc] initWithRootViewController:duty_Nie];
    [[dutyControll navigationBar] setTintColor:[UIColor orangeColor]];

    duty_Nie.title=@"外出勤务";
    UIImage *img2 = [UIImage imageNamed:@"DutyOut.png"];
    [duty_Nie.tabBarItem initWithTitle:@"外出勤务" image:img2 tag:2];
    //外出勤务
    ApplyForDuty *apply = [[ApplyForDuty alloc] initWithNibName:@"ApplyForDuty" bundle:nil];
    UINavigationController *applyController = [[UINavigationController alloc]  initWithRootViewController:apply];
    [[applyController navigationBar] setTintColor:[UIColor orangeColor]];
    apply.title = @"勤务申请";
    UIImage *img3 = [UIImage imageNamed:@"DutyApply.png"];
    [apply.tabBarItem initWithTitle:@"勤务申请" image:img3 tag:3];
    //加载周边同事页面
    Colleague *tongshi_Nie = [[Colleague alloc] initWithNibName:@"Colleague" bundle:nil ];
    UINavigationController *tongshiControll = [[UINavigationController alloc]  initWithRootViewController:tongshi_Nie];
     [[tongshiControll navigationBar] setTintColor:[UIColor orangeColor]];
    tongshi_Nie.title = @"周边同事";
    UIImage *img4 = [UIImage imageNamed:@"Colleage.png"];
    [tongshi_Nie.tabBarItem initWithTitle:@"周边同事" image:img4 tag:4];
    
    //系统设置
    Setting *OpSetting = [[Setting alloc] initWithNibName:@"Setting" bundle:nil];
    UINavigationController *settingControll = [[UINavigationController alloc] initWithRootViewController:OpSetting];
   [[settingControll navigationBar] setTintColor:[UIColor orangeColor]];
    OpSetting.title = @"系统设置";
    UIImage *img5 = [UIImage imageNamed:@"Setting.png"];
    [OpSetting.tabBarItem initWithTitle:@"系统设置" image:img5 tag:5];
    //修改起始页面
    NSArray *tabBarArray = [[NSArray alloc] initWithObjects:messageNaviControll,dutyControll,applyController,tongshiControll,settingControll,nil ];
    UITabBarController *TabBar = [[UITabBarController alloc] init];
    [[TabBar tabBar] setTintColor:[UIColor darkGrayColor]];
    TabBar.viewControllers = tabBarArray;
    self.window.rootViewController = TabBar;
   [self.window makeKeyAndVisible];
    [self  createDatabaseIfNeeded:@"Duty.sqlite"];
    [self openDB];
    return YES;
}

-(void)myMessage{
    UIAlertView *demo = [[UIAlertView alloc] initWithTitle:@"tidhi" message:@"tidhi" delegate:self cancelButtonTitle:@"tidhi" otherButtonTitles:nil, nil] ;
    [demo show];
}
- (void)applicationWillResignActive:(UIApplication *)application
{
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [[UIApplication  sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{

}

- (void)applicationDidBecomeActive:(UIApplication *)application
{

}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    if(sqlite3_close(db) != SQLITE_OK)
    {
        NSAssert1(0, @"Failed to close database file with message%s", sqlite3_errmsg(db));

    }
    
}
-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
}

-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{

}
//sqlite操作
-(void)createDatabaseIfNeeded:(NSString *)fileName;
{
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager] ;
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDictionary = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDictionary stringByAppendingPathComponent:fileName];
    success = [fileManager fileExistsAtPath:writableDBPath];
    if(success)
    {
            return;
    }else
    {
        NSString *DefaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:fileName];
        success = [fileManager copyItemAtPath:DefaultDBPath toPath:writableDBPath error:&error];
        
        if(!success)
        {
            NSLog(@"%s",[error localizedDescription]);
            //NSAssert1(0, @"Failed to create wriable database file with message'%s'", [error localizedDescription]);
        }

    }

}
-(void)openDB
{
     NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDictionary = [paths objectAtIndex:0];
    NSString *DBPath = [documentsDictionary stringByAppendingPathComponent:@"Duty.sqlite"];
    int returnVal  = sqlite3_open([DBPath UTF8String], &db);
    if(returnVal != SQLITE_OK)
    {
        sqlite3_close(db);
        NSAssert1(0, @"Failed to open database file with message'%s'", sqlite3_errmsg(db));
    }
    
}
//检测相机是否存在或者工作正常
-(BOOL) isCameraAvailable{
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
}
@end

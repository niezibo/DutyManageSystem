//
//  colleageContact.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-22.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "colleageContact.h"

@interface colleageContact ()

@end

@implementation colleageContact
@synthesize phoneCall = _phoneCall;
@synthesize sendSMS = _sendSMS;
@synthesize duty = _duty;
@synthesize department = _department;
@synthesize cellphone = _cellphone;
@synthesize telephone = _telephone;
@synthesize email = _email;
@synthesize workPosition = _workPosition;
@synthesize myhome = _myhome;
@synthesize birth = _birth;
@synthesize notes = _notes;
@synthesize cellPhoneLabel =_cellPhoneLabel;
@synthesize userNameLabel = _userNameLabel;
@synthesize telePhoneLabel = _telePhoneLabel;
@synthesize emailLabel =_emailLabel;
@synthesize workPositionLabel  =_workPositionLabel;
@synthesize myHomeLabel  = _myHomeLabel;
@synthesize birthLabel = _birthLabel;
@synthesize noteLabel = _noteLabel;
@synthesize postLabel = _postLabel;
@synthesize dutyLabel = _dutyLabel;
@synthesize contentCell = _contentCell;
@synthesize posButton = _posButton;
@synthesize posTime =_posTime;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    RequestKiss = [[NSNetRequestKiss alloc] init];
    // Do any additional setup after loading the view from its nib.
    contactMethod= [[NSArray alloc] initWithObjects:@"拨打电话",@"发送短信", nil] ;
    phoneNum = self.passPhoneNum;
    self.navigationItem.title = @"联系同事";
    self.userNameLabel.text = [self.contentCell objectForKey:@"userName"];
    self.cellPhoneLabel.text = [self.contentCell objectForKey:@"telNo"];
    self.emailLabel.text = [self.contentCell objectForKey:@"emailAddress"];
    self.myHomeLabel.text = [self.contentCell objectForKey:@"homeAddress"];
    self.birthLabel.text = [self.contentCell objectForKey:@"birthDay"];
    self.noteLabel.text = [self.contentCell objectForKey:@"remarksColumn"];
    self.postLabel.text = self.postName;
    self.dutyLabel.text =  [[RequestKiss readSqlite:@"04" sub:[self.contentCell objectForKey:@"dutyKind"]] objectForKey:[self.contentCell objectForKey:@"dutyKind"] ];
    First = [[NSArray alloc] initWithObjects:self.department,self.duty, nil];
    Second = [[NSArray alloc] initWithObjects:self.telephone,self.cellphone, nil];
    
    Third= [[NSArray alloc] initWithObjects:self.email, nil];
    
    Forth= [[NSArray alloc] initWithObjects:self.workPosition,self.myhome, nil];
    
    Fiveth= [[NSArray alloc] initWithObjects:self.birth,self.notes, nil];
    BaseCell = [[NSMutableDictionary alloc] initWithObjectsAndKeys:First,@"First",Second,@"Second",Third,@"Third",Forth,@"Forth",Fiveth, @"Fiveth",nil];
    RequestKiss = [[NSNetRequestKiss alloc] init];
    NSString *post = [NSString stringWithFormat:@"userId=%@",[self.contentCell objectForKey:@"userId"]];
    NSURLConnection *urlConn = [[NSURLConnection alloc] initWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/colleage_checkSomeOnePosition.action" AsyncOrSync:YES PostFormNetData:post] delegate:self];
    [urlConn start];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    NSInteger *section = indexPath.section;
    NSString *key  =[[BaseCell allKeys] objectAtIndex:section];
    cell = [[BaseCell objectForKey:key] objectAtIndex:indexPath.row];
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[BaseCell objectForKey:[[BaseCell allKeys] objectAtIndex:section] ] count];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return [BaseCell count];
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(section ==0){
        return self.HeadView;
    }else{
        return nil;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(section ==0){
        return 110;
    }else
    {
        return 10;
    }
}

//调用拨打电话
-(void)makeaCall:(NSString*)poneNum
{
   
    NSURL *phoneURL = [NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",phoneNum]];
    UIWebView  *phoneCalWebView = [[UIWebView alloc] initWithFrame:CGRectZero];
    [phoneCalWebView loadRequest:[NSURLRequest requestWithURL:phoneURL]];
    [self.view addSubview:phoneCalWebView];

}
//调用sendSMS函数
//内容，收件人列表
- (void)sendSMS:(NSString *)bodyOfMessage recipientList:(NSArray *)recipients
{
    
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    
    if([MFMessageComposeViewController canSendText])
        
    {
        
        controller.body = bodyOfMessage;
        
        controller.recipients = recipients;
        
        controller.messageComposeDelegate = self;
        
        [self presentModalViewController:controller animated:YES];
        
    }
    
}

// 处理发送完的响应结果
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissModalViewControllerAnimated:YES];
    
    if (result == MessageComposeResultCancelled)
        NSLog(@"Message cancelled");
    else if (result == MessageComposeResultSent)
        NSLog(@"Message sent");
    else
        NSLog(@"Message failed");
}

-(IBAction)makeAcall:(id)sender
{
     [self makeaCall:phoneNum];
}
-(IBAction)makeAsms:(id)sender
{
 [self sendSMS:@"Hello" recipientList:[[NSArray  alloc] initWithObjects:phoneNum, nil]];
}
-(IBAction)navitoMap:(id)sender
{
    locationView = [[colleageLocation alloc] initWithNibName:@"colleageLocation" bundle:nil];
    locationView.longi = [[rootDic objectForKey:@"checkinLongitude"] floatValue];
    locationView.lati = [[rootDic objectForKey:@"checkinLatitude"] floatValue];
    locationView.colleageName = [self.contentCell objectForKey:@"userName"];
    locationView.locationName = self.posButton.titleLabel.text;
    [self.navigationController pushViewController:locationView animated:YES];
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    /// self.loadingText.text =@"正在登录...";
    
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //  self.loadingText.text = @"认证成功...";
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    receiveData = data;
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error ;
    rootDic = [NSJSONSerialization JSONObjectWithData: receiveData options:NSJSONReadingMutableLeaves error:&error];
    NSDictionary *colleagePos = [RequestKiss getMyPositionLon:[[rootDic objectForKey:@"checkinLongitude"] floatValue] getMyPositionLon:[[rootDic objectForKey:@"checkinLatitude"] floatValue]];
    NSString *colleageText = [[[[[colleagePos objectForKey:@"list"] objectAtIndex:0] objectForKey:@"poilist"] objectAtIndex:0] objectForKey:@"name"];
    if(![colleageText isEqualToString:@""])
    {
        self.posButton.titleLabel.text = colleageText;
        self.posTime.text = [rootDic objectForKey:@"checkinTime"] ;
    }
 
    
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}

@end

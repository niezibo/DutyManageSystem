//
//  SignInReport.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-3.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "SignInReport.h"

@interface SignInReport ()

@end

@implementation SignInReport

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

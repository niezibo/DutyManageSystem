//
//  Setting.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-13.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ModifyPassword.h"
#import "BaseInformation.h"
#import "About.h"
#import "Suggest.h"
#import "Login.h"
@interface Setting : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    //PersonalInformation *personInfo;
    ModifyPassword      *modifyPw;
    BaseInformation *personInfo;
    About        *about;
    Suggest            *suggestMine;
    UINavigationController *naviInfo;
    UINavigationController *naviPw;
    NSArray *Container_Nie;
    NSUserDefaults *userDefault;
}
@property (strong, nonatomic) IBOutlet UITableViewCell *trackInteval;


@end

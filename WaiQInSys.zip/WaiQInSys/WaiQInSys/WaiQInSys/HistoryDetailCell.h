//
//  HistoryDetailCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryDetailCell : UITableViewCell


@property (nonatomic) IBOutlet UILabel *CountLabel;
@property (nonatomic , retain) IBOutlet UILabel *WorkState;
@property (nonatomic , retain) IBOutlet UILabel *WorkStateSecond;
@property (nonatomic , retain) IBOutlet UILabel *CheckTime;
@property (nonatomic , retain) IBOutlet UILabel *Who;
@property (nonatomic , retain) IBOutlet UILabel *CheckState;
@property (nonatomic , retain) IBOutlet UILabel *CheckStateSecond;
@property (nonatomic,  retain) IBOutlet UILabel *WhoPosition;
@end

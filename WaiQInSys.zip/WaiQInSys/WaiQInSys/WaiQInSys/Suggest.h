//
//  Suggest.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-13.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewOperation.h"

@interface Suggest : UIViewController<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate>
{
    NSArray *cellContainer;
    NSArray *cellContainerHeight;
        ViewOperation *vo;
}
@property (nonatomic, retain) IBOutlet UITableViewCell *cell1;
@end

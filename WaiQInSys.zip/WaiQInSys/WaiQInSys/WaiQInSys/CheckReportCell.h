//
//  CheckReportCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-20.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckReportCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UILabel *leftTitle;
@property (nonatomic, retain) IBOutlet UILabel *startDate;
@property (nonatomic, retain) IBOutlet UILabel *endDate;
@property (nonatomic, retain) IBOutlet UILabel *applyState;
@end

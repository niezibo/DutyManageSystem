
//
//  RGBConvertUIColor.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "RGBConvertUIColor.h"

@implementation RGBConvertUIColor
-(UIColor *) convertRGB:(NSString *)rgb andAlpha:(NSString *)alpha
{
    unsigned int red, green, blue;
    NSRange range;
    range.length =2;
    range.location =0;
    [[NSScanner scannerWithString:[rgb substringWithRange:range]]scanHexInt:&red];
    range.location =2;
    [[NSScanner scannerWithString:[rgb substringWithRange:range]]scanHexInt:&green];
    range.location =4;
    [[NSScanner scannerWithString:[rgb substringWithRange:range]]scanHexInt:&blue];
    CGFloat  alp = [alpha floatValue];
    return [UIColor colorWithRed:(float)(red/255.0f)green:(float)(green/255.0f)blue:(float)(blue/255.0f)alpha:alp];
}

@end

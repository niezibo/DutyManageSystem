//
//  AppDelegate.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-25.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
//添加引用
#import "DefaultMessage.h"
#import "ViewController.h"
#import "Login.h"
#import "duty.h"
#import "tongshiLocationView.h"
#import "Setting.h"
#import "Colleague.h"
#import "ApplyForDuty.h"
#import <sqlite3.h>


//#ifdef  kAppKey
//#error
//#endif

//#ifdef  kAppScecret
//#error
//#endif

//#ifdef  kAppRedirectURI
//#error
//#endif

@class ViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
   UINavigationController *navigation_Nie ;
    NSString *UserName_Nie;
    NSString *UserPassword_Nie;
    sqlite3 *db;
}
-(void)createDatabaseIfNeeded:(NSString *)fileName;
-(void)openDB;
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) IBOutlet UITabBarController *rootController;

@end

//
//  BaseInformation.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-12.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSNetRequestKiss.h"
#import <sqlite3.h>
#import "ViewOperation.h"

@interface BaseInformation : UIViewController <UITableViewDelegate , UITableViewDataSource,UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate,UIImagePickerControllerDelegate>
{
    NSArray *Container;
    NSMutableDictionary *BaseCell;
    NSArray *First;
    NSArray *Second;
    NSArray *Third;
    NSArray *Forth;
    NSArray *Fiveth;
    UIBarButtonItem  *Edit_Msg ;
    NSString  *path;
    NSMutableDictionary *WorKDic;
    NSArray   *WorkArr;
    int  hero;
    NSNetRequestKiss *RequestKiss;
    BOOL girl;
    sqlite3 *db;
    NSMutableDictionary *dutyArr;
    NSUserDefaults *userDefault;
    NSDictionary * rootDic;
    NSArray *postArr;
    NSDictionary *sexDic;
        ViewOperation *vo;
     UIImagePickerController *imagePicker;
    NSDictionary *picSource;
}

@property (nonatomic,retain)  IBOutlet NSMutableData *receiveData;
@property  (nonatomic , retain) IBOutlet UILabel *UserName_Nie;
@property  (nonatomic , retain) IBOutlet UILabel *SubLabel_Nie;
@property (nonatomic, retain) IBOutlet UIView *FaceCandy;
@property (weak, nonatomic) IBOutlet UIWebView *loadingWebView;
@property (weak, nonatomic) IBOutlet UIView *loadingView;

@property (weak, nonatomic) IBOutlet UITextField *sexKind;
@property (nonatomic, retain) IBOutlet UITableView *defaultTableView;
@property (strong, nonatomic) IBOutlet UIView *HeadView;
@property (strong, nonatomic) IBOutlet UITableViewCell *duty;
@property (strong, nonatomic) IBOutlet UITableViewCell *department;
@property (weak, nonatomic) IBOutlet UITableViewCell*cellphone;
@property (weak, nonatomic) IBOutlet UITableViewCell *telephone;
@property (weak, nonatomic) IBOutlet UITableViewCell *email;
@property (strong, nonatomic) IBOutlet UITableViewCell *workPosition;
@property (strong, nonatomic) IBOutlet UITableViewCell *myhome;
@property (strong, nonatomic) IBOutlet UITableViewCell *birth;
@property (strong, nonatomic) IBOutlet UITableViewCell *notes;
@property (weak, nonatomic) IBOutlet UITextField *cellphoneTextField;
@property (weak, nonatomic) IBOutlet UITextField *emailTextField;
@property (weak, nonatomic) IBOutlet UITextField *workPositionTextField;
@property (weak, nonatomic) IBOutlet UITextField *myhomeTextField;
@property (weak, nonatomic) IBOutlet UITextField *birthTextField;
@property (weak, nonatomic) IBOutlet UITextField *noteTextField;
@property (weak, nonatomic) IBOutlet UITextField *departmentTextField;
@property (weak, nonatomic) IBOutlet UITextField *dutyTextField;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker;
@property (strong, nonatomic) IBOutlet UIPickerView *datapicker;
@property (weak, nonatomic) IBOutlet UIImageView *userFace;

-(IBAction)fillDataforDatePickerItem:(id)sender;
-(IBAction)fillDataforDatePickerDuty:(id)sender;
-(IBAction)fillDataforDatePickerSex:(id)sender;
@end

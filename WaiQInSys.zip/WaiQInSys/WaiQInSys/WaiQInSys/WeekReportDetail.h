//
//  WeekReportDetail.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-16.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WeekReportDetailCell.h"
#import "NSNetRequestKiss.h"

@interface WeekReportDetail : UIViewController<UITableViewDataSource, UITableViewDelegate,NSURLConnectionDelegate,NSURLConnectionDataDelegate>
{
    NSNetRequestKiss *ResquestKiss;
    NSData *weeDetailData;
    NSMutableArray *weekDetail;
}
@property (retain, nonatomic) IBOutlet UITableView *weekDetailTable;
@property (nonatomic) IBOutlet int *workApplyNo;
@end

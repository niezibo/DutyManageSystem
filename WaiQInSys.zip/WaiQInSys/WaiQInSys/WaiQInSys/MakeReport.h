//
//  MakeReport.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-4-1.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReportList.h"
#import "ViewOperation.h"

@interface MakeReport : UIViewController<UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate>
{
    NSMutableArray *Container;
    ReportList *signinReport;
        NSUserDefaults *userDefa;
    ViewOperation *vo;
}
@property(nonatomic) NSData *fieldBeginer;
@property(nonatomic) NSData *fieldEnder;
@property(nonatomic) NSInteger Beginer;
@property(nonatomic) NSInteger Ender;

@end

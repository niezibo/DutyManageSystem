//
//  WeekReportDetailCell.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-16.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "WeekReportDetailCell.h"

@implementation WeekReportDetailCell
@synthesize weekDay = _weekDay;
@synthesize weekDayDate  = _weekDayDate;
@synthesize DutyClass = _DutyClass;
@synthesize onDutyTime = _onDutyTime;
@synthesize offDutyTime = _offDutyTime;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

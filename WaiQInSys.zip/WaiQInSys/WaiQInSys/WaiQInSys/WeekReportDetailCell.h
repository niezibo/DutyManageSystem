//
//  WeekReportDetailCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-5-16.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeekReportDetailCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *weekDay;
@property (weak, nonatomic) IBOutlet UILabel *weekDayDate;
@property (weak, nonatomic) IBOutlet UILabel *DutyClass;
@property (weak, nonatomic) IBOutlet UILabel *onDutyTime;
@property (weak, nonatomic) IBOutlet UILabel *offDutyTime;

@end

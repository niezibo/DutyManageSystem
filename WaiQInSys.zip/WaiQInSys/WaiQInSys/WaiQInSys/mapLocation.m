//
//  mapLocation.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-5.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "mapLocation.h"


@implementation mapLocation
@synthesize coordinate, title, subtitle;

-(NSString*)tagTitle
{
    return @"你的当前位置";
}
-(NSString*)subTitle
{
    NSMutableString *ret = [NSMutableString string];
    if (streetAddress)
        [ret appendString:streetAddress];
    if (streetAddress && (city || state || zip))
        [ret appendString:@" • "];
    if (city)
        [ret appendString:city];
    if (city && state)
        [ret appendString:@", "];
    if (state)
        [ret appendString:state];
    if (zip)
        [ret appendFormat:@", %@", zip];
    
    return ret;
}
#pragma mark NSCoding Methods
- (void) encodeWithCoder: (NSCoder *)encoder {
    [encoder encodeObject: [self streetAddress] forKey: @"streetAddress"];
    [encoder encodeObject: [self city] forKey: @"city"];
    [encoder encodeObject: [self state] forKey: @"state"];
    [encoder encodeObject: [self zip] forKey: @"zip"];
}
- (id) initWithCoder: (NSCoder *)decoder  {
    if (self = [super init]) {
        [self setStreetAddress: [decoder decodeObjectForKey: @"streetAddress"]];
        [self setCity: [decoder decodeObjectForKey: @"city"]];
        [self setState: [decoder decodeObjectForKey: @"state"]];
        [self setZip: [decoder decodeObjectForKey: @"zip"]];
    }
    return self;
}

-(id) initWithCoordinate:(CLLocationCoordinate2D)coords
{
    if(self == [super init]){
        coordinate = coords;
    }
    return self;
}
@end

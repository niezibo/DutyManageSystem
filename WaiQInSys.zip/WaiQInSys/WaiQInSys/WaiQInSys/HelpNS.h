//
//  HelpNS.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-21.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HelpNS : NSObject
@property (nonatomic, retain) UIView *vv;
@property (nonatomic)  int year;
@property (nonatomic)  int month;
-(int)gethowmanyweeks;
-(NSMutableArray*) getfromto:(int) weekth;
-(void)init_Son:(UIView*)a;
-(void) initer;
@end

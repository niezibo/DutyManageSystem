//
//  ReportList.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HelpNS.h"
#import <sqlite3.h>
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"

@interface ReportList : UIViewController<UITableViewDataSource, UITableViewDelegate, UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate>
{
    NSArray *cellContainer;
    NSString  *path;
    NSMutableDictionary *WorKDic;
    NSArray   *WorkArr;
    NSArray  *docWork;
    
    NSArray *vacationOption;
    HelpNS *helpKiss;
    sqlite3 *db;
    NSMutableDictionary *dutyArr;
    NSNetRequestKiss *RequestKiss;
    NSDate *receiveData;
    NSUserDefaults *userDefault ;
    NSUserDefaults *userDefa;
    ViewOperation *vo;

}
@property (nonatomic, retain) IBOutlet NSString *WhichDay;
@property (nonatomic, retain) IBOutlet NSString *Ticket;
@property (nonatomic, retain) IBOutlet NSString *TicketNum;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell1;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell2;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell3;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell4;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell5;
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *userId;

@property (nonatomic,retain) IBOutlet NSString *classOfvacationBtnString;
@property (nonatomic,retain) IBOutlet UIButton *classOfvacationBtn;
@property (nonatomic,retain) IBOutlet NSString *classOfvacationString;
@property (nonatomic,retain) IBOutlet UITextField *classOfvacation;
@property (nonatomic,retain) IBOutlet NSString *onDutyString;
@property (nonatomic,retain) IBOutlet UITextField *onDuty;
@property (nonatomic,retain) IBOutlet NSString *offDutyString;
@property (nonatomic,retain) IBOutlet UITextField *offDuty;
@property (nonatomic,retain) IBOutlet NSString    *PrivatetimeString;
@property (nonatomic,retain) IBOutlet UITextField *Privatetime;
@property (nonatomic,retain) IBOutlet NSString    *PrivatetravelTimeString;
@property (nonatomic,retain) IBOutlet UITextField *PrivatetravelTime;
@property (nonatomic,retain) IBOutlet NSString    *RemarksString;
@property (nonatomic,retain) IBOutlet UITextView  *Remarks;

@property (strong, nonatomic) IBOutlet UIPickerView *datapicker;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker1;
@property (strong, nonatomic) IBOutlet UIDatePicker *datepicker2;


@end

//
//  DefaultMessage.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-6.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "DefaultMessage.h"

@interface DefaultMessage ()

@end

@implementation DefaultMessage
@synthesize FirstVew = _FirstVew;
@synthesize SearchViewContainer = _SearchViewContainer;
@synthesize CompanyTable = _CompanyTable;
@synthesize SegMessage = _SegMessage;
@synthesize bottomBar =_bottomBar;
@synthesize FatherView  =_FatherView;
@synthesize SonView = _SonView;
@synthesize PersonM = _PersonM;
@synthesize CompanyM = _CompanyM;
@synthesize receiveData = _receiveData;
@synthesize receiveDataUser = _receiveDataUser;
@synthesize segmentMsg = _segmentMsg;
@synthesize loadinWebview =_loadinWebview;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    userDefault = [NSUserDefaults standardUserDefaults];
    na = [[NSMutableArray alloc] initWithCapacity:10];
    naUser = [[NSMutableArray alloc] initWithCapacity:10];
    if([userDefault objectForKey:@"up"]==NULL | [userDefault objectForKey:@"un"]==NULL)
    {
        Login  *login_Nie =[[ Login alloc]  initWithNibName:@"Login" bundle:nil];
        [self.navigationController pushViewController:login_Nie animated:NO];
    }

    // Do any additional setup after loading the view from its nib.
    [self.navigationItem setHidesBackButton:YES];
    self.tabBarController.tabBar.hidden = NO;

    [self.navigationItem setTitleView:self.segmentMsg];
    [self.segmentMsg addTarget:self action:@selector(getMsg:) forControlEvents:UIControlEventValueChanged];
    //s数值在这里

    pretty = 1;
    RequestKiss = [[NSNetRequestKiss alloc] init];
    [RequestKiss loadingAction:self.loadinWebview];
    NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/bulletin_checkBulletin.action" AsyncOrSync:YES PostFormNetData:nil]delegate:self];
    [urlConnection start];
    [self.CompanyTable addPullToRefreshWithActionHandler:^{
        [self.CompanyTable.pullToRefreshView performSelector:@selector(stopAnimating) withObject:nil afterDelay:2];
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(pretty == 1)
    {
        return  [na count];
    }else  if(pretty == 0 )
    {
         return  [naUser count];
    }    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"SimpleDataItem";
    CompanyMessageCell *cell = (CompanyMessageCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        
        NSArray *nib_Nie = [[NSBundle mainBundle] loadNibNamed:@"CompanyMessageCell" owner:self options:nil];
        cell = [nib_Nie objectAtIndex:0];
    }
    if(pretty==0)
    {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.mianTitle.text = [ [na objectAtIndex:indexPath.row] objectForKey:@"tulTitle"];
        cell.mianMsg.text = [ [na objectAtIndex:indexPath.row] objectForKey:@"tulTitle"];
        cell.pubMan.text = [ [na objectAtIndex:indexPath.row]  objectForKey:@"userName"];
        cell.pubTime.text = [ [na objectAtIndex:indexPath.row]  objectForKey:@"inputTime"];
    }
    else if(pretty==1)
    {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.mianTitle.text = [ [naUser objectAtIndex:indexPath.row] objectForKey:@"inforTitle"];
        cell.mianMsg.text = [ [naUser objectAtIndex:indexPath.row] objectForKey:@"inforTitle"];
        cell.pubMan.text = [ [naUser objectAtIndex:indexPath.row]  objectForKey:@"userName"];
        cell.pubTime.text = [ [naUser objectAtIndex:indexPath.row]  objectForKey:@"inputTime"];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DefaultDetailCompanyMessage *companyMessage = [[DefaultDetailCompanyMessage alloc] initWithNibName:@"DefaultDetailCompanyMessage" bundle:nil];
    if(pretty  == 0)
    {
       companyMessage.containerCell = [na objectAtIndex:indexPath.row];
    }else if(pretty ==1)
    {
       companyMessage.containerCell = [naUser objectAtIndex:indexPath.row];
    }
    
    [self.navigationController pushViewController:companyMessage animated:YES];
}
-(void)getMsg:(id)sender
{
    UISegmentedControl *seg = (UISegmentedControl *)sender;
    self.loadinWebview.hidden = NO;
    if(seg.selectedSegmentIndex==0)
    {
        pretty = 1;
        NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/bulletin_checkBulletin.action" AsyncOrSync:YES PostFormNetData:nil]delegate:self];
        [urlConnection start];
    }else
    {
        pretty = 0;
        NSString *post = [NSString stringWithFormat:@"userId=%@", [userDefault objectForKey:@"uid"]];
        NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:[RequestKiss PostFormNetURL:@"http://w3c.ap01.aws.af.cm/userinformation_checkUserInformation.action" AsyncOrSync:YES PostFormNetData:post]delegate:self];
        [urlConnection start];
    }
}
//网络请求i
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    
    return request;
}
//接收到服务器回应的时候调用此方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //self.loadingText.text =@"认证成功...";
}
//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    if(pretty==0)
    {
          self.receiveDataUser = data;  
    }else
    {
        
        self.receiveData = data;
    }

    
}
//数据传完之后调用此方法
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSError *error;
    if(pretty ==0)
    {
        naUser = [NSJSONSerialization JSONObjectWithData:self.receiveDataUser options:NSJSONReadingMutableLeaves error:&error];

        [self dyncTable:naUser];
        if([naUser count]==0)
        {
            [self.view makeToast:@"暂无个人信息，请稍后重试"];
        }
         pretty = 1;
        
    }else if(pretty ==1)
    {
       na = [NSJSONSerialization JSONObjectWithData:self.receiveData options:NSJSONReadingMutableLeaves error:&error];
       [self dyncTable:na];
        if([na count]==0)
        {
            
            [self.view makeToast:@"暂无公司公告，请稍后重试"];
        }
        pretty = 0;
    }
    self.loadinWebview.hidden = YES;

    

    
}
-(void)dyncTable:(NSArray*)a
{
    NSMutableArray *nmar =[[NSMutableArray alloc] initWithCapacity:10];
    for (int i = 0; i < [a  count]; i++) {
        [nmar addObject:[NSIndexPath indexPathForRow:i inSection:0]];
    }
    [self.CompanyTable reloadData];
}
//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView * alertV = [[UIAlertView alloc] initWithTitle:@"网络连接失败" message:[NSString  stringWithFormat:@"%@",error] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertV show];
    
}
@end

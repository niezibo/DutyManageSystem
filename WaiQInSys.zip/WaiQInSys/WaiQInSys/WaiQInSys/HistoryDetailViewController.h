//
//  HistoryDetailViewController.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-18.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryDetailCell.h"
#import "NSNetRequestKiss.h"

@interface HistoryDetailViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    NSString   *path;
    NSDictionary   *data;
    NSArray   *Records;
    NSArray  *detailRecords;
    NSNetRequestKiss *RequestKiss;
    NSMutableArray *outWorkCheckIn;
    NSMutableData *receiveData;
    NSUserDefaults *userDefault;
}
@property (weak, nonatomic) IBOutlet UITableView *outWorkCheckInStatus;

@property (nonatomic) IBOutlet int *loadNUM;
@end

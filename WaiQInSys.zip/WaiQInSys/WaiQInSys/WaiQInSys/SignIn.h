//
//  SignIn.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "mapLocation.h"
#import "NSNetRequestKiss.h"
#import "ViewOperation.h"

@interface SignIn : UIViewController<UITableViewDelegate , UITableViewDataSource,MKMapViewDelegate , CLLocationManagerDelegate, MKReverseGeocoderDelegate, UIPickerViewDataSource, UIPickerViewDataSource,UITextFieldDelegate,UIImagePickerControllerDelegate>

{
    NSArray *Cells;
    NSArray *CellsHeight;
    CLLocationManager *locationManager;
    NSString *streetAddress;
    NSString *cityAddress;
    NSDictionary *Container;
    int hero;
    NSUserDefaults *userDefault;
    NSNetRequestKiss *RequestKiss;
    NSMutableData *receiveData;
    NSString  *checkinLongitude;
    NSString  *checkinLatitude;
        ViewOperation *vo;
    UIImagePickerController *imagePicker;
    NSArray *picArr;
    NSDictionary *picSource;
   
    
}
@property (weak, nonatomic) IBOutlet UILabel *state;
@property (nonatomic, retain) IBOutlet UITableView  *KissTable;
@property  (nonatomic,retain) IBOutlet UIView *HeadView;
@property  (nonatomic,retain) IBOutlet UIView *HeadViewFace;
@property (nonatomic , retain) IBOutlet UITableViewCell *cell1;
@property (nonatomic , retain) IBOutlet UITableViewCell *cell2;
@property (nonatomic , retain) IBOutlet UITableViewCell *cell3;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell4;
@property (nonatomic, retain) IBOutlet MKMapView *mapMine;
@property (weak, nonatomic) IBOutlet UISegmentedControl *SegChoose;
@property (weak, nonatomic) IBOutlet UITabBarItem *SecondTabBar;
@property (strong, nonatomic) IBOutlet UIPickerView *datapicker;
//记录信息
@property (nonatomic,retain) IBOutlet UILabel *staffName;
@property (nonatomic,retain) IBOutlet UILabel *staffId;
@property (nonatomic,retain) IBOutlet UITextField *staffPosition;
@property (nonatomic,retain) IBOutlet UITextField *staffSigntime;
@property (nonatomic,retain) IBOutlet UITextField *staffSignstate;
@property (weak, nonatomic) IBOutlet UIWebView *SigninWebview;
@property (weak, nonatomic) IBOutlet UITextField *getPicText;
@property (weak, nonatomic) IBOutlet UIImageView *userFace;

-(void)createAnnotationWIthCoords:(CLLocationCoordinate2D) coords;
-(IBAction)gtePic:(id)sender;
-(void)pickImage; //从相册离选取图片上传
-(void)snapImage; //拍照获得
-(UIImage *)scaleToSize:(UIImage *)img size:(CGSize) size; //设置图片尺寸
@end

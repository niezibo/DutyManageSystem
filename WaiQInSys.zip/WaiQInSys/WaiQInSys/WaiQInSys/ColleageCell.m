//
//  ColleageCell.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-22.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "ColleageCell.h"

@implementation ColleageCell
@synthesize colleageDuty = _colleageDuty;
@synthesize colleageFace = _colleageFace;
@synthesize colleageName = _colleageName;
@synthesize colleagePhone = _colleagePhone;
@synthesize colleageId = _colleageId;
@synthesize colleageIco  =_colleageIco;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

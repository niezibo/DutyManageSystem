//
//  duty.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-11.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "duty.h"

@interface duty ()

@end

@implementation duty

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    GoOut = [[ ApplicationGoOut alloc] initWithNibName:@"ApplicationGoOut" bundle:nil];
    Signin = [[SignIn alloc] initWithNibName:@"SignIn" bundle:nil];
    historyTrack = [[HistoryTrackSearch alloc] initWithNibName:@"HistoryTrackSearch" bundle:nil];
    DutyList = [[NSDictionary alloc] initWithObjectsAndKeys:GoOut,@"外出申请",Signin,@"签到",historyTrack,@"历史追踪" ,nil];
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title = @"外出勤务";
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    cell.textLabel.text = [[DutyList  allKeys] objectAtIndex:indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *key = [[DutyList allKeys] objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:[DutyList objectForKey:key] animated:YES];
}
-(IBAction)navitoSign:(id)sender
{
[self.navigationController pushViewController:Signin animated:YES];
}
-(IBAction)navitoApplicationGoOut:(id)sender;

{
[self.navigationController pushViewController:GoOut animated:YES];
}
-(IBAction)navitoHistoryTracker:(id)sender;

{
[self.navigationController pushViewController:historyTrack animated:YES];
}
@end

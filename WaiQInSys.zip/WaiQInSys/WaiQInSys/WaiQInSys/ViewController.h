//
//  ViewController.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-15.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController

@end

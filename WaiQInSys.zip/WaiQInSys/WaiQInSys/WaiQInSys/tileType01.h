//
//  tileType01.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-2-27.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface tileType01 : UIView
{
  
}

@end

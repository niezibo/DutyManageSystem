//
//  CompanyMessageCell.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-4.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RGBConvertUIColor.h"

@interface CompanyMessageCell : UITableViewCell


@property (nonatomic, weak) IBOutlet UILabel *mianTitle;
@property (nonatomic, weak) IBOutlet UILabel *mianMsg;
@property (nonatomic, weak) IBOutlet UILabel *pubTime;
@property (nonatomic, weak) IBOutlet UILabel *pubMan;
@end

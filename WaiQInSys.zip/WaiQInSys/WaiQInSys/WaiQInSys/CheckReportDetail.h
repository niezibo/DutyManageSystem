//
//  CheckReportDetail.h
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-20.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "NSNetRequestKiss.h"
#import "WeekReportDetail.h"

@interface CheckReportDetail : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    NSArray *cellContainer;
    NSArray *cellContainerHeight;
    NSNetRequestKiss *RequestKiss;
}
@property (nonatomic,retain) IBOutlet UITableViewCell *cell0;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell1;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell2;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell3;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell4;
@property (nonatomic,retain) IBOutlet UITableViewCell *cell5;
@property (nonatomic,retain) IBOutlet NSString        *headTitle;
@property (weak, nonatomic) IBOutlet UITextField      *SignObjectDay;
@property (weak, nonatomic) IBOutlet UITextField *SignDay;
@property (weak, nonatomic) IBOutlet UITextField *DateLimit;
@property (weak, nonatomic) IBOutlet UITextField *Approver;
@property (weak, nonatomic) IBOutlet UITextField *State;
@property (weak, nonatomic) IBOutlet UITextView *Note;
@property (nonatomic,retain) IBOutlet NSString        *ObjectTitle;
@property (nonatomic,retain) IBOutlet NSDictionary *DicDetail;
@end

//
//  TongShiCell.m
//  WaiQInSys
//
//  Created by zhihuiguan on 13-3-4.
//  Copyright (c) 2013年 fun. All rights reserved.
//

#import "TongShiCell.h"

@implementation TongShiCell
@synthesize NumberView = _NumberView;
@synthesize LocationView = _LocationView;

@synthesize CheckLocation = _CheckLocation;
@synthesize CheckName = _CheckName;
@synthesize CheckNumber =_CheckNumber;
@synthesize CheckLocationTime = _CheckLocationTime;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        UISwipeGestureRecognizer *locationGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(navitoLocation:)];
        [self.LocationView addGestureRecognizer:locationGesture];
        UISwipeGestureRecognizer *numberGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(navitoContact:)];
        [self.NumberView addGestureRecognizer:numberGesture];
        
        //设置字体
        _CheckLocation.font = [UIFont fontWithName:@"Microsoft Yahei" size:14];
        _CheckName.font = [UIFont fontWithName:@"Microsoft Yahei" size:14];
        _CheckLocationTime.font = [UIFont fontWithName:@"Microsoft Yahei" size:14];
        _CheckNumber.font = [UIFont fontWithName:@"Microsoft Yahei" size:14];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state

}

-(void)navitoLocation:(UISwipeGestureRecognizer*) gesture
{
    
}
-(void)navitoContact:(UISwipeGestureRecognizer*) gesture
{
    
}

@end
